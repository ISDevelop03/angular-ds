import { EventEmitter } from '@angular/core';
import { CardVariant } from '../card-visual/card-visual.component';
export interface RechargeCardRowData {
    id: string;
    holder: string;
    numTail: string;
    expiry: string;
    solde: number;
    variant?: CardVariant;
    productName?: string;
}
/**
 * RechargeCardRowComponent — ligne carte pour l'onglet Initiation (recharge Escale PRO)
 *
 * Live demo:
 * <example-url>/demo/ds-recharge-initiation-card-list.component.html</example-url>
 */
export declare class RechargeCardRowComponent {
    card: RechargeCardRowData;
    productName: string;
    actionLabel: string;
    className: string;
    onOpen: EventEmitter<RechargeCardRowData>;
    readonly variant: CardVariant;
    readonly positive: boolean;
    readonly resolvedProductName: string;
    formatMad(n: number): string;
    handleOpen(): void;
}
