import { EventEmitter } from '@angular/core';
import { RechargeCardRowData } from '../recharge-card-row/recharge-card-row.component';
/**
 * RechargeInitiationCardListComponent — liste scrollable de cartes (onglet Initiation)
 *
 * Live demo:
 * <example-url>/demo/ds-recharge-initiation-card-list.component.html</example-url>
 */
export declare class RechargeInitiationCardListComponent {
    cards: RechargeCardRowData[];
    productName: string;
    actionLabel: string;
    className: string;
    onOpen: EventEmitter<RechargeCardRowData>;
    open(card: RechargeCardRowData): void;
}
