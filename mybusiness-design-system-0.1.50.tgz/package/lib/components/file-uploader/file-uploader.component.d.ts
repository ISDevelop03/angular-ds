import { ElementRef, EventEmitter } from '@angular/core';
import { UploadedFiles } from '../file-list/file-list.component';
/**
 * FileUploaderComponent
 *
 * Live demo:
 * <example-url>/demo/ds-file-uploader.component.html</example-url>
 */
export declare class FileUploaderComponent {
    allowedExtensions: string[];
    className?: string;
    maxFileSizeMB: number;
    variant: string;
    isMultiple: boolean;
    files: UploadedFiles[];
    disabled: boolean;
    maxHeight: number | undefined;
    showErrorButtonUpload?: boolean;
    isPreviewable: boolean;
    onChange: EventEmitter<File | File[]>;
    onRemove: EventEmitter<string>;
    onReUpload: EventEmitter<string>;
    onDownloadErrors: EventEmitter<string>;
    downloadErrors(fileId: string): void;
    fileInput: ElementRef<HTMLInputElement>;
    currentTheme: import("./theme").FileUploaderTheme;
    selectedFiles: (File & {
        id: string;
    })[];
    isErrorModalShown: boolean;
    errorMessages: string[];
    handleFile(files: File[]): void;
    openFileInput(): void;
    onDrop(event: DragEvent): void;
    onDragOver(event: DragEvent): void;
    private generateUniqueId;
    onFileChange(event: Event): void;
    closeErrorModal(): void;
    removeFile(id: string): void;
}
