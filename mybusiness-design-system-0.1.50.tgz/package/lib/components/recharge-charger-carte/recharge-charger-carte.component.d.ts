import { EventEmitter } from '@angular/core';
import { CardVariant } from '../card-visual/card-visual.component';
export interface RechargeChargerCarteTile {
    label: string;
    value: string;
    /** When `green`, value uses success color (e.g. Solde chargé). */
    tint?: 'green';
}
export interface RechargeChargerCarteDetail {
    label: string;
    value: string;
}
export interface RechargeChargerCarteData {
    name: string;
    holder: string;
    numTail: string;
    expiry: string;
    variant: CardVariant;
    /** Optional override for card thumbnail */
    imageSrc?: string;
    tiles?: RechargeChargerCarteTile[];
    details?: RechargeChargerCarteDetail[];
}
/**
 * RechargeChargerCarteComponent — détail carte recharge (Escale PRO) avec Voir plus / moins
 *
 * Live demo:
 * <example-url>/demo/ds-recharge-charger-carte.component.html</example-url>
 */
export declare class RechargeChargerCarteComponent {
    card: RechargeChargerCarteData;
    expanded: boolean;
    expandLabel: string;
    collapseLabel: string;
    className: string;
    onToggle: EventEmitter<RechargeChargerCarteData>;
    toggle(): void;
    readonly tiles: RechargeChargerCarteTile[];
    readonly details: RechargeChargerCarteDetail[];
}
