import { EventEmitter, OnDestroy } from '@angular/core';
import { DomSanitizer, SafeResourceUrl } from '@angular/platform-browser';
export declare type UploadedFiles = {
    file: File & {
        id: string;
    };
    progress?: number;
    status?: 'uploading' | 'success' | 'error';
    errors?: null | string[];
};
export declare type FilePreviewKind = 'pdf' | 'text' | 'unsupported';
/**
 * FileListComponent
 *
 * Live demo:
 * <example-url>/demo/ds-file-list.component.html</example-url>
 */
export declare class FileListComponent implements OnDestroy {
    private sanitizer;
    className?: string;
    files: UploadedFiles[];
    isMultiple: boolean;
    isDownloadable: boolean;
    isPreviewable: boolean;
    maxHeight: number | undefined;
    showErrorButtonUpload: boolean;
    onDelete: EventEmitter<{}>;
    onReUpload: EventEmitter<{}>;
    onDownload: EventEmitter<{}>;
    onDownloadErrors: EventEmitter<{}>;
    onPreview: EventEmitter<File & {
        id: string;
    }>;
    isPreviewShown: boolean;
    previewFile: (File & {
        id: string;
    }) | null;
    previewKind: FilePreviewKind;
    previewUrl: string | null;
    previewText: string | null;
    safePreviewUrl: SafeResourceUrl | null;
    private errorVisibilityMap;
    constructor(sanitizer: DomSanitizer);
    ngOnDestroy(): void;
    isErrorVisible(fileId: string): boolean;
    toggleErrors(fileId: string): void;
    removeFile(fileId: string): void;
    openPreview(file: File & {
        id: string;
    }): void;
    closePreview: () => void;
    downloadFile(file: File): void;
    formatFileSize(sizeInBytes: number): string;
    canPreview(file: File): boolean;
    private getPreviewKind;
    private revokePreviewUrl;
}
