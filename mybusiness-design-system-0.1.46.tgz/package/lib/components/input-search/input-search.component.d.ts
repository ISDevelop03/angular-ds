import { ElementRef, OnInit } from '@angular/core';
/**
 * InputSearchComponent
 *
 * Live demo:
 * <example-url>/demo/ds-input-search.component.html</example-url>
 */
export declare class InputSearchComponent implements OnInit {
    private elementRef;
    className?: string;
    placeholder: string;
    maxWidth: string;
    defaultOpen: boolean;
    value: string;
    isExpanded: boolean;
    constructor(elementRef: ElementRef<HTMLElement>);
    ngOnInit(): void;
    onDocumentClick(event: MouseEvent): void;
    openSearch(): void;
    clearSearch(): void;
}
