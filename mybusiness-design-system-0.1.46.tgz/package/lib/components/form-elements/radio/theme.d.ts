export declare const radio: {
    default: {
        wrapper: string;
        base: string;
        enabled: {
            checked: string;
            unchecked: string;
        };
        disabled: {
            checked: string;
            unchecked: string;
        };
        icon: {
            base: string;
            enabled: {
                checked: string;
                unchecked: string;
            };
            disabled: {
                checked: string;
                unchecked: string;
            };
        };
        error: string;
        label: {
            base: string;
            disabled: string;
            unchecked: string;
            checked: string;
            error: string;
        };
    };
};
