import { EventEmitter, OnChanges, SimpleChanges } from '@angular/core';
import { PaginationVariants } from './types';
declare type PageItem = number | '...';
/**
 * PaginationComponent
 *
 * Live demo:
 * <example-url>/demo/ds-pagination.component.html</example-url>
 */
export declare class DsPaginationComponent implements OnChanges {
    firstItem: number;
    totalItems: number;
    itemsPerPage: number;
    currentPage: number;
    variant: string;
    className: string;
    showPerPage: boolean;
    minimized: boolean;
    display: "horizontal" | "vertical";
    pageChange: EventEmitter<number>;
    perPageChange: EventEmitter<number>;
    boundaryStartCount: number;
    boundaryEndCount: number;
    windowSize: number;
    prevLabel: string;
    nextLabel: string;
    perPageLabel: string;
    perPageOptions: number[];
    maxPageButtons: number;
    theme: PaginationVariants;
    pages: PageItem[];
    pageCount: number;
    constructor();
    ngOnChanges(changes: SimpleChanges): void;
    private calculatePages;
    selectPage(page: number): void;
    prev(): void;
    next(): void;
    changePerPage(count: number): void;
}
export {};
