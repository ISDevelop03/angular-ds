import { AfterViewInit, OnChanges, SimpleChanges } from '@angular/core';
import { AccordionItem } from '../accordion/accordion.component';
export declare type MatriceSignatureCardContext = {
    groupList: string[];
    userList: string[];
    validatorNumber: number;
    order: string;
};
/**
 * MatriceSignatureCardComponent
 *
 * Live demo:
 * <example-url>/demo/ds-matrice-signature-card.component.html</example-url>
 */
export declare class MatriceSignatureCardComponent implements AfterViewInit, OnChanges {
    className?: string;
    items: AccordionItem<MatriceSignatureCardContext>[];
    /** Items passed to the accordion, with `content` set from the view template. */
    accordionItems: AccordionItem<MatriceSignatureCardContext>[];
    private matriceSignatureCardContent?;
    ngOnChanges(changes: SimpleChanges): void;
    ngAfterViewInit(): void;
    private syncItemsWithTemplate;
}
