import { EventEmitter } from '@angular/core';
/**
 * SchemaSignatureGroupCardComponent
 *
 * Live demo:
 * <example-url>/demo/ds-schema-signature-group-card.component.html</example-url>
 */
export declare class SchemaSignatureGroupCardComponent {
    className?: string;
    groupName?: string;
    numberOfUsers?: number;
    onEdit: EventEmitter<void>;
    onDelete: EventEmitter<void>;
    handleEdit(): void;
    handleDelete(): void;
}
