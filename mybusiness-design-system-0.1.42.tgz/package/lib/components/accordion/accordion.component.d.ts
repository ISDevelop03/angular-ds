import { EventEmitter, OnInit, TemplateRef, SimpleChanges } from '@angular/core';
export declare type AccordionItem<T = any> = {
    id: string;
    title: string;
    caption?: string;
    /** Either a string (HTML) or an Angular `<ng-template>` */
    content: string | TemplateRef<any>;
    buttonTemplate?: string | TemplateRef<any>;
    context?: T;
    count?: string | number;
    countColor?: string;
    open?: boolean;
    prefixTemplate?: string | TemplateRef<any>;
};
declare type Variant = 'default' | 'borderless' | 'shadowless' | 'borderless-reversed';
/**
 * AccordionComponent
 *
 * Live demo:
 * <example-url>/demo/ds-accordion.component.html</example-url>
 */
export declare class AccordionComponent implements OnInit {
    variant: Variant;
    items: AccordionItem[];
    allowMultiple: boolean;
    textClassName: string;
    className: string;
    openHandler: EventEmitter<AccordionItem<any>>;
    localItems: Array<AccordionItem & {
        isOpen: boolean;
    }>;
    /** copy of your theme object from React, trimmed to only the bits we use */
    theme: {
        default: {
            container: string;
            disclosure: string;
            button: {
                base: string;
                title: string;
                active: string;
                titleWrapper: string;
                icon: {
                    base: string;
                    classActive: string;
                    classInactive: string;
                    inactiveId: string;
                    activeId: string;
                    size: string;
                };
            };
            panel: {
                base: string;
            };
        };
        borderless: {
            container: string;
            disclosure: string;
            button: {
                base: string;
                active: string;
                title: string;
                titleWrapper: string;
                icon: {
                    base: string;
                    classActive: string;
                    classInactive: string;
                    inactiveId: string;
                    activeId: string;
                    size: string;
                };
            };
            panel: {
                base: string;
            };
        };
        'borderless-reversed': {
            container: string;
            disclosure: string;
            button: {
                base: string;
                active: string;
                title: string;
                titleWrapper: string;
                icon: {
                    base: string;
                    classActive: string;
                    classInactive: string;
                    inactiveId: string;
                    activeId: string;
                    size: string;
                };
            };
            panel: {
                base: string;
            };
        };
        shadowless: {
            container: string;
            disclosure: string;
            button: {
                base: string;
                title: string;
                active: string;
                titleWrapper: string;
                icon: {
                    base: string;
                    classActive: string;
                    classInactive: string;
                    inactiveId: string;
                    activeId: string;
                    size: string;
                };
            };
            panel: {
                base: string;
            };
        };
    };
    ngOnInit(): void;
    ngOnChanges(changes: SimpleChanges): void;
    private buildLocalItems;
    handleChange(item: AccordionItem & {
        isOpen: boolean;
    }): void;
    getContainerClasses(): string[];
    getDisclosureClasses(isOpen: boolean): string[];
    getButtonClasses(isOpen: boolean): string[];
    getIconId(isOpen: boolean): string;
    getIconClasses(isOpen: boolean): string[];
    getPanelClasses(): string;
    isTemplate(ref: any): ref is TemplateRef<any>;
}
export {};
