export declare type GenericListTextItem = {
    label: string;
    type: 'text';
    value: string;
};
export declare type GenericListListItem = {
    label: string;
    type: 'list-badges';
    value: string[];
};
export declare type GenericListAccountItem = {
    label: string;
    type: 'account';
    value: {
        accountName: string;
        accountNumber: string;
    };
};
export declare type GenericListItem = GenericListTextItem | GenericListListItem | GenericListAccountItem;
/**
 * GenericListComponent
 *
 * Live demo:
 * <example-url>/demo/ds-generic-list.component.html</example-url>
 */
export declare class GenericListComponent {
    className?: string;
    items: GenericListItem[];
}
