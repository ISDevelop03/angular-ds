import { EventEmitter, SimpleChanges, TemplateRef } from '@angular/core';
/**
 * GroupSignataireCheckboxComponent
 *
 * Live demo:
 * <example-url>/demo/ds-group-signataire-checkbox.component.html</example-url>
 */
export declare class GroupSignataireCheckboxComponent {
    className?: string;
    users: string[];
    checked: boolean;
    usersDropdownContent: TemplateRef<any>;
    change: EventEmitter<boolean>;
    toggle: EventEmitter<boolean>;
    getFirstTwoLetters: (title: string) => string;
    isChecked: boolean;
    ngOnChanges(changes: SimpleChanges): void;
    handleCheckboxChange(): void;
    toggleDropdown(event: boolean): void;
}
