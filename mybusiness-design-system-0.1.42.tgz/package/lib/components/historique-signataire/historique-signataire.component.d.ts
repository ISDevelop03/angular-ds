export declare type TAction = {
    actionDate: string;
    actionLabel: string;
    actionAgent: TAgent;
};
export declare type TAgent = {
    name: string;
    role: string;
};
/**
 * HistoriqueSignataireComponent
 *
 * Live demo:
 * <example-url>/demo/ds-historique-signataire.component.html</example-url>
 */
export declare class HistoriqueSignataireComponent {
    className?: string;
    title?: string;
    initiation?: TAction;
    actions?: TAction[];
}
