import { TemplateRef, EventEmitter, QueryList } from '@angular/core';
import { StepButton } from './steps.component';
import { SubStepComponent } from './subStep.component';
/**
 * @ignore
 */
export declare class StepComponent {
    title: string;
    shouldGoNext: boolean;
    shouldGoPrev: boolean;
    data: any;
    leftButtons: StepButton[];
    rightButtons: StepButton[];
    /** Emitted when advancing to a new step */
    nextStep: EventEmitter<{
        button: StepButton;
        event: any;
        data: any;
        currentIndex: number;
    }>;
    /** Emitted when going back to a previous step */
    prevStep: EventEmitter<{
        button: StepButton;
        data: any;
        event: any;
        currentIndex: number;
    }>;
    contentTemplate: TemplateRef<any>;
    /** Nested <ds-sub-step> children projected into this step */
    subSteps: QueryList<SubStepComponent>;
}
