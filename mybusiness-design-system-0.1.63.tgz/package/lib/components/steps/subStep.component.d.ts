import { TemplateRef, EventEmitter } from '@angular/core';
import { StepButton } from './steps.component';
/**
 * Nested step projected inside a parent `ds-step`.
 * `StepComponent` collects these with `@ContentChildren`.
 * @ignore
 */
export declare class SubStepComponent {
    shouldGoNext: boolean;
    shouldGoPrev: boolean;
    data: any;
    leftButtons: StepButton[];
    rightButtons: StepButton[];
    /** Emitted when advancing to a new sub-step */
    nextStep: EventEmitter<{
        button: StepButton;
        event: any;
        data: any;
        currentIndex: number;
    }>;
    /** Emitted when going back to a previous sub-step */
    prevStep: EventEmitter<{
        button: StepButton;
        data: any;
        event: any;
        currentIndex: number;
    }>;
    contentTemplate: TemplateRef<any>;
}
