import { AfterContentInit, ChangeDetectorRef, QueryList } from '@angular/core';
import { OnbordingSlideComponent } from './onbording-slide.component';
/**
 * OnbordingSliderComponent
 *
 * Shows one projected slide at a time. Each `ds-onbording-slide` can host any component.
 *
 * Live demo:
 * <example-url>/demo/ds-onbording-slider.component.html</example-url>
 */
export declare class OnbordingSliderComponent implements AfterContentInit {
    private cd;
    className: string;
    showDots: boolean;
    slides: QueryList<OnbordingSlideComponent>;
    theme: {
        wrapper: string;
        header: string;
        title: string;
        viewport: string;
        track: string;
        slide: string;
        content: string;
        dots: string;
        arrow: string;
        arrowDisabled: string;
        arrowIcon: string;
        arrowIconDisabled: string;
        dot: string;
        dotActive: string;
    };
    activeIndex: number;
    dotIndexes: number[];
    constructor(cd: ChangeDetectorRef);
    ngAfterContentInit(): void;
    readonly slideList: OnbordingSlideComponent[];
    goTo(index: number): void;
    prev(): void;
    next(): void;
    private bindSlides;
    private syncSlides;
}
