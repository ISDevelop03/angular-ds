/**
 * One screen projected into `ds-onbording-slider`.
 * Any component can be placed inside; the slider handles layout and dots.
 * @ignore
 */
export declare class OnbordingSlideComponent {
    private _active;
    private activeFromParent;
    /** Called by the slider when this slide is marked active from the template. */
    onActivated: (() => void) | null;
    theme: {
        wrapper: string;
        /**
         * One screen projected into `ds-onbording-slider`.
         * Any component can be placed inside; the slider handles layout and dots.
         * @ignore
         */
        header: string;
        title: string;
        viewport: string;
        track: string;
        slide: string;
        content: string;
        dots: string;
        arrow: string;
        arrowDisabled: string;
        arrowIcon: string;
        arrowIconDisabled: string;
        dot: string;
        dotActive: string;
    };
    active: boolean;
    readonly hostClass: string;
    setActiveFromParent(value: boolean): void;
}
