export declare const ONBORDING_SLIDER_THEME: {
    default: {
        wrapper: string;
        header: string;
        title: string;
        viewport: string;
        track: string;
        slide: string;
        content: string;
        dots: string;
        arrow: string;
        arrowDisabled: string;
        arrowIcon: string;
        arrowIconDisabled: string;
        dot: string;
        dotActive: string;
    };
};
