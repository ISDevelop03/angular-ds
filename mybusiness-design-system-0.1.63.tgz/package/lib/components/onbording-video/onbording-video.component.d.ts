import { ApplicationRef, ComponentFactoryResolver, Injector, OnDestroy, OnInit, TemplateRef, ViewContainerRef } from '@angular/core';
import { DomSanitizer, SafeResourceUrl } from '@angular/platform-browser';
/**
 * OnbordingVideoComponent
 *
 * Thumbnail with a YouTube play icon. Clicking it opens a 16:9 popup and plays `videoUrl`.
 * YouTube and Vimeo links play in an embed; any other URL plays in a video element.
 *
 * Live demo:
 * <example-url>/demo/ds-onbording-video.component.html</example-url>
 */
export declare class OnbordingVideoComponent implements OnInit, OnDestroy {
    private sanitizer;
    private vcr;
    private cfr;
    private appRef;
    private injector;
    className: string;
    videoUrl: string;
    imageSrc: string;
    imageAlt: string;
    playerTpl: TemplateRef<any>;
    theme: {
        trigger: string;
        image: string;
        play: string;
        backdrop: string;
        overlay: string;
        dialog: string;
        frame: string;
        player: string;
        close: string;
    };
    isOpen: boolean;
    useNativePlayer: boolean;
    safeEmbedUrl: SafeResourceUrl;
    private portalHost;
    private playerPortal;
    private previousBodyOverflow;
    constructor(sanitizer: DomSanitizer, vcr: ViewContainerRef, cfr: ComponentFactoryResolver, appRef: ApplicationRef, injector: Injector);
    ngOnInit(): void;
    ngOnDestroy(): void;
    open(): void;
    close(): void;
    playNative(event: Event): void;
    onEscape(): void;
    private toEmbedUrl;
}
