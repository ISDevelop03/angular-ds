export declare const ONBORDING_VIDEO_THEME: {
    default: {
        trigger: string;
        image: string;
        play: string;
        backdrop: string;
        overlay: string;
        dialog: string;
        frame: string;
        player: string;
        close: string;
    };
};
