import { AfterContentInit, ChangeDetectorRef, EventEmitter, OnDestroy, QueryList } from '@angular/core';
import { OnbordingStepComponent } from './onbording-step.component';
/**
 * OnbordingStepperComponent
 *
 * Vertical stepper. Each `ds-onbording-step` can host any component.
 * The default variant shows the active step, checks earlier steps, and mutes later ones.
 * The `open` variant shows every step and keeps the numbered markers.
 *
 * Live demo:
 * <example-url>/demo/ds-onbording-stepper.component.html</example-url>
 */
export declare class OnbordingStepperComponent implements AfterContentInit, OnDestroy {
    private cd;
    className: string;
    activeIndexChange: EventEmitter<number>;
    steps: QueryList<OnbordingStepComponent>;
    theme: {
        wrapper: string;
        step: string;
        rail: string;
        marker: string;
        markerActive: string;
        markerDone: string;
        markerUpcoming: string;
        line: string;
        body: string;
        bodyLast: string;
        title: string;
        titleActive: string;
        titleDone: string;
        titleUpcoming: string;
        content: string;
        contentHidden: string;
    };
    private _activeIndex;
    private _variant;
    private stepsReady;
    private stepsSub;
    constructor(cd: ChangeDetectorRef);
    activeIndex: number;
    /** `default` tracks progress. `open` shows every step and never marks one complete. */
    variant: string;
    ngAfterContentInit(): void;
    ngOnDestroy(): void;
    readonly stepList: OnbordingStepComponent[];
    goTo(index: number): void;
    prev(): void;
    next(): void;
    private syncSteps;
}
