export declare type OnbordingStepStatus = 'active' | 'done' | 'upcoming' | 'open';
/**
 * One step projected into `ds-onbording-stepper`.
 * Any component can be placed inside. The default variant shows that content
 * on the active step. The open variant shows it on every step.
 * @ignore
 */
export declare class OnbordingStepComponent {
    title: string;
    theme: {
        wrapper: string;
        step: string;
        rail: string;
        marker: string;
        markerActive: string;
        markerDone: string;
        markerUpcoming: string;
        line: string;
        body: string;
        bodyLast: string;
        title: string;
        titleActive: string;
        titleDone: string;
        titleUpcoming: string;
        content: string;
        contentHidden: string;
    };
    /** Set by the stepper. */
    index: number;
    isLast: boolean;
    status: OnbordingStepStatus;
    readonly hostClass: string;
    readonly markerClass: string;
    readonly titleClass: string;
    readonly bodyClass: string;
    readonly contentClass: string;
}
