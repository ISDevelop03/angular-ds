export declare const ONBORDING_STEPPER_THEME: {
    default: {
        wrapper: string;
        step: string;
        rail: string;
        marker: string;
        markerActive: string;
        markerDone: string;
        markerUpcoming: string;
        line: string;
        body: string;
        bodyLast: string;
        title: string;
        titleActive: string;
        titleDone: string;
        titleUpcoming: string;
        content: string;
        contentHidden: string;
    };
};
