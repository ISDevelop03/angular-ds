import { DOCUMENT, CommonModule, registerLocaleData } from '@angular/common';
import { animate, style, transition, trigger, state } from '@angular/animations';
import { Subject } from 'rxjs';
import { NG_VALUE_ACCESSOR, ReactiveFormsModule, FormsModule } from '@angular/forms';
import { Router, RouterModule } from '@angular/router';
import localeFr from '@angular/common/locales/fr';
import { CarouselModule } from 'ngx-owl-carousel-o';
import { DomPortalHost, TemplatePortal, PortalModule } from '@angular/cdk/portal';
import { CodeInputModule } from 'angular-code-input';
import { OverlayModule } from '@angular/cdk/overlay';
import { BsDatepickerModule } from 'ngx-bootstrap/datepicker';
import { Component, Input, EventEmitter, Output, HostListener, ApplicationRef, ChangeDetectorRef, ComponentFactoryResolver, ElementRef, Inject, Injector, TemplateRef, ViewChild, ViewContainerRef, Renderer2, ChangeDetectionStrategy, ViewEncapsulation, forwardRef, ContentChild, ContentChildren, NgModule, LOCALE_ID, Injectable, defineInjectable } from '@angular/core';

/**
 * VirementCardRecapComponent
 *
 * Live demo:
 * <example-url>/demo/ds-virement-card-recap.component.html</example-url>
 */
class VirementCardRecapComponent {
    constructor() {
        this.className = '';
        this.items = [];
    }
}
VirementCardRecapComponent.decorators = [
    { type: Component, args: [{
                selector: 'ds-virement-card-recap',
                template: "<div\n  id=\"ds-virement-card-recap\"\n  [ngClass]=\"[className, 'flex flex-col bg-level-5 rounded p-4']\"\n>\n  <div\n    *ngFor=\"let item of items\"\n    class=\"border-b border-neutral-50 pb-3.5 pt-3.5 first:pt-0 last:pb-0 last:border-b-0\"\n  >\n    <div class=\"flex justify-between items-start mb-2\">\n      <p class=\"text-xs font-medium text-neutral-900\">\n        {{ item.beneficiaryName }}\n      </p>\n      <p class=\"text-xs font-bold text-neutral-900\">\n        {{ item.beneficiaryAccountNumber }}\n      </p>\n    </div>\n    <div class=\"flex justify-between items-center\">\n      <div class=\"flex flex-col gap-y-0.5\">\n        <p class=\"text-xs text-neutral-500\">Motif</p>\n        <p class=\"text-xs font-bold text-neutral-900\">{{ item.motif }}</p>\n      </div>\n      <div class=\"flex flex-col items-end gap-y-0.5\">\n        <p class=\"text-xs text-neutral-500\">Montant</p>\n        <ds-balance-formatter\n          [balance]=\"item.amount.amount\"\n          [currency]=\"item.amount.currency\"\n          [noIcon]=\"true\"\n        ></ds-balance-formatter>\n      </div>\n    </div>\n  </div>\n</div>\n"
            }] }
];
VirementCardRecapComponent.propDecorators = {
    className: [{ type: Input }],
    items: [{ type: Input }]
};

/**
 * VirementCardComponent
 *
 * Live demo:
 * <example-url>/demo/ds-virement-card.component.html</example-url>
 */
class VirementCardComponent {
    constructor() {
        this.className = '';
        this.onSave = new EventEmitter();
        this.onDelete = new EventEmitter();
        this.mode = 'view';
        this.motifValue = '';
        this.amountValue = null;
    }
    toggleEditMode() {
        this.mode = "edit";
    }
    toggleViewMode() {
        this.mode = "view";
    }
    handleSave() {
        this.onSave.emit({ motif: this.motifValue, amount: this.amountValue });
    }
    handleDelete() {
        this.onDelete.emit();
    }
}
VirementCardComponent.decorators = [
    { type: Component, args: [{
                selector: 'ds-virement-card',
                template: "<div id=\"ds-virement-card\" [ngClass]=\"[className, 'bg-level-5 rounded p-4']\">\n  <div *ngIf=\"mode === 'view'\" class=\"flex flex-col gap-y-2\">\n    <div class=\"flex justify-between items-start\">\n      <div class=\"flex flex-col gap-y-2\">\n        <p class=\"text-xs font-medium text-neutral-900\">\n          {{ beneficiaryName }}\n        </p>\n        <p class=\"text-xs font-bold text-neutral-900\">\n          {{ beneficiaryAccountNumber }}\n        </p>\n      </div>\n      <div class=\"flex gap-x-2\">\n        <button (click)=\"toggleEditMode()\">\n          <ds-icon id=\"edit-contained-1\" size=\"16\"></ds-icon>\n        </button>\n        <button (click)=\"handleDelete()\">\n          <ds-icon id=\"trash-02\" size=\"16\"></ds-icon>\n        </button>\n      </div>\n    </div>\n    <div class=\"flex justify-between items-center\">\n      <div class=\"flex flex-col gap-y-0.5\">\n        <p class=\"text-xs text-neutral-500\">Motif</p>\n        <p class=\"text-xs font-bold text-neutral-900\">\n          {{ motif }}\n        </p>\n      </div>\n      <div class=\"flex flex-col items-end gap-y-0.5\">\n        <p class=\"text-xs text-neutral-500\">Montant</p>\n        <ds-balance-formatter\n          [balance]=\"amount?.amount\"\n          [currency]=\"amount?.currency\"\n          [noIcon]=\"true\"\n        ></ds-balance-formatter>\n      </div>\n    </div>\n  </div>\n  <div *ngIf=\"mode === 'edit'\" class=\"flex flex-col gap-y-2\">\n    <div class=\"flex justify-between items-start\">\n      <div class=\"flex flex-col gap-y-2\">\n        <p class=\"text-xs font-medium text-neutral-900\">\n          {{ beneficiaryName }}\n        </p>\n        <p class=\"text-xs font-bold text-neutral-900\">\n          {{ beneficiaryAccountNumber }}\n        </p>\n      </div>\n      <div class=\"flex gap-x-2\">\n        <button (click)=\"toggleViewMode()\">\n          <ds-icon id=\"close-square\" size=\"16\" class=\"text-error-500\"></ds-icon>\n        </button>\n        <button (click)=\"handleSave()\">\n          <ds-icon\n            id=\"tick-circle\"\n            size=\"18\"\n            class=\"text-success-500\"\n          ></ds-icon>\n        </button>\n      </div>\n    </div>\n    <div class=\"flex justify-between items-center gap-x-2\">\n      <ds-input\n        [label]=\"'Motif'\"\n        [value]=\"motifValue\"\n        (onInput)=\"motifValue = $event.target.value\"\n        class=\"flex-1\"\n        placeholder=\"Saisir le motif\"\n      ></ds-input>\n      <ds-input\n        [label]=\"'Montant'\"\n        [value]=\"amountValue\"\n        (onInput)=\"amountValue = $event.target.value\"\n        class=\"flex-1\"\n        placeholder=\"Saisir le montant\"\n      ></ds-input>\n    </div>\n  </div>\n</div>\n"
            }] }
];
VirementCardComponent.propDecorators = {
    className: [{ type: Input }],
    beneficiaryName: [{ type: Input }],
    beneficiaryAccountNumber: [{ type: Input }],
    motif: [{ type: Input }],
    amount: [{ type: Input }],
    onSave: [{ type: Output }],
    onDelete: [{ type: Output }]
};

// theme definitions for ModalComponent (modal variant only)
const theme = {
    overlay: 'fixed inset-0 dark:bg-black/60 bg-black/40 transition-opacity',
    base: 'fixed left-1/2 top-1/2 -translate-x-1/2 -translate-y-1/2 flex items-center justify-center max-w-fit',
    panel: 'mx-auto w-auto max-w-full h-auto overflow-hidden dark:bg-black bg-white rounded p-6 pt-7 h-fit flex items-start gap-x-5',
};

/**
 * ModalComponent
 *
 * Live demo:
 * <example-url>/demo/ds-modal.component.html</example-url>
 */
class ModalComponent {
    constructor() {
        this.isShown = false;
        this.icon = '';
        this.type = 'info';
        this.className = '';
        this.close = new EventEmitter();
        this.mainActionOnClick = new EventEmitter();
        this.secondaryActionOnClick = new EventEmitter();
        this.theme = theme;
    }
    onEscPressed(_event) {
        if (this.isShown) {
            this.close.emit();
        }
    }
    onClose() {
        this.isShown = false;
        this.close.emit();
    }
    onBackdropClick(event) {
        if (event.target.classList.contains('popup-overlay')) {
            this.close.emit();
        }
    }
    onSecondaryActionOnClick() {
        this.secondaryActionOnClick.emit();
    }
    onMainActionOnClick() {
        this.mainActionOnClick.emit();
    }
}
ModalComponent.decorators = [
    { type: Component, args: [{
                selector: 'ds-modal',
                template: "<div\n  id=\"ds-modal\"\n  *ngIf=\"isShown\"\n  class=\"fixed inset-0 z-[1001]\"\n  [ngClass]=\"[className]\"\n>\n  <!-- Backdrop -->\n  <div\n    class=\"popup-overlay\"\n    [ngClass]=\"theme.overlay\"\n    (click)=\"onBackdropClick($event)\"\n  ></div>\n\n  <!-- Modal panel -->\n  <div class=\"absolute\" [ngClass]=\"[theme.base]\">\n    <div [ngClass]=\"[theme.panel, 'animate-fadeInScale']\">\n      <button (click)=\"onClose()\" class=\"absolute top-2 right-2\">\n        <ds-icon id=\"close\" size=\"24px\"></ds-icon>\n      </button>\n      <div\n        *ngIf=\"icon\"\n        class=\"flex items-center justify-center p-2 rounded-full mb-3.5\"\n        [ngClass]=\"\n          type === 'success'\n            ? 'bg-green-100'\n            : type === 'warning'\n              ? 'bg-amber-100'\n              : type === 'error'\n                ? 'bg-red-100'\n                : 'bg-blue-100'\n        \"\n      >\n        <ds-icon\n          [id]=\"icon\"\n          size=\"1.25rem\"\n          [ngClass]=\"\n            type === 'success'\n              ? 'text-green-500'\n              : type === 'warning'\n                ? 'text-amber-500'\n                : type === 'error'\n                  ? 'text-red-500'\n                  : 'text-blue-500'\n          \"\n        ></ds-icon>\n      </div>\n      <div>\n        <h2 *ngIf=\"title\" class=\"text-[1.25rem]/[1.5rem] font-bold mb-1\">\n          {{ title }}\n        </h2>\n        <p *ngIf=\"description\" class=\"text-neutral-500 text-sm\">\n          {{ description }}\n        </p>\n        <div class=\"flex items-center justify-start gap-2 mt-4\">\n          <ds-button\n            *ngIf=\"secondaryAction\"\n            variant=\"secondary\"\n            size=\"small\"\n            (click)=\"onSecondaryActionOnClick()\"\n            class=\"text-neutral-500 text-sm\"\n          >\n            {{ secondaryAction }}\n          </ds-button>\n          <ds-button\n            *ngIf=\"mainAction\"\n            variant=\"primary\"\n            size=\"small\"\n            (click)=\"onMainActionOnClick()\"\n            class=\"text-primary-500 text-sm\"\n          >\n            {{ mainAction }}\n          </ds-button>\n        </div>\n      </div>\n    </div>\n  </div>\n</div>\n"
            }] }
];
ModalComponent.propDecorators = {
    isShown: [{ type: Input }],
    icon: [{ type: Input }],
    type: [{ type: Input }],
    title: [{ type: Input }],
    description: [{ type: Input }],
    mainAction: [{ type: Input }],
    secondaryAction: [{ type: Input }],
    className: [{ type: Input }],
    close: [{ type: Output }],
    mainActionOnClick: [{ type: Output }],
    secondaryActionOnClick: [{ type: Output }],
    onEscPressed: [{ type: HostListener, args: ['document:keydown.escape', ['$event'],] }]
};

// theme definitions for InputPhoneComponent
const theme$1 = {
    default: {
        container: 'relative w-full',
        wrapper: {
            base: 'border relative bg-level-4 h-[40px] flex flex-grow items-center gap-3 px-3 w-full rounded',
            enabled: 'border-stroke-1 hover:border-primary-500 focus-within:!border-primary-500',
            disabled: 'border-neutral-100 bg-neutral-100 [&_input]:!text-neutral-500 cursor-not-allowed ',
        },
        label: 'inline-block text-neutral-900 font-normal text-[0.75rem]/[0.875rem] mb-0',
        input: 'text-xs font-bold w-full text-gray-800 dark:text-white bg-transparent appearance-none dark:placeholder-gray-300 placeholder-gray-400 placeholder-text-sm placeholder:font-medium outline-none border-none focus:ring-0 p-0',
        prefix: 'mr-1 text-gray-500',
        sufix: 'ml-1 text-gray-500',
        errorMessage: 'text-error-500 text-xs mt-1',
        hasError: '!border-red-500 [&_input]:!text-red-500 [&_input]:placeholder:!text-red-500/50 hover:border-red-600 focus-within:!border-red-400',
        description: 'text-xs text-gray-500 mt-1',
    },
};

/**
 * InputPhoneComponent
 *
 * Live demo:
 * <example-url>/demo/ds-input-phone.component.html</example-url>
 */
class InputPhoneComponent {
    constructor() {
        this.className = '';
        this.countriesPrefixes = [];
        this.placeholder = 'Enter your phone number';
        this.selectedCountryPrefix = "+212";
        this.value = null;
        this.onChange = new EventEmitter();
        this.theme = theme$1.default;
        this.phoneNumber = null;
    }
    onCountryChange(event) {
        this.selectedCountryPrefix = event;
    }
    onPhoneNumberChange(event) {
        this.phoneNumber = event.target.value;
        this.onChange.emit(this.selectedCountryPrefix.concat(this.phoneNumber));
    }
}
InputPhoneComponent.decorators = [
    { type: Component, args: [{
                selector: 'ds-input-phone',
                template: "<div id=\"ds-input-phone\" [ngClass]=\"className\">\n  <div class=\"flex items-center gap-2 mb-2\">\n    <label [ngClass]=\"['shrink-0', theme.label || '']\">\n      {{ label }}\n      <span *ngIf=\"required\" class=\"text-red-500\">*</span>\n    </label>\n    <ds-tooltip *ngIf=\"tooltip\" [content]=\"tooltip\" position=\"right\">\n      <ds-icon id=\"info-circle\" class=\"size-4\"></ds-icon>\n    </ds-tooltip>\n  </div>\n  <div class=\"flex gap-x-2 w-full\">\n    <ds-select\n      [items]=\"countriesPrefixes\"\n      [value]=\"selectedCountryPrefix\"\n      (valueChange)=\"onCountryChange($event)\"\n      [hasError]=\"hasError\"\n    >\n    </ds-select>\n    <ds-input\n      [placeholder]=\"placeholder\"\n      [value]=\"phoneNumber\"\n      (input)=\"onPhoneNumberChange($event)\"\n      class=\"w-full\"\n      [hasError]=\"hasError\"\n    ></ds-input>\n  </div>\n  <div *ngIf=\"description\" [ngClass]=\"theme.description\">\n    {{ description }}\n  </div>\n\n  <div *ngIf=\"hasError && errorMessage\" [ngClass]=\"theme.errorMessage\">\n    {{ errorMessage }}\n  </div>\n</div>\n"
            }] }
];
InputPhoneComponent.propDecorators = {
    className: [{ type: Input }],
    label: [{ type: Input }],
    tooltip: [{ type: Input }],
    required: [{ type: Input }],
    hasError: [{ type: Input }],
    errorMessage: [{ type: Input }],
    description: [{ type: Input }],
    countriesPrefixes: [{ type: Input }],
    placeholder: [{ type: Input }],
    selectedCountryPrefix: [{ type: Input }],
    value: [{ type: Input }],
    onChange: [{ type: Output }]
};

/**
 * IllustrationComponent
 *
 * Live demo:
 * <example-url>/demo/ds-illustration.component.html</example-url>
 */
class IllustrationComponent {
    constructor() {
        this.className = '';
        this.src = '';
        this.size = 'lg';
    }
    get dimensions() {
        return this.size === 'lg' ?
            { width: 300, height: 224 } : this.size === 'md' ? { width: 200, height: 126 } : this.size === 'sm' ? { width: 170, height: 127 } : { width: 120, height: 90 };
    }
}
IllustrationComponent.decorators = [
    { type: Component, args: [{
                selector: 'ds-illustration',
                template: "<div id=\"ds-illustration\" [ngClass]=\"className\">\n  <img [src]=\"src\" [width]=\"dimensions.width\" [height]=\"dimensions.height\" />\n</div>"
            }] }
];
IllustrationComponent.propDecorators = {
    className: [{ type: Input }],
    src: [{ type: Input }],
    size: [{ type: Input }]
};

/**
 * PriceFilterComponent
 *
 * Live demo:
 * <example-url>/demo/ds-price-filter.component.html</example-url>
 */
class PriceFilterComponent {
    constructor(cd, vcr, cfr, appRef, injector, document) {
        this.cd = cd;
        this.vcr = vcr;
        this.cfr = cfr;
        this.appRef = appRef;
        this.injector = injector;
        this.document = document;
        this.className = '';
        this.showOptions = true;
        this.value = null;
        this.onSelect = new EventEmitter();
        this.isOpen = false;
        this.menuStyles = {};
        this.selectedType = 'credit';
        this.selectedPrice = null;
        this.displayPrice = '';
        this.placeholder = '';
        this.handleOutsideClick = (e) => {
            const tgt = e.target;
            if (this.isOpen &&
                !this.trigger.nativeElement.contains(tgt) &&
                this.menu &&
                !this.menu.nativeElement.contains(tgt)) {
                this.closeMenu();
            }
        };
    }
    logDisplayPrice() {
        console.log('displayPrice:', this.displayPrice);
    }
    ngOnChanges(changes) {
        if (changes['value']) {
            this.selectedPrice = this.value != null ? this.value : null;
            this.displayPrice = this.value != null ? this.formatPrice(this.value) : '';
            this.placeholder = this.value != null ? this.formatPrice(this.value) : '';
        }
    }
    ngOnInit() {
        this.portalHost = new DomPortalHost(this.document.body, this.cfr, this.appRef, this.injector);
        document.addEventListener('click', this.handleOutsideClick, true);
        this.logDisplayPrice();
    }
    ngOnDestroy() {
        document.removeEventListener('click', this.handleOutsideClick, true);
        this.portalHost.detach();
    }
    toggleMenu() {
        if (!this.isOpen) {
            this.menuPortal = new TemplatePortal(this.menuTpl, this.vcr);
            if (this.portalHost.hasAttached()) {
                this.portalHost.detach();
            }
            this.portalHost.attach(this.menuPortal);
            this.menuStyles = {
                position: 'fixed',
                visibility: 'hidden',
                top: '0px',
                left: '0px',
                zIndex: `${++PriceFilterComponent.zIndexCounter}`,
            };
            this.isOpen = true;
            this.cd.detectChanges();
            this.setMenuPosition();
            this.menuStyles.visibility = 'visible';
        }
        else {
            this.closeMenu();
        }
    }
    setMenuPosition() {
        const t = this.trigger.nativeElement.getBoundingClientRect();
        const mEl = this.menu.nativeElement;
        const mW = mEl.offsetWidth, mH = mEl.offsetHeight;
        const vw = window.innerWidth, vh = window.innerHeight;
        let top = t.bottom;
        if (t.bottom + mH > vh) {
            top = t.top - mH;
        }
        top = Math.max(0, top);
        let left = t.left;
        if (t.left + mW > vw) {
            left = t.right - mW;
        }
        left = Math.max(0, left);
        Object.assign(this.menuStyles, {
            top: `${top}px`,
            left: `${left}px`,
        });
    }
    closeMenu() {
        if (this.portalHost.hasAttached()) {
            this.portalHost.detach();
        }
        this.isOpen = false;
        this.menuStyles = {};
    }
    onItemClick(event, cb) {
        if (cb) {
            cb(event);
        }
        this.closeMenu();
    }
    formatPrice(value) {
        const num = typeof value === 'string' ? parseFloat(value) : value;
        if (isNaN(num))
            return '';
        return num
            .toLocaleString('de-DE', {
            minimumFractionDigits: 2,
            maximumFractionDigits: 2,
        })
            .replace(/\./g, ' ');
    }
    onPriceKeydown(event) {
        const allowedKeys = [
            'Backspace',
            'Delete',
            'Tab',
            'Escape',
            'Enter',
            'ArrowLeft',
            'ArrowRight',
            'ArrowUp',
            'ArrowDown',
            'Home',
            'End',
        ];
        // Allow navigation keys
        if (allowedKeys.includes(event.key)) {
            return;
        }
        // Allow Ctrl/Cmd combinations (copy, paste, select all, etc.)
        if (event.ctrlKey || event.metaKey) {
            return;
        }
        // Allow digits and comma (decimal separator)
        if (/^[0-9,]$/.test(event.key)) {
            return;
        }
        // Block everything else
        event.preventDefault();
    }
    onPriceInput(event) {
        const input = event.target;
        let rawValue = input.value.replace(/[^\d,]/g, '');
        const parts = rawValue.split(',');
        let integerPart = parts[0].replace(/^0+/, '') || '';
        let decimalPart = parts[1] ? parts[1].slice(0, 2) : '';
        integerPart = Number(integerPart).toLocaleString('fr-FR').replace(/\u202f/g, ' ');
        this.displayPrice =
            decimalPart !== undefined && parts.length > 1
                ? `${integerPart},${decimalPart}`
                : integerPart;
        const numericValue = parseFloat(`${parts[0]}.${decimalPart || ''}`);
        this.selectedPrice = isNaN(numericValue) ? null : numericValue;
        input.value = this.displayPrice;
    }
    clearSelection() {
        this.selectedPrice = null;
        this.displayPrice = '';
        this.placeholder = '';
        this.onSelect.emit(null);
    }
    handleSelect() {
        if (this.selectedPrice) {
            this.placeholder = this.formatPrice(this.selectedPrice);
        }
        if (this.showOptions) {
            this.onSelect.emit({
                type: this.selectedType,
                price: this.selectedPrice,
            });
        }
        else {
            this.onSelect.emit(this.selectedPrice);
        }
        this.closeMenu();
    }
    stopEvent(event) {
        event.stopPropagation();
    }
}
PriceFilterComponent.zIndexCounter = 10000;
PriceFilterComponent.decorators = [
    { type: Component, args: [{
                selector: 'ds-price-filter',
                template: "<div id=\"ds-price-filter\" [ngClass]=\"className\">\n  <button #trigger (click)=\"toggleMenu()\">\n    <div class=\"flex items-center gap-2 border border-neutral-100 bg-level-3 hover:border-primary rounded-md px-3 py-2\">\n      <ds-icon id=\"coins\" class=\"text-red-500\" size=\"20px\"></ds-icon>\n      <span *ngIf=\"placeholder\" class=\"text-neutral-900 font-bold text-[0.75rem]/normal\">\n        {{ placeholder }}\n      </span>\n      <span *ngIf=\"!placeholder\" class=\"text-neutral-900 font-medium text-[0.75rem]/normal\">\n        Montant\n      </span>\n      <ds-icon *ngIf=\"!displayPrice\" id=\"arrow-down\" [class]=\"[\n          'transition-all duration-500 ease-in-out',\n          isOpen ? '-rotate-180' : ''\n        ]\"></ds-icon>\n      <ds-icon *ngIf=\"displayPrice\" id=\"close\" class=\"text-neutral-900 cursor-pointer\"\n        (click)=\"clearSelection()\"></ds-icon>\n    </div>\n  </button>\n\n  <ng-template #menuTpl>\n    <div #menu @dropdownAnim\n      class=\"absolute mt-2 min-w-[350px] origin-top-right focus:outline-none rounded-lg p-4 border border-stroke-1 bg-level-3\"\n      style=\"box-shadow: 6px 6px 54px 0px rgba(0, 0, 0, 0.14)\" [ngStyle]=\"menuStyles\">\n      <div *ngIf=\"showOptions\" class=\"flex items-center gap-4 mb-4\">\n        <ds-radio name=\"group1\" value=\"debit\" label=\"Debit\" [(modelValue)]=\"selectedType\" variant=\"default\"></ds-radio>\n        <ds-radio name=\"group1\" value=\"credit\" label=\"Credit\" [(modelValue)]=\"selectedType\"\n          variant=\"default\"></ds-radio>\n      </div>\n      <div class=\"flex items-end gap-2\">\n        <div class=\"flex-1\">\n          <ds-input placeholder=\"Entrer un montant exact\" type=\"text\" label=\"Chercher un montant exact\"\n            className=\"w-full\" [value]=\"displayPrice\" (onInput)=\"onPriceInput($event)\"\n            (onKeydown)=\"onPriceKeydown($event)\"></ds-input>\n        </div>\n        <ds-button variant=\"primary\" (click)=\"handleSelect()\" [disabled]=\"!selectedPrice\">\n          Valider\n        </ds-button>\n      </div>\n    </div>\n  </ng-template>\n</div>",
                animations: [
                    trigger('dropdownAnim', [
                        // enter: from nothing → visible
                        transition(':enter', [
                            style({ opacity: 0, transform: 'scale(0.95)' }),
                            animate('120ms ease-out', style({ opacity: 1, transform: 'scale(1)' })),
                        ]),
                        // leave: from visible → nothing
                        transition(':leave', [
                            animate('100ms ease-in', style({ opacity: 0, transform: 'scale(0.95)' })),
                        ]),
                    ]),
                ]
            }] }
];
/** @nocollapse */
PriceFilterComponent.ctorParameters = () => [
    { type: ChangeDetectorRef },
    { type: ViewContainerRef },
    { type: ComponentFactoryResolver },
    { type: ApplicationRef },
    { type: Injector },
    { type: undefined, decorators: [{ type: Inject, args: [DOCUMENT,] }] }
];
PriceFilterComponent.propDecorators = {
    className: [{ type: Input }],
    showOptions: [{ type: Input }],
    value: [{ type: Input }],
    onSelect: [{ type: Output }],
    trigger: [{ type: ViewChild, args: ['trigger',] }],
    menuTpl: [{ type: ViewChild, args: ['menuTpl',] }],
    menu: [{ type: ViewChild, args: ['menu',] }],
    stopEvent: [{ type: HostListener, args: ['click', ['$event'],] }]
};

/**
 * LoaderComponent
 *
 * Live demo:
 * <example-url>/demo/ds-loader.component.html</example-url>
 */
class LoaderComponent {
    constructor() {
        this.className = '';
        this.showLoader = true;
        this.showOverlay = true;
        this.type = 'contained';
    }
}
LoaderComponent.decorators = [
    { type: Component, args: [{
                selector: 'ds-loader',
                template: "<div id=\"ds-loader\" [ngClass]=\"className\">\n  <div\n    *ngIf=\"showLoader\"\n    [ngClass]=\"\n      type === 'fill' ? 'loader-wrapper-fill' : 'loader-wrapper-contained'\n    \"\n  >\n    <div *ngIf=\"showOverlay\" class=\"loader-overlay\"></div>\n    <div class=\"loader-spinner\"></div>\n  </div>\n</div>\n",
                styles: [".loader-wrapper-fill{position:fixed;top:0;left:0;width:100vw;height:100vh;z-index:9999;display:flex;justify-content:center;align-items:center}.loader-wrapper-contained{position:absolute;width:100%;height:100%;z-index:9999;display:flex;justify-content:center;align-items:center}.loader-overlay{position:relative;top:0;left:0;width:100%;height:100%;background-color:#000;opacity:.2}.loader-spinner{position:absolute;width:60px;height:60px;border:8px solid #f3f3f3;border-top:8px solid #fb2c36;border-radius:50%;animation:1s linear infinite spin}@keyframes spin{0%{transform:rotate(0)}100%{transform:rotate(360deg)}}"]
            }] }
];
LoaderComponent.propDecorators = {
    className: [{ type: Input }],
    showLoader: [{ type: Input }],
    showOverlay: [{ type: Input }],
    type: [{ type: Input }]
};

/**
 * SignataireListComponent
 *
 * Live demo:
 * <example-url>/demo/ds-signataire-list.component.html</example-url>
 */
class SignataireListComponent {
    constructor() {
        this.items = [];
        this.className = '';
    }
}
SignataireListComponent.decorators = [
    { type: Component, args: [{
                selector: 'ds-signataire-list',
                template: "<div\n  id=\"ds-signataire-list\"\n  [ngClass]=\"className\"\n  class=\"flex flex-col gap-y-2 divide-y divide-neutral-50 bg-neutral-25 p-4 rounded\"\n>\n  <div\n    *ngFor=\"let item of items\"\n    class=\"flex justify-between gap-y-3 pt-2 first:pt-0\"\n  >\n    <div class=\"flex flex-col gap-y-1\">\n      <p class=\"text-neutral-500 font-medium text-[0.725rem]/[1rem]\">\n        {{ item.label }}\n      </p>\n      <p class=\"text-neutral-900 font-bold text-[0.875rem]/[1.125rem]\">\n        {{ item.value }}\n      </p>\n    </div>\n    <div class=\"flex flex-col items-end gap-y-1\">\n      <p class=\"text-neutral-500 font-medium text-[0.725rem]/[1rem]\">\n        {{ item.dateLabel }}\n      </p>\n      <p class=\"text-neutral-900 text-[0.875rem]/[1.125rem]\">\n        {{ item.dateValue }}\n      </p>\n    </div>\n  </div>\n</div>\n"
            }] }
];
SignataireListComponent.propDecorators = {
    items: [{ type: Input }],
    className: [{ type: Input }]
};

/**
 * LayerComponent
 *
 * Live demo:
 * <example-url>/demo/ds-layer.component.html</example-url>
 */
class LayerComponent {
    constructor() {
        this.className = '';
        this.isOpen = false;
        this.isOpenChange = new EventEmitter();
    }
    onClose() {
        this.isOpen = false;
        this.isOpenChange.emit(false);
    }
}
LayerComponent.decorators = [
    { type: Component, args: [{
                selector: 'ds-layer',
                template: "<div\n  *ngIf=\"isOpen\"\n  @slideInOut\n  id=\"ds-layer\"\n  class=\"relative bg-level-3 rounded-lg p-6 w-full\"\n  [ngClass]=\"className\"\n>\n  <ds-icon\n    id=\"close\"\n    size=\"20px\"\n    class=\"absolute top-0.5 right-0.5 cursor-pointer\"\n    (click)=\"onClose()\"\n  ></ds-icon>\n  <ng-content></ng-content>\n</div>\n",
                animations: [
                    trigger('slideInOut', [
                        transition(':enter', [
                            style({ opacity: 0, transform: 'translateY(-20px)' }),
                            animate('200ms ease-out', style({ opacity: 1, transform: 'translateY(0)' })),
                        ]),
                        transition(':leave', [
                            animate('200ms ease-in', style({ opacity: 0, transform: 'translateY(-20px)' })),
                        ]),
                    ]),
                ]
            }] }
];
LayerComponent.propDecorators = {
    className: [{ type: Input }],
    isOpen: [{ type: Input }],
    isOpenChange: [{ type: Output }]
};

/**
 * BoxCheckboxComponent
 *
 * Live demo:
 * <example-url>/demo/ds-box-checkbox.component.html</example-url>
 */
class BoxCheckboxComponent {
    constructor() {
        this.className = '';
        this.checked = false;
        this.disabled = false;
        this.change = () => { };
    }
}
BoxCheckboxComponent.decorators = [
    { type: Component, args: [{
                selector: 'ds-box-checkbox',
                template: "<div\n  id=\"ds-box-checkbox\"\n  class=\"bg-level-3 flex items-center justify-between border border-stroke-1 rounded-md p-2\"\n  [ngClass]=\"className\"\n>\n  <ds-checkbox\n    [checked]=\"checked\"\n    [disabled]=\"disabled\"\n    [label]=\"label\"\n  ></ds-checkbox>\n  <ds-tooltip *ngIf=\"tooltip\" [content]=\"tooltip\" position=\"right\">\n    <ds-icon id=\"info-circle\" class=\"size-4\"></ds-icon>\n  </ds-tooltip>\n</div>\n"
            }] }
];
BoxCheckboxComponent.propDecorators = {
    className: [{ type: Input }],
    checked: [{ type: Input }],
    disabled: [{ type: Input }],
    label: [{ type: Input }],
    tooltip: [{ type: Input }],
    change: [{ type: Input }]
};

// theme definitions for TooltipComponent
const defaultTheme = {
    base: 'w-max max-w-[300px] absolute z-[9999] px-3 py-2 text-sm font-medium text-white bg-neutral-900 dark:bg-[#000000] dark:bg-neutral-800 rounded-lg shadow-tooltip pointer-events-none',
    positions: {
        top: 'bottom-full left-1/2 !-translate-x-1/2 mb-2',
        topRight: 'bottom-full right-0 mb-2',
        topLeft: 'bottom-full left-0 mb-2',
        bottom: 'top-full left-1/2 !-translate-x-1/2 mt-2',
        bottomRight: 'top-full right-0 mt-2',
        bottomLeft: 'top-full left-0 mt-2',
        left: 'right-full top-1/2 !-translate-y-1/2 mr-2',
        right: 'left-full top-1/2 !-translate-y-1/2 ml-2',
    },
    arrow: {
        base: 'absolute w-0 h-0',
        positions: {
            top: 'top-full left-1/2 !-translate-x-1/2 -translate-y-[1px] border-l-[6px] border-r-[6px] border-t-[6px] border-l-transparent border-r-transparent border-t-neutral-900 dark:border-t-[#000000]',
            topRight: 'top-full right-3 -translate-y-[1px] border-l-[6px] border-r-[6px] border-t-[6px] border-l-transparent border-r-transparent border-t-neutral-900 dark:border-t-[#000000]',
            topLeft: 'top-full left-3 -translate-y-[1px] border-l-[6px] border-r-[6px] border-t-[6px] border-l-transparent border-r-transparent border-t-neutral-900 dark:border-t-[#000000]',
            bottom: 'bottom-full left-1/2 !-translate-x-1/2 translate-y-[1px] border-l-[6px] border-r-[6px] border-b-[6px] border-l-transparent border-r-transparent border-b-neutral-900 dark:border-b-[#000000]',
            bottomRight: 'bottom-full right-3 translate-y-[1px] border-l-[6px] border-r-[6px] border-b-[6px] border-l-transparent border-r-transparent border-b-neutral-900 dark:border-b-[#000000]',
            bottomLeft: 'bottom-full left-3 translate-y-[1px] border-l-[6px] border-r-[6px] border-b-[6px] border-l-transparent border-r-transparent border-b-neutral-900 dark:border-b-[#000000]',
            left: 'left-full top-1/2 !-translate-y-1/2 -translate-x-[1px] border-t-[6px] border-b-[6px] border-l-[6px] border-t-transparent border-b-transparent border-l-neutral-900 dark:border-l-[#000000]',
            right: 'right-full top-1/2 !-translate-y-1/2 translate-x-[1px] border-t-[6px] border-b-[6px] border-r-[6px] border-t-transparent border-b-transparent border-r-neutral-900 dark:border-r-[#000000]',
        },
    },
};

/**
 * TooltipComponent
 *
 * Live demo:
 * <example-url>/demo/ds-tooltip.component.html</example-url>
 */
class TooltipComponent {
    constructor(el, renderer, cdr) {
        this.el = el;
        this.renderer = renderer;
        this.cdr = cdr;
        this.position = 'top';
        this.className = '';
        this.disabled = false;
        this.delay = 200;
        this.style = {};
        this.isVisible = false;
        this.defaultTheme = defaultTheme;
    }
    ngOnInit() {
        // Set up the wrapper element
        const nativeElement = this.el.nativeElement;
        this.renderer.setStyle(nativeElement, 'position', 'relative');
        this.renderer.setStyle(nativeElement, 'display', 'inline-block');
    }
    ngAfterViewChecked() {
        this.applyStylesToTooltip();
    }
    applyStylesToTooltip() {
        const tooltipElement = this.el.nativeElement.querySelector('#ds-tooltip');
        if (tooltipElement) {
            for (const key in this.style) {
                if (this.style[key]) {
                    this.renderer.setStyle(tooltipElement, key, this.style[key]);
                }
            }
        }
    }
    ngOnDestroy() {
        this.clearTimeout();
    }
    // Use the provided theme or fall back to the default one
    get appliedTheme() {
        return this.theme || this.defaultTheme;
    }
    // Compute the CSS class string
    get computedClass() {
        const theme = this.appliedTheme;
        const classes = [];
        classes.push(theme.base);
        classes.push(theme.positions[this.position]);
        if (this.className) {
            classes.push(this.className);
        }
        return classes.join(' ');
    }
    get animationState() {
        return this.isVisible ? 'visible' : 'hidden';
    }
    get arrowClass() {
        const theme = this.appliedTheme;
        return `${theme.arrow.base} ${theme.arrow.positions[this.position]}`;
    }
    get isStringContent() {
        return typeof this.content === 'string';
    }
    onMouseEnter(event) {
        if (!this.disabled) {
            this.clearTimeout();
            this.timeoutId = setTimeout(() => {
                this.showTooltip();
            }, this.delay);
        }
    }
    onMouseLeave(event) {
        this.clearTimeout();
        this.hideTooltip();
    }
    onFocusIn(event) {
        if (!this.disabled) {
            this.clearTimeout();
            this.timeoutId = setTimeout(() => {
                this.showTooltip();
            }, this.delay);
        }
    }
    onFocusOut(event) {
        this.clearTimeout();
        this.hideTooltip();
    }
    showTooltip() {
        if (!this.disabled) {
            this.isVisible = true;
            this.cdr.detectChanges();
            // Apply styles after tooltip becomes visible
            setTimeout(() => this.applyStylesToTooltip(), 0);
        }
    }
    hideTooltip() {
        this.isVisible = false;
        this.cdr.detectChanges();
    }
    clearTimeout() {
        if (this.timeoutId) {
            clearTimeout(this.timeoutId);
            this.timeoutId = null;
        }
    }
}
TooltipComponent.decorators = [
    { type: Component, args: [{
                selector: 'ds-tooltip',
                template: "<div class=\"relative w-fit flex items-center justify-center\">\n  <ng-content></ng-content>\n  <div\n    id=\"ds-tooltip\"\n    *ngIf=\"content\"\n    [@tooltipAnim]=\"animationState\"\n    [ngClass]=\"computedClass\"\n    [attr.aria-hidden]=\"!isVisible\"\n    role=\"tooltip\"\n  >\n    <div class=\"block\">\n      <ng-container *ngIf=\"isStringContent; else templateRef\">\n        {{ content }}\n      </ng-container>\n      <ng-template #templateRef>\n        <ng-container *ngTemplateOutlet=\"content\" class=\"flex items-center justify-center\"></ng-container>\n      </ng-template>\n    </div>\n    <div [ngClass]=\"arrowClass\"></div>\n  </div>\n</div>\n",
                animations: [
                    trigger('tooltipAnim', [
                        state('hidden', style({ opacity: 0, transform: 'scale(0.95)' })),
                        state('visible', style({ opacity: 1, transform: 'scale(1)' })),
                        transition('hidden => visible', [
                            animate('150ms ease-out'),
                        ]),
                        transition('visible => hidden', [
                            animate('100ms ease-in'),
                        ]),
                    ]),
                ]
            }] }
];
/** @nocollapse */
TooltipComponent.ctorParameters = () => [
    { type: ElementRef },
    { type: Renderer2 },
    { type: ChangeDetectorRef }
];
TooltipComponent.propDecorators = {
    content: [{ type: Input }],
    position: [{ type: Input }],
    className: [{ type: Input }],
    disabled: [{ type: Input }],
    delay: [{ type: Input }],
    theme: [{ type: Input }],
    style: [{ type: Input }],
    onMouseEnter: [{ type: HostListener, args: ['mouseenter', ['$event'],] }],
    onMouseLeave: [{ type: HostListener, args: ['mouseleave', ['$event'],] }],
    onFocusIn: [{ type: HostListener, args: ['focusin', ['$event'],] }],
    onFocusOut: [{ type: HostListener, args: ['focusout', ['$event'],] }]
};

/**
 * TotalListComponent
 *
 * Live demo:
 * <example-url>/demo/ds-total-list.component.html</example-url>
 */
class TotalListComponent {
    constructor() {
        this.className = '';
        this.label = '';
        this.value = '';
        this.icon = '';
    }
}
TotalListComponent.decorators = [
    { type: Component, args: [{
                selector: 'ds-total-list',
                template: "<div\n  id=\"ds-display-price-card\"\n  [ngClass]=\"className\"\n  class=\"py-3 px-4 bg-crame-100 border border-crame-300 rounded-[4px] flex items-center justify-between gap-5\"\n>\n  <span class=\"inline-flex text-[0.875rem] font-bold text-neutral-900\">\n    {{ label }}\n  </span>\n  <p\n    class=\"flex items-center gap-1.5 text-[1.25rem] font-bold text-neutral-900\"\n  >\n    <span>{{ value }}</span>\n    <ds-icon [id]=\"icon\" size=\"24px\" class=\"text-crame-500\"></ds-icon>\n  </p>\n</div>"
            }] }
];
TotalListComponent.propDecorators = {
    className: [{ type: Input }],
    label: [{ type: Input }],
    value: [{ type: Input }],
    icon: [{ type: Input }]
};

/**
 * FileListComponent
 *
 * Live demo:
 * <example-url>/demo/ds-file-list.component.html</example-url>
 */
class FileListComponent {
    constructor() {
        this.className = '';
        this.files = [];
        this.isMultiple = false;
        this.isDownloadable = false;
        this.maxHeight = undefined;
        this.showErrorButtonUpload = false;
        this.onDelete = new EventEmitter();
        this.onReUpload = new EventEmitter();
        this.onDownload = new EventEmitter();
        this.onDownloadErrors = new EventEmitter();
        this.errorVisibilityMap = new Map();
    }
    isErrorVisible(fileId) {
        return this.errorVisibilityMap.get(fileId) || false;
    }
    toggleErrors(fileId) {
        const currentState = this.errorVisibilityMap.get(fileId) || false;
        this.errorVisibilityMap.set(fileId, !currentState);
    }
    removeFile(fileId) {
        this.onDelete.emit(fileId);
    }
    // reUploadFile(fileId:string) {
    //   this.onReUpload.emit(fileId)
    // }
    downloadFile(file) {
        if (this.onDownload.observers.length > 0) {
            this.onDownload.emit(file);
        }
        else {
            const blob = new Blob([file], { type: file.type });
            const blobUrl = URL.createObjectURL(blob);
            const link = document.createElement('a');
            link.href = blobUrl;
            link.download = file.name;
            document.body.appendChild(link);
            link.click();
            document.body.removeChild(link);
            URL.revokeObjectURL(blobUrl);
        }
    }
    formatFileSize(sizeInBytes) {
        const sizeInMB = sizeInBytes / 1024 / 1024;
        if (sizeInMB < 1) {
            const sizeInKB = sizeInBytes / 1024;
            return `${sizeInKB.toFixed(2)} Ko`;
        }
        return `${sizeInMB.toFixed(2)} Mo`;
    }
}
FileListComponent.decorators = [
    { type: Component, args: [{
                selector: 'ds-file-list',
                template: "<div\n  id=\"ds-file-list\"\n  [ngClass]=\"className\"\n  [style.maxHeight]=\"maxHeight + 'px'\"\n  [style.overflowY]=\"maxHeight ? 'auto' : 'hidden'\"\n>\n  <div *ngFor=\"let file of files\" class=\"flex flex-col gap-1 mt-1\">\n    <!-- Neutral status file -->\n    <div\n      *ngIf=\"!file.status\"\n      class=\"relative border border-neutral-100 bg-level-3 rounded-lg p-4 flex gap-4 items-center justify-between\"\n    >\n      <div class=\"flex items-center justify-start gap-4\">\n        <div\n          class=\"flex items-center justify-center p-2 bg-level-4 border border-stroke-1 rounded text-neutral-500\"\n        >\n          <ds-icon id=\"file-edit-02\" size=\"16px\" class=\"text-red-500\"></ds-icon>\n        </div>\n        <div class=\"flex flex-col gap-1 text-neutral-900\">\n          <p class=\"text-[1rem]/[1.375rem] font-medium\">\n            {{ file.file.name }}\n          </p>\n          <p class=\"text-[0.875rem]/[1.25rem] font-normal\">\n            {{ formatFileSize(file.file.size) }} - 100% T\u00E9l\u00E9charg\u00E9\n          </p>\n        </div>\n      </div>\n\n      <div *ngIf=\"isDownloadable\">\n        <button\n          (click)=\"downloadFile(file?.file)\"\n          class=\"p-2 hover:bg-neutral-25 rounded\"\n        >\n          <ds-icon\n            id=\"download\"\n            size=\"20px\"\n            class=\"shrink-0 text-red-500\"\n          ></ds-icon>\n        </button>\n      </div>\n    </div>\n    <!-- Success status file -->\n    <div\n      *ngIf=\"file.status === 'success'\"\n      class=\"relative border border-success-500 rounded-lg p-4 flex gap-4 items-center justify-between\"\n    >\n      <div class=\"flex items-center justify-start gap-4\">\n        <div\n          class=\"flex items-center justify-center rounded p-2 bg-[#FFFFFF] border border-success-200 text-success-500\"\n        >\n          <ds-icon id=\"file-edit-02\" size=\"16px\"></ds-icon>\n        </div>\n        <div class=\"flex flex-col gap-1\">\n          <p class=\"text-[1rem]/[1.375rem] font-medium text-success-500\">\n            {{ file.file.name }}\n          </p>\n          <p class=\"text-[0.875rem]/[1.25rem] font-normal text-neutral-700\">\n            {{ formatFileSize(file.file.size) }} - 100% T\u00E9l\u00E9charg\u00E9\n          </p>\n        </div>\n      </div>\n      <div *ngIf=\"!isDownloadable\">\n        <button\n          (click)=\"removeFile(file?.file.id)\"\n          class=\"rounded hover:bg-neutral-25 flex items-center justify-center p-1\"\n        >\n          <ds-icon\n            id=\"trash-02\"\n            size=\"20\"\n            class=\"shrink-0 text-neutral-700\"\n          ></ds-icon>\n        </button>\n      </div>\n      <div *ngIf=\"isDownloadable\">\n        <button\n          (click)=\"downloadFile(file?.file)\"\n          class=\"p-2 hover:bg-gray-50 rounded-full\"\n        >\n          <ds-icon id=\"download\" size=\"16px\" class=\"shrink-0\"></ds-icon>\n        </button>\n      </div>\n    </div>\n\n    <!-- Uploading status file -->\n    <div\n      *ngIf=\"file.status === 'uploading'\"\n      class=\"relative border overflow-hidden border-red-200 bg-transparent rounded-lg p-4\"\n    >\n      <!-- <div\n        class=\"absolute inset-0 h-full bg-red-50 dark:bg-[#290505] w-1/4 transition-all duration-300 ease-in-out\"\n        [style.width]=\"file.progress + '%'\"\n      ></div> -->\n      <div class=\"relative w-full z-[1] flex gap-4 items-center justify-start\">\n        <div\n          class=\"flex items-center justify-center rounded bg-white border border-red-100 p-2 text-red-500\"\n        >\n          <ds-icon id=\"file-edit-02\" size=\"16px\"></ds-icon>\n        </div>\n\n        <div class=\"flex flex-col gap-1 text-neutral-700\">\n          <p class=\"text-[1rem]/[1.375rem] font-medium\">\n            {{ file.file.name }}\n          </p>\n          <p class=\"text-[0.875rem]/[1.25rem] font-normal\">\n            {{ formatFileSize(file.file.size) }}\n          </p>\n        </div>\n        <div class=\"absolute right-0 top-1/2 -translate-y-1/2\">\n          <ds-icon\n            id=\"Loader\"\n            size=\"32px\"\n            class=\"animate-spin text-red-500\"\n          ></ds-icon>\n        </div>\n      </div>\n    </div>\n\n    <!-- Error status file -->\n    <div *ngIf=\"file.status === 'error'\">\n      <div\n        class=\"relative border border-error-300 rounded-lg p-4 bg-error-50 dark:bg-[#290505]\"\n      >\n        <div class=\"flex items-center justify-between gap-4\">\n          <div class=\"flex items-center gap-4\">\n            <div\n              class=\"flex items-center justify-center rounded bg-white dark:bg-red-50 text-error-500 p-2 border border-error-100\"\n            >\n              <ds-icon id=\"file-edit-02\" size=\"16px\"></ds-icon>\n            </div>\n            <div class=\"flex flex-col gap-0.5 text-error-500\">\n              <p class=\"text-[1rem]/[1.375rem] font-medium\">\n                {{ file.file.name }}\n              </p>\n              <p class=\"text-neutral-700 text-[0.875rem]/[1.25rem] font-normal\">\n                {{ formatFileSize(file.file.size) }} - 100% T\u00E9l\u00E9charg\u00E9\n              </p>\n              <!-- <button (click)=\"reUploadFile(file.file.id)\" class=\"max-w-fit inline-block font-medium text-error-500 hover:text-error-700\">\n                R\u00E9essayer\n              </button> -->\n            </div>\n          </div>\n          <button\n            (click)=\"removeFile(file.file.id)\"\n            class=\"rounded-full text-rose-700 flex items-center justify-center w-5 h-5\"\n          >\n            <ds-icon id=\"trash-02\" size=\"20px\" class=\"shrink-0\"></ds-icon>\n          </button>\n        </div>\n        <div *ngIf=\"file.errors && file.errors.length > 0\" class=\"mt-3\">\n          <div class=\"overflow-hidden\">\n            <button\n              type=\"button\"\n              class=\"w-full text-left transition-colors duration-200 flex items-center justify-start gap-x-2\"\n              (click)=\"toggleErrors(file.file.id)\"\n            >\n              <ds-icon\n                [id]=\"isErrorVisible(file.file.id) ? 'arrow-up' : 'arrow-down'\"\n                size=\"16px\"\n                class=\"transition-transform duration-200\"\n                [ngClass]=\"{ 'rotate-180': isErrorVisible(file.file.id) }\"\n              ></ds-icon>\n              <span class=\"font-medium text-sm text-black\"\n                >Merci de consulter ci-dessous les erreurs identifi\u00E9es au niveau\n                de votre fichier</span\n              >\n            </button>\n\n            <div\n              *ngIf=\"isErrorVisible(file.file.id)\"\n              class=\"mt-2 relative\"\n              [ngClass]=\"{\n                'max-h-0 overflow-hidden': !isErrorVisible(file.file.id),\n                'max-h-[108px] overflow-hidden': isErrorVisible(file.file.id)\n              }\"\n              style=\"transition: max-height 0.3s ease-in-out\"\n            >\n              <div class=\"max-h-[108px] overflow-y-auto\">\n                <ul class=\"space-y-1\">\n                  <li\n                    *ngFor=\"let error of file.errors\"\n                    class=\"flex items-start gap-2 text-rose-700\"\n                  >\n                    <ds-icon\n                      id=\"dash\"\n                      size=\"16px\"\n                      class=\"text-error-500 mt-0.5 flex-shrink-0\"\n                    ></ds-icon>\n                    <span class=\"text-sm\">{{ error }}</span>\n                  </li>\n                </ul>\n              </div>\n              <div\n                *ngIf=\"file.errors!.length > 4\"\n                class=\"pointer-events-none absolute bottom-0 left-0 right-0 h-8 bg-gradient-to-t from-[#F9E6E7] to-transparent\"\n                aria-hidden=\"true\"\n              ></div>\n            </div>\n          </div>\n        </div>\n        <ds-button\n          variant=\"primary\"\n          className=\"mt-3\"\n          (click)=\"onDownloadErrors.emit(file.file.id)\"\n          *ngIf=\"showErrorButtonUpload && file.errors && file.errors.length > 0\"\n        >\n          T\u00E9l\u00E9charger le rapport des erreurs\n          <ds-icon id=\"download-cloud\" size=\"16px\"></ds-icon\n        ></ds-button>\n      </div>\n    </div>\n  </div>\n</div>\n"
            }] }
];
FileListComponent.propDecorators = {
    className: [{ type: Input }],
    files: [{ type: Input }],
    isMultiple: [{ type: Input }],
    isDownloadable: [{ type: Input }],
    maxHeight: [{ type: Input }],
    showErrorButtonUpload: [{ type: Input }],
    onDelete: [{ type: Output }],
    onReUpload: [{ type: Output }],
    onDownload: [{ type: Output }],
    onDownloadErrors: [{ type: Output }]
};

const theme$3 = {
    default: {
        wrapper: 'relative py-4 px-6 border !border-dashed border-neutral-100 flex flex-col gap-3 text-neutral-500 rounded-lg text-center bg-neutral-25 transition cursor-pointer',
        icon: 'mx-auto size-14 shrink-0 flex justify-center items-center bg-level-3 rounded-md text-gray-400 border border-neutral-100',
        text: 'text-sm flex flex-col gap-1',
    },
};

/**
 * FileUploaderComponent
 *
 * Live demo:
 * <example-url>/demo/ds-file-uploader.component.html</example-url>
 */
class FileUploaderComponent {
    constructor() {
        this.allowedExtensions = [];
        this.className = '';
        this.maxFileSizeMB = 10;
        this.variant = 'default';
        this.isMultiple = false;
        this.files = [];
        this.disabled = false;
        this.maxHeight = undefined;
        this.showErrorButtonUpload = false;
        this.onChange = new EventEmitter();
        this.onRemove = new EventEmitter();
        this.onReUpload = new EventEmitter();
        this.onDownloadErrors = new EventEmitter();
        this.currentTheme = theme$3[this.variant];
        this.selectedFiles = [];
        // reUploadFile(id: string) {
        //   this.fileInput.nativeElement.value = '';
        //   if (!this.disabled) {
        //     this.fileInput.nativeElement.click();
        //   }
        //   this.onReUpload.emit(id);
        //   this.files = [];
        // }
    }
    downloadErrors(fileId) {
        this.onDownloadErrors.emit(fileId);
    }
    handleFile(files) {
        const errors = [];
        files.forEach((file) => {
            const ext = (file.name.split('.').pop() || '').toLowerCase();
            if (!this.allowedExtensions.includes(ext) &&
                this.allowedExtensions.length > 0) {
                errors.push(`Invalid file type. Allowed: ${this.allowedExtensions.join(', ')}`);
            }
        });
        files.forEach((file) => {
            if (file.size > this.maxFileSizeMB * 1024 * 1024 &&
                this.maxFileSizeMB > 0) {
                errors.push(`Max file size is ${this.maxFileSizeMB} MB`);
            }
        });
        if (!this.isMultiple && this.files.length >= 1) {
            errors.push('Multiple files are not allowed');
        }
        if (errors.length > 0) {
            alert(errors.join('\n'));
            return;
        }
        const filesWithId = Array.from(files).map((file) => {
            const fileWithId = file;
            fileWithId.id = this.generateUniqueId();
            return fileWithId;
        });
        if (filesWithId.length > 0) {
            this.onChange.emit(filesWithId);
        }
    }
    openFileInput() {
        if (this.fileInput && this.fileInput.nativeElement && !this.disabled) {
            this.fileInput.nativeElement.click();
        }
    }
    onDrop(event) {
        event.preventDefault();
        this.handleFile(Array.from(event.dataTransfer.files));
    }
    onDragOver(event) {
        event.preventDefault();
    }
    generateUniqueId() {
        const chars = '0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ';
        const randomValues = new Uint32Array(16);
        crypto.getRandomValues(randomValues);
        let id = '';
        for (let group = 0; group < 4; group++) {
            for (let i = 0; i < 4; i++) {
                const idx = group * 4 + i;
                id += chars[randomValues[idx] % chars.length];
            }
            if (group < 3) {
                id += '-';
            }
        }
        return id;
    }
    onFileChange(event) {
        event.preventDefault();
        const input = event.target;
        this.handleFile(Array.from(input.files));
    }
    removeFile(id) {
        this.onRemove.emit(id);
        this.fileInput.nativeElement.value = '';
    }
}
FileUploaderComponent.decorators = [
    { type: Component, args: [{
                selector: 'ds-file-uploader',
                template: "<div id=\"ds-file-uploader\">\n  <div\n    [ngClass]=\"[\n      currentTheme.wrapper,\n      className,\n      disabled ? '!cursor-not-allowed opacity-40' : ''\n    ]\"\n    (drop)=\"onDrop($event)\"\n    (dragover)=\"onDragOver($event)\"\n    (click)=\"openFileInput()\"\n  >\n    <div [ngClass]=\"currentTheme.icon\">\n      <ds-icon id=\"upload-cloud\" size=\"30px\" class=\"text-red-500\"></ds-icon>\n    </div>\n\n    <div [ngClass]=\"[currentTheme.text]\" class=\"relative\">\n      <input\n        #fileInput\n        type=\"file\"\n        [accept]=\"'.' + allowedExtensions.join(',.')\"\n        class=\"absolute inset-0 opacity-0 cursor-pointer z-[-1000]\"\n        (change)=\"onFileChange($event)\"\n        [multiple]=\"isMultiple\"\n      />\n      <ng-content></ng-content>\n    </div>\n  </div>\n  <div class=\"mt-2\">\n    <ds-file-list\n      [files]=\"files\"\n      [isMultiple]=\"isMultiple\"\n      (onDelete)=\"removeFile($event)\"\n      (onDownloadErrors)=\"downloadErrors($event)\"\n      [maxHeight]=\"maxHeight\"\n      [showErrorButtonUpload]=\"showErrorButtonUpload\"\n    ></ds-file-list>\n  </div>\n</div>\n"
            }] }
];
FileUploaderComponent.propDecorators = {
    allowedExtensions: [{ type: Input }],
    className: [{ type: Input }],
    maxFileSizeMB: [{ type: Input }],
    variant: [{ type: Input }],
    isMultiple: [{ type: Input }],
    files: [{ type: Input }],
    disabled: [{ type: Input }],
    maxHeight: [{ type: Input }],
    showErrorButtonUpload: [{ type: Input }],
    onChange: [{ type: Output }],
    onRemove: [{ type: Output }],
    onReUpload: [{ type: Output }],
    onDownloadErrors: [{ type: Output }],
    fileInput: [{ type: ViewChild, args: ['fileInput',] }]
};

/**
 * ImportCardComponent
 *
 * Live demo:
 * <example-url>/demo/ds-import-card.component.html</example-url>
 */
class ImportCardComponent {
    constructor() {
        this.className = '';
        this.title = '';
        this.description = '';
        this.actions = [];
        this.onClick = new EventEmitter();
    }
    handleCardClick() {
        this.onClick.emit();
    }
}
ImportCardComponent.decorators = [
    { type: Component, args: [{
                selector: 'ds-import-card',
                template: "<div\n  id=\"ds-import-card\"\n  class=\"relative w-full bg-level-4 p-3 rounded-md\"\n  [ngClass]=\"[className, onClick.observers?.length ? 'cursor-pointer' : '']\"\n  (click)=\"handleCardClick()\"\n>\n  <div class=\"flex items-center gap-3 mb-3.5\">\n    <div\n      *ngIf=\"icon\"\n      class=\"p-2 border bg-card-level-2 border-stroke-1 rounded-full\"\n    >\n      <ds-icon [id]=\"icon\" size=\"20\" class=\"text-primary\"></ds-icon>\n    </div>\n    <div class=\"\">\n      <h3 class=\"text-sm text-neutral-900 font-bold mb-1\">{{ title }}</h3>\n      <p class=\"text-xs text-neutral-900\">{{ description }}</p>\n    </div>\n  </div>\n  <div class=\"flex items-center justify-end gap-4\">\n    <button\n      *ngFor=\"let action of actions\"\n      class=\"flex items-center gap-2\"\n      (click)=\"action.onClick()\"\n    >\n      <span class=\"text-xs font-bold\">{{ action.label }}</span>\n      <ds-icon [id]=\"action.icon\" class=\"w-4 h-4 text-primary-500\"></ds-icon>\n    </button>\n  </div>\n  <!-- <ds-dropdown *ngIf=\"actionsList && actionsList.length > 0\" [items]=\"actionsList\" anchor=\"bottom start\" class=\"absolute top-2 right-3\">\n    <ds-icon id=\"more-1\" size=\"18\"></ds-icon>\n  </ds-dropdown> -->\n</div>\n"
            }] }
];
ImportCardComponent.propDecorators = {
    className: [{ type: Input }],
    title: [{ type: Input }],
    description: [{ type: Input }],
    actions: [{ type: Input }],
    icon: [{ type: Input }],
    onClick: [{ type: Output }]
};

// theme definitions for MessageComponent
const theme$4 = {
    warning: {
        wrapper: 'rounded-md border border-amber-400 w-full flex items-center gap-4 py-3 px-4 bg-amber-100',
        icon: 'rounded-full bg-amber-400 p-3',
        content: 'text-[1rem] font-bold text-amber-800',
    },
    success: {
        wrapper: 'rounded-md border border-green-200 w-full flex items-center gap-4 py-3 px-4 bg-green-50',
        icon: 'rounded-full bg-green-400 p-3',
        content: 'text-[1rem] font-bold text-green-600',
    },
    error: {
        wrapper: 'rounded-md border border-red-200 w-full flex items-center gap-4 py-3 px-4 bg-red-50',
        icon: 'rounded-full bg-error-400 p-3',
        content: 'text-[1rem] font-bold text-red-600',
    },
};

/**
 * MessageComponent
 *
 * Live demo:
 * <example-url>/demo/ds-message.component.html</example-url>
 */
class MessageComponent {
    constructor() {
        this.className = '';
        this.content = '';
        this.theme = theme$4;
    }
}
MessageComponent.decorators = [
    { type: Component, args: [{
                selector: 'ds-message',
                template: "<div id=\"ds-message\" [ngClass]=\"theme[variant].wrapper\" [ngClass]=\"className\">\n  <div [ngClass]=\"theme[variant].icon\">\n    <ds-icon *ngIf=\"variant === 'warning'\" id=\"danger\" class=\"text-white w-5 h-5\"></ds-icon>\n    <ds-icon *ngIf=\"variant === 'success'\" id=\"check\" class=\"text-white w-5 h-5\"></ds-icon>\n    <ds-icon *ngIf=\"variant === 'error'\" id=\"close\" class=\"text-white w-5 h-5\"></ds-icon>\n  </div>\n  <div>\n      <p [ngClass]=\"theme[variant].content\">{{ content }}</p>\n  </div>\n</div>\n"
            }] }
];
MessageComponent.propDecorators = {
    className: [{ type: Input }],
    content: [{ type: Input }],
    variant: [{ type: Input }]
};

// dropdown.component.ts
/**
 * DropdownHolderComponent
 *
 * Live demo:
 * <example-url>/demo/ds-dropdown-holder.component.html</example-url>
 */
class DropdownHolderComponent {
    constructor(cd, vcr, cfr, appRef, injector, document) {
        this.cd = cd;
        this.vcr = vcr;
        this.cfr = cfr;
        this.appRef = appRef;
        this.injector = injector;
        this.document = document;
        this.className = '';
        this.containerClassName = '';
        this.toggle = new EventEmitter();
        this.isOpen = false;
        this.menuStyles = {};
        this.handleOutsideClick = (e) => {
            const tgt = e.target;
            if (this.isOpen &&
                !this.trigger.nativeElement.contains(tgt) &&
                this.menu &&
                !this.menu.nativeElement.contains(tgt)) {
                this.closeMenu();
            }
        };
    }
    ngOnInit() {
        // set up a portal host on <body>
        this.portalHost = new DomPortalHost(this.document.body, this.cfr, this.appRef, this.injector);
        document.addEventListener('click', this.handleOutsideClick, true);
    }
    ngOnDestroy() {
        document.removeEventListener('click', this.handleOutsideClick, true);
        this.portalHost.detach(); // clean up
    }
    toggleMenu() {
        if (!this.isOpen) {
            // prepare a fresh portal
            this.menuPortal = new TemplatePortal(this.menuTpl, this.vcr);
            // attach it (renders the <ng-template> into <body>)
            this.portalHost.attach(this.menuPortal);
            this.menuStyles = {
                position: 'fixed',
                visibility: 'hidden',
                top: '0px',
                left: '0px',
                zIndex: `${++DropdownHolderComponent.zIndexCounter}`,
            };
            this.isOpen = true;
            this.toggle.emit(true);
            this.cd.detectChanges();
            this.setMenuPosition();
            this.menuStyles.visibility = 'visible';
        }
        else {
            this.closeMenu();
        }
    }
    setMenuPosition() {
        const t = this.trigger.nativeElement.getBoundingClientRect();
        const mEl = this.menu.nativeElement;
        const mW = mEl.offsetWidth, mH = mEl.offsetHeight;
        const vw = window.innerWidth, vh = window.innerHeight;
        let top = t.bottom;
        if (t.bottom + mH > vh) {
            top = t.top - mH;
        }
        top = Math.max(0, top);
        let left = t.left;
        if (t.left + mW > vw) {
            left = t.right - mW;
        }
        left = Math.max(0, left);
        Object.assign(this.menuStyles, {
            top: `${top}px`,
            left: `${left}px`,
        });
    }
    closeMenu() {
        if (this.portalHost.hasAttached()) {
            this.portalHost.detach();
        }
        this.isOpen = false;
        this.toggle.emit(false);
        this.menuStyles = {};
    }
    onItemClick(event, cb) {
        if (cb) {
            cb(event);
        }
        this.closeMenu();
    }
    stopEvent(event) {
        event.stopPropagation();
    }
}
DropdownHolderComponent.zIndexCounter = 10000;
DropdownHolderComponent.decorators = [
    { type: Component, args: [{
                selector: 'ds-dropdown-holder',
                template: "<div id=\"ds-dropdown-holder\" id=\"ds-dropdown\" [ngClass]=\"[className]\">\n  <button #trigger (click)=\"toggleMenu()\">\n    <ng-container *ngIf=\"buttonContent\">\n      <ng-template [ngTemplateOutlet]=\"buttonContent\"></ng-template>\n    </ng-container>\n  </button>\n\n  <ng-template #menuTpl>\n    <div\n      #menu\n      @dropdownAnim\n      class=\"p-2 absolute mt-2 min-w-[350px] origin-top-right shadow-dropdown focus:outline-none\"\n      [ngStyle]=\"menuStyles\"\n      [ngClass]=\"containerClassName\"\n    >\n      <ng-content></ng-content>\n    </div>\n  </ng-template>\n</div>\n",
                animations: [
                    trigger('dropdownAnim', [
                        // enter: from nothing → visible
                        transition(':enter', [
                            style({ opacity: 0, transform: 'scale(0.95)' }),
                            animate('120ms ease-out', style({ opacity: 1, transform: 'scale(1)' })),
                        ]),
                        // leave: from visible → nothing
                        transition(':leave', [
                            animate('100ms ease-in', style({ opacity: 0, transform: 'scale(0.95)' })),
                        ]),
                    ]),
                ]
            }] }
];
/** @nocollapse */
DropdownHolderComponent.ctorParameters = () => [
    { type: ChangeDetectorRef },
    { type: ViewContainerRef },
    { type: ComponentFactoryResolver },
    { type: ApplicationRef },
    { type: Injector },
    { type: undefined, decorators: [{ type: Inject, args: [DOCUMENT,] }] }
];
DropdownHolderComponent.propDecorators = {
    className: [{ type: Input }],
    containerClassName: [{ type: Input }],
    buttonContent: [{ type: Input }],
    toggle: [{ type: Output }],
    trigger: [{ type: ViewChild, args: ['trigger',] }],
    menuTpl: [{ type: ViewChild, args: ['menuTpl',] }],
    menu: [{ type: ViewChild, args: ['menu',] }],
    stopEvent: [{ type: HostListener, args: ['click', ['$event'],] }]
};

/**
 * CarouselComponent
 *
 * Live demo:
 * <example-url>/demo/ds-carousel.component.html</example-url>
 */
class CarouselComponent {
    constructor(cd) {
        this.cd = cd;
        this.className = '';
        this.wrapperClass = 'w-full';
        this.itemCount = 0;
        this.itemClass = 'carousel-item';
        this.activeIndex = 0;
        this.visibleSlides = [];
        this.visibleCount = 1;
        this.items = [];
    }
    ngAfterViewInit() {
        const carouselEl = this.carouselRef.nativeElement;
        this.items = Array.from(carouselEl.querySelectorAll(`.${this.itemClass}`));
        if (!this.items.length) {
            return;
        }
        const itemWidth = this.items[0].offsetWidth;
        this.visibleCount = Math.floor(carouselEl.offsetWidth / itemWidth) || 1;
        // Delay initial rendering to avoid ExpressionChangedAfterItHasBeenCheckedError
        setTimeout(() => {
            this.updateVisibleSlides();
            this.cd.detectChanges();
        });
        // Update activeIndex on manual scroll
        carouselEl.addEventListener('scroll', () => {
            const scrollLeft = carouselEl.scrollLeft;
            const width = this.items[0].offsetWidth || carouselEl.offsetWidth;
            this.activeIndex = Math.round(scrollLeft / width);
            this.updateVisibleSlides();
            this.cd.detectChanges();
        });
    }
    updateVisibleSlides() {
        const remaining = this.itemCount - this.visibleCount;
        const total = remaining > 0 ? remaining + 1 : 1;
        this.visibleSlides = Array.from({ length: total }, (_, i) => i);
    }
    scrollToIndex(index) {
        const item = this.items[index];
        if (item) {
            item.scrollIntoView({ behavior: 'smooth', inline: 'start' });
            this.activeIndex = index;
            this.updateVisibleSlides();
            this.cd.detectChanges();
        }
    }
    scrollNext() {
        const maxIndex = this.itemCount - this.visibleCount;
        const next = this.activeIndex >= maxIndex ? 0 : this.activeIndex + 1;
        this.scrollToIndex(next);
    }
    scrollPrev() {
        const maxIndex = this.itemCount - this.visibleCount;
        const prev = this.activeIndex <= 0 ? maxIndex : this.activeIndex - 1;
        this.scrollToIndex(prev);
    }
    onSelect(index) {
        if (index >= 0 && index < this.itemCount) {
            this.scrollToIndex(index);
        }
    }
}
CarouselComponent.decorators = [
    { type: Component, args: [{
                selector: 'ds-carousel',
                template: "<div id=\"ds-carousel\" [ngClass]=\"className\">\n  <div class=\"relative flex flex-col gap-3 w-full\">\n    <div\n      #carousel\n      class=\"flex overflow-x-auto snap-x snap-mandatory scroll-smooth gap-x-4 no-scrollbar\"\n      [ngClass]=\"wrapperClass\"\n    >\n      <ng-content></ng-content>\n    </div>\n\n    <ds-slider-dots\n      [count]=\"visibleSlides.length\"\n      [active]=\"activeIndex\"\n      [showArrows]=\"true\"\n      (prev)=\"scrollPrev()\"\n      (next)=\"scrollNext()\"\n      (select)=\"onSelect($event)\"\n    ></ds-slider-dots>\n  </div>\n</div>\n"
            }] }
];
/** @nocollapse */
CarouselComponent.ctorParameters = () => [
    { type: ChangeDetectorRef }
];
CarouselComponent.propDecorators = {
    className: [{ type: Input }],
    wrapperClass: [{ type: Input }],
    itemCount: [{ type: Input }],
    itemClass: [{ type: Input }],
    carouselRef: [{ type: ViewChild, args: ['carousel',] }]
};

/**
 * FloatedButtonsComponent
 *
 * Live demo:
 * <example-url>/demo/ds-floated-buttons.component.html</example-url>
 */
class FloatedButtonsComponent {
    constructor() {
        this.items = [];
        this.className = '';
    }
    isAllItemsDisabled() {
        return this.items.every((item) => item.disabled);
    }
}
FloatedButtonsComponent.decorators = [
    { type: Component, args: [{
                selector: 'ds-floated-buttons',
                template: "<div\n  id=\"ds-floated-buttons\"\n  *ngIf=\"items && items.length\"\n  class=\"flex items-center gap-4 rounded-lg py-3 px-6 bg-level-5 border border-neutral-100 shadow-floated shadow-neutral-100 w-fit\"\n  [ngClass]=\"className\"\n>\n  <ng-container *ngFor=\"let item of items; let last = last\">\n    <button\n      [type]=\"item.type\"\n      [disabled]=\"item.disabled\"\n      (click)=\"item.onClick($event)\"\n      class=\"inline-flex text-nowrap items-center gap-2 text-[0.75rem]/[1rem] font-medium disabled:cursor-not-allowed disabled:opacity-40\"\n      [ngClass]=\"[item.className || '', item.isDelete ? 'text-red-500' : '']\"\n    >\n      <ng-container *ngIf=\"item.isLoading\">\n        <ds-icon [id]=\"'Loader'\" class=\"animate-spin\" size=\"14px\"></ds-icon>\n      </ng-container>\n      <ng-container *ngIf=\"!item.isLoading && item.icon && !item.iconRight\">\n        <ds-icon [id]=\"item.icon\" size=\"14px\"></ds-icon>\n      </ng-container>\n      {{ item.content }}\n      <ng-container *ngIf=\"!item.isLoading && item.icon && item.iconRight\">\n        <ds-icon [id]=\"item.icon\" size=\"14px\"></ds-icon>\n      </ng-container>\n    </button>\n    <span\n      *ngIf=\"!last\"\n      class=\"inline-flex h-3 w-px\"\n      [ngClass]=\"isAllItemsDisabled() ? 'bg-neutral-200' : 'bg-neutral-700'\"\n    ></span>\n  </ng-container>\n</div>\n"
            }] }
];
FloatedButtonsComponent.propDecorators = {
    items: [{ type: Input }],
    className: [{ type: Input }]
};

/**
 * AutocompleteComponent
 *
 * Live demo:
 * <example-url>/demo/ds-autocomplete.component.html</example-url>
 */
class AutocompleteComponent {
    constructor(host) {
        this.host = host;
        this.className = '';
        this.placeholder = '';
        this.items = [];
        this.values = [];
        this.valuesChange = new EventEmitter();
        this.onSelect = new EventEmitter();
        // These will be set by Angular when you register the control
        this.onChange = () => { };
        this.onTouched = () => { };
        this.value = '';
        this.showDropdown = false;
        this.filteredItems = [];
    }
    ngOnInit() {
        // initialize checked flags
        this.filteredItems = this.items.map((item) => (Object.assign({}, item, { checked: false })));
    }
    ngOnChanges(changes) {
        if (changes.items) {
            // reset when the source list changes
            this.filteredItems = this.items.map((item) => (Object.assign({}, item, { checked: this.values.some((v) => v.value === item.value) })));
            this._syncCheckedFlags();
        }
        if (changes.values) {
            // keep checked state in sync with selected badges
            this.filteredItems = this.filteredItems.map((item) => (Object.assign({}, item, { checked: this.values.some((v) => v.value === item.value) })));
        }
    }
    //ControlValueAccessor methods
    writeValue(vals) {
        this.values = vals || [];
        this._syncCheckedFlags();
    }
    registerOnChange(fn) {
        this.onChange = fn;
    }
    registerOnTouched(fn) {
        this.onTouched = fn;
    }
    emitValues() {
        this.valuesChange.emit(this.values);
    }
    onInput(event) {
        this.onTouched();
        const input = event.target.value;
        this.value = input;
        this.filteredItems = this.items
            .filter((item) => item.label.toLowerCase().includes(input.toLowerCase()))
            .map((item) => (Object.assign({}, item, { checked: this.values.some((v) => v.value === item.value) })));
        this.showDropdown = !!input;
    }
    onSelectItem(event, field) {
        event.preventDefault();
        event.stopPropagation();
        const exists = this.values.find((v) => v.value === field.value);
        if (exists) {
            // remove
            this.values = this.values.filter((v) => v.value !== field.value);
            this._setChecked(field.value, false);
            this.onSelect.emit({ event, values: this.values, field: null });
        }
        else {
            // add
            this.values.push(field);
            this._setChecked(field.value, true);
            this.onSelect.emit({ event, values: this.values, field });
        }
        this._syncCheckedFlags();
        this._notifyChange();
        this._closeAndRefocus();
        // clear + hide + refocus
        this.value = '';
        this.filteredItems = this.items.map((item) => (Object.assign({}, item, { checked: this.values.some((v) => v.value === item.value) })));
        this.showDropdown = false;
        this.emitValues();
        setTimeout(() => this.inputRef.nativeElement.focus());
    }
    onDeleteBadge(event, field) {
        event.preventDefault();
        event.stopPropagation();
        this.values = this.values.filter((v) => v.value !== field.value);
        this._setChecked(field.value, false);
        setTimeout(() => this.inputRef.nativeElement.focus());
        this.onSelect.emit({ event, values: this.values, field: null });
        this.emitValues();
        this._syncCheckedFlags();
        this._notifyChange();
    }
    /** When user hits backspace on empty input, remove last badge */
    onBackspace() {
        // only if the input is empty and there is at least one badge
        if (!this.value && this.values.length) {
            // grab the last field
            const last = this.values[this.values.length - 1];
            // remove it
            this.values = this.values.slice(0, -1);
            // un-check it in the dropdown list
            this._setChecked(last.value, false);
            // emit change (field=null because it's a removal)
            this.onSelect.emit({
                event: null,
                values: this.values,
                field: null,
            });
            this.emitValues();
            this._syncCheckedFlags();
            this._notifyChange();
        }
    }
    _setChecked(val, checked) {
        this.filteredItems = this.filteredItems.map((item) => item.value === val ? Object.assign({}, item, { checked }) : item);
    }
    // ------------ Internals ---------------
    _syncCheckedFlags() {
        this.filteredItems = this.items.map((item) => (Object.assign({}, item, { checked: this.values.some((v) => v.value === item.value) })));
    }
    _notifyChange() {
        this.onChange(this.values);
    }
    _closeAndRefocus() {
        this.value = '';
        this.showDropdown = false;
        setTimeout(() => this.inputRef.nativeElement.focus());
    }
    getCheckedItems(item) {
        return this.values.some((v) => v.value === item.value);
    }
    onClickOutside(target) {
        if (!this.host.nativeElement.contains(target)) {
            this.showDropdown = false;
        }
    }
}
AutocompleteComponent.decorators = [
    { type: Component, args: [{
                selector: 'ds-autocomplete',
                template: "<div id=\"ds-autocomplete\" class=\"relative space-y-1\" [ngClass]=\"className\">\n  <div\n    class=\"flex justify-start items-center flex-wrap gap-1 bg-level-3 rounded border border-neutral-50 hover:border-primary text-left p-2\"\n  >\n    <ds-badge\n      size=\"sm\"\n      pill=\"true\"\n      *ngFor=\"let val of values\"\n      [label]=\"val.label\"\n      icon=\"close\"\n      iconRight=\"true\"\n      (onClick)=\"onDeleteBadge($event, val)\"\n    ></ds-badge>\n\n    <input\n      #myInput\n      class=\"text-sm font-bold flex-1 bg-transparent dark:placeholder-gray-300 placeholder-gray-400 placeholder-text-sm outline-none border-none focus:ring-0 p-0\"\n      [value]=\"value\"\n      (focus)=\"showDropdown = true\"\n      (input)=\"onInput($event)\"\n      (keydown.backspace)=\"onBackspace()\"\n      [placeholder]=\"placeholder\"\n      [attr.aria-label]=\"'Autocomplete input for ' + placeholder\"\n    />\n    <ds-icon\n      [id]=\"showDropdown ? 'arrow-up' : 'arrow-down'\"\n      class=\"text-heading dark:text-white w-4 h-4 shrink-0\"\n    ></ds-icon>\n  </div>\n\n  <div\n    *ngIf=\"showDropdown\"\n    class=\"absolute top-full left-0 w-full min-w-fullmax-w-[500px] bg-level-3 border border-stroke-2 rounded z-10 p-4\"\n  >\n    <ul\n      *ngIf=\"filteredItems.length\"\n      class=\"max-h-60 overflow-y-auto custom-scrollbar grid grid-cols-2 gap-2\"\n    >\n      <li\n        *ngFor=\"let item of filteredItems\"\n        class=\"rounded transition-all duration-300 ease-in-out flex items-center cursor-pointer gap-2\"\n        (click)=\"onSelectItem($event, item)\"\n      >\n        <ds-checkbox\n          [checked]=\"getCheckedItems(item)\"\n          [label]=\"item.label\"\n          variant=\"autocomplete\"\n          className=\"w-full\"\n        ></ds-checkbox>\n      </li>\n    </ul>\n\n    <div\n      *ngIf=\"!filteredItems.length\"\n      class=\"w-full min-h-32 bg-level-4 max-h-60 p-6 flex justify-center items-center overflow-y-auto custom-scrollbar\"\n    >\n      <h3 class=\"text-[1rem]/[1.5rem] font-bold text-neutral-800\">\n        No results found\n      </h3>\n    </div>\n  </div>\n</div>\n"
            }] }
];
/** @nocollapse */
AutocompleteComponent.ctorParameters = () => [
    { type: ElementRef }
];
AutocompleteComponent.propDecorators = {
    className: [{ type: Input }],
    placeholder: [{ type: Input }],
    items: [{ type: Input }],
    values: [{ type: Input }],
    valuesChange: [{ type: Output }],
    onSelect: [{ type: Output }],
    inputRef: [{ type: ViewChild, args: ['myInput',] }],
    onClickOutside: [{ type: HostListener, args: ['document:click', ['$event.target'],] }]
};

/**
 * SkeletonComponent
 *
 * Live demo:
 * <example-url>/demo/ds-skeleton.component.html</example-url>
 */
class SkeletonComponent {
    constructor() {
        this.className = '';
    }
}
SkeletonComponent.decorators = [
    { type: Component, args: [{
                selector: 'ds-skeleton',
                template: "<div\n  id=\"ds-skeleton\"\n  [ngClass]=\"['bg-neutral-100 animate-pulse rounded', className]\"\n></div>\n"
            }] }
];
SkeletonComponent.propDecorators = {
    className: [{ type: Input }]
};

/**
 * BadgeGroupComponent
 *
 * Live demo:
 * <example-url>/demo/ds-badge-group.component.html</example-url>
 */
class BadgeGroupComponent {
    constructor(cdr, host) {
        this.cdr = cdr;
        this.host = host;
        this.className = '';
        this.moreClassName = '';
        this.moreIcon = 'more';
        this.moreIconSize = '20px';
        this.tags = [];
        this.showInvisibleTags = false;
        this.visibleTags = [];
        this.invisibleTags = [];
        this.overflowCount = 0;
    }
    toggleInvisibleTags(event) {
        event.preventDefault();
        this.showInvisibleTags = !this.showInvisibleTags;
    }
    calculateOverflow() {
        const containerWidth = this.container.nativeElement.clientWidth;
        // grab only the badge elements (ignore the "+N" one)
        const badgeEls = Array.from(this.container.nativeElement.children);
        let total = 0;
        let fit = 0;
        const gap = 4; // px, match your CSS gap
        badgeEls.forEach((el) => (el.style.visibility = 'hidden'));
        for (let i = 0; i < badgeEls.length; i++) {
            total += badgeEls[i].offsetWidth + gap;
            if (total > containerWidth)
                break;
            fit++;
        }
        // 3) Now slice down to what fits...
        // this.visibleTags = this.tags.slice(0, fit);
        //get the invisibile
        this.invisibleTags = this.tags.slice(fit);
        // ...and count the overflow
        this.overflowCount = this.tags.length - fit;
        badgeEls.forEach((el) => (el.style.visibility = ''));
        // 4) Tell Angular to re-run CD so it picks up our new visibleTags/overflowCount
        this.cdr.detectChanges();
    }
    ngAfterViewInit() {
        // 2) Show *all* badges first so they actually render in the DOM
        this.visibleTags = this.tags.concat();
        this.overflowCount = 0;
        // 1) Wait a tick to let Angular paint them, then measure + slice
        setTimeout(() => {
            this.calculateOverflow();
        }, 0);
    }
    onWindowResize() {
        // optional: debounce if you see jank
        this.calculateOverflow();
    }
    // ← listen to *all* clicks on the page
    onClickOutside(target) {
        // if the dropdown is open, but click was *not* inside this component, close it
        if (this.showInvisibleTags && !this.host.nativeElement.contains(target)) {
            this.showInvisibleTags = false;
            // if you ever see ExpressionChanged… errors here, you can:
            // this.cdr.detectChanges();
        }
    }
}
BadgeGroupComponent.decorators = [
    { type: Component, args: [{
                selector: 'ds-badge-group',
                template: "<div id=\"ds-badge-group\" [ngClass]=\"className\" class=\"flex gap-1 items-center\">\n  <div\n    class=\"flex gap-1 flex-nowrap overflow-hidden items-center flex-1\"\n    #container\n  >\n    <ds-badge\n      *ngFor=\"let tag of tags\"\n      [label]=\"tag.label\"\n      [href]=\"tag.href\"\n      [withDot]=\"tag.withDot\"\n      [iconRight]=\"tag.iconRight\"\n      [pill]=\"tag.pill\"\n      [icon]=\"tag.icon\"\n      [className]=\"tag.className\"\n      [variant]=\"tag.variant || 'default'\"\n      [size]=\"tag.size || 'md'\"\n    ></ds-badge>\n  </div>\n  <div class=\"relative flex items-center\">\n    <button\n      class=\"rounded-full p-[3px] text-neutral-700 bg-neutral-50\"\n      (click)=\"toggleInvisibleTags($event)\"\n      [ngClass]=\"moreClassName\"\n    >\n      <!-- <ds-badge\n        *ngIf=\"overflowCount > 0\"\n        pill=\"true\"\n        className=\"!px-2\"\n        [label]=\"'+' + overflowCount\"\n      ></ds-badge> -->\n\n      <ds-icon [id]=\"moreIcon\" [size]=\"moreIconSize\"></ds-icon>\n    </button>\n\n    <ul\n      @dropdown\n      *ngIf=\"showInvisibleTags\"\n      class=\"top-[calc(100%+4px)] shadow-md rounded z-[100] right-0 absolute w-full flex flex-col min-w-max p-2 gap-4 bg-level-4\"\n    >\n      <li *ngFor=\"let tag of invisibleTags\">\n        <ds-badge\n          [label]=\"tag.label\"\n          [href]=\"tag.href\"\n          [withDot]=\"tag.withDot\"\n          [iconRight]=\"tag.iconRight\"\n          [pill]=\"tag.pill\"\n          [icon]=\"tag.icon\"\n          [className]=\"tag.className\"\n          [variant]=\"tag.variant || 'default'\"\n          [size]=\"tag.size || 'md'\"\n        ></ds-badge>\n      </li>\n    </ul>\n  </div>\n</div>\n",
                animations: [
                    trigger('dropdown', [
                        transition(':enter', [
                            style({ opacity: 0, transform: 'translateY(-8px) scale(0.95)' }),
                            animate('150ms ease-out', style({ opacity: 1, transform: 'translateY(0) scale(1)' })),
                        ]),
                        transition(':leave', [
                            animate('100ms ease-in', style({ opacity: 0, transform: 'translateY(-4px) scale(0.95)' })),
                        ]),
                    ]),
                ]
            }] }
];
/** @nocollapse */
BadgeGroupComponent.ctorParameters = () => [
    { type: ChangeDetectorRef },
    { type: ElementRef }
];
BadgeGroupComponent.propDecorators = {
    className: [{ type: Input }],
    moreClassName: [{ type: Input }],
    moreIcon: [{ type: Input }],
    moreIconSize: [{ type: Input }],
    tags: [{ type: Input }],
    container: [{ type: ViewChild, args: ['container', { read: ElementRef },] }],
    onWindowResize: [{ type: HostListener, args: ['window:resize',] }],
    onClickOutside: [{ type: HostListener, args: ['document:click', ['$event.target'],] }]
};

/**
 * ErrorCardComponent
 *
 * Live demo:
 * <example-url>/demo/ds-error-card.component.html</example-url>
 */
class ErrorCardComponent {
    constructor() {
        this.items = [];
        this.className = '';
    }
}
ErrorCardComponent.decorators = [
    { type: Component, args: [{
                selector: 'ds-error-card',
                template: "<ul\n  id=\"ds-error-card\"\n  class=\"flex flex-col gap-2 border border-red-200 bg-red-50 rounded p-4\"\n  [ngClass]=\"className\"\n>\n  <li\n    *ngFor=\"let item of items\"\n    class=\"flex w-full text-neutral-900 items-center gap-4 [&_*]:text-[0.75rem]/[0.875rem]\"\n    [ngClass]=\"[\n      item.className,\n      item.className ? '[&_span]:text-[0.875rem]/[1rem]' : '',\n      item.value ? 'justify-between' : 'justify-start'\n    ]\"\n  >\n    <span class=\"inline-block font-medium\">\n      {{ item.label }}\n    </span>\n    <p>{{ item.value }}</p>\n  </li>\n</ul>\n"
            }] }
];
ErrorCardComponent.propDecorators = {
    items: [{ type: Input }],
    className: [{ type: Input }]
};

// theme definitions for LabelComponent
const theme$5 = {
    default: {
        base: 'text-[0.875rem]/[1rem] font-bold text-neutral-900 mb-2',
    },
};

/**
 * LabelComponent
 *
 * Live demo:
 * <example-url>/demo/ds-label.component.html</example-url>
 */
class LabelComponent {
    constructor() {
        this.variant = 'default';
        this.for = '';
        this.required = false;
        this.disabled = false;
        this.className = '';
        this.theme = theme$5;
    }
}
LabelComponent.decorators = [
    { type: Component, args: [{
                selector: 'ds-label',
                template: "<label\n  id=\"ds-label\"\n  [for]=\"for\"\n  [ngClass]=\"[\n    theme[variant].base,\n    disabled ? 'cursor-not-allowed opacity-60' : '',\n    className\n  ]\"\n>\n  <ng-content></ng-content>\n  <span *ngIf=\"required\" class=\"ml-1 text-red-500\">*</span>\n</label>\n"
            }] }
];
LabelComponent.propDecorators = {
    variant: [{ type: Input }],
    for: [{ type: Input }],
    required: [{ type: Input }],
    disabled: [{ type: Input }],
    className: [{ type: Input }]
};

/**
 * DisplayPriceCardComponent
 *
 * Live demo:
 * <example-url>/demo/ds-display-price-card.component.html</example-url>
 */
class DisplayPriceCardComponent {
    constructor() {
        this.text = '';
        this.price = '';
        this.icon = 'receipt-lines';
        this.items = [];
        this.buttons = [];
        this.className = '';
    }
}
DisplayPriceCardComponent.decorators = [
    { type: Component, args: [{
                selector: 'ds-display-price-card',
                template: "<div id=\"ds-display-price-card\" [ngClass]=\"className\">\n  <div\n    class=\"py-3 px-4 bg-crame-100 border border-crame-300 rounded-[4px] flex flex-col gap-5\"\n  >\n    <div *ngIf=\"items.length > 0\" class=\"flex flex-col gap-2\">\n      <div\n        *ngFor=\"let item of items\"\n        class=\"w-full flex justify-between items-center gap-4 text-[0.875rem]/[1rem] text-neutral-900 [&_p]:font-bold\"\n      >\n        <span class=\"inline-flex whitespace-nowrap\">\n          {{ item.label }}\n        </span>\n        <span\n          *ngIf=\"item.showLine\"\n          class=\"w-[85%] whitespace-nowrap inline-flex mx-auto border-t border-dashed border-black\"\n        ></span>\n        <p class=\"whitespace-nowrap\">{{ item.value }}</p>\n      </div>\n    </div>\n\n    <div\n      class=\"flex w-full justify-between items-center\"\n      [ngClass]=\"[\n        items.length > 0 ? 'border-t border-dashed border-black pt-4' : ''\n      ]\"\n    >\n      <span\n        class=\"inline-flex text-[1rem]/[1.125rem] font-bold text-neutral-900\"\n      >\n        {{ text }}\n      </span>\n      <p\n        class=\"flex items-center gap-1.5 text-[1.375rem]/[2rem] font-bold text-neutral-900\"\n      >\n        <span> {{ price }} </span>\n\n        <ds-icon [id]=\"icon\" size=\"24px\" class=\"text-crame-500\"></ds-icon>\n      </p>\n    </div>\n  </div>\n  <div\n    *ngIf=\"buttons.length > 0\"\n    class=\"flex justify-end items-center gap-2 mt-4\"\n  >\n    <ds-button\n      *ngFor=\"let button of buttons\"\n      [className]=\"button.className\"\n      [variant]=\"button.variant ? button.variant : 'primary'\"\n      [size]=\"button.size ? button.size : 'normal'\"\n      [type]=\"button.type ? button.type : 'button'\"\n      [isLoading]=\"button.isLoading\"\n      [icon]=\"button.icon\"\n      [iconRight]=\"button.iconRight\"\n      [iconLeft]=\"button.iconLeft\"\n      (onClick)=\"button.onClick({ event: $event, data: data })\"\n    >\n      {{ button.text }}\n    </ds-button>\n  </div>\n</div>\n"
            }] }
];
DisplayPriceCardComponent.propDecorators = {
    text: [{ type: Input }],
    price: [{ type: Input }],
    icon: [{ type: Input }],
    items: [{ type: Input }],
    buttons: [{ type: Input }],
    className: [{ type: Input }],
    data: [{ type: Input }]
};

/**
 * FooterComponent
 *
 * Live demo:
 * <example-url>/demo/ds-footer.component.html</example-url>
 */
class FooterComponent {
    constructor() {
        this.leftMenus = [];
        this.rightMenus = [];
        this.className = '';
    }
}
FooterComponent.decorators = [
    { type: Component, args: [{
                selector: 'ds-footer',
                template: "<footer\n  id=\"ds-footer\"\n  class=\"@container border-neutral-100 border-t p-[14px]\"\n  [ngClass]=\"className\"\n>\n  <div class=\"flex items-center justify-between gap-4 w-full @3xl:flex-row\">\n    <ul\n      class=\"flex items-center @3xl:justify-start justify-center gap-x-3.5 flex-wrap\"\n    >\n      <ng-container *ngFor=\"let leftMenu of leftMenus; let last = last\">\n        <li\n          class=\"flex items-center justify-center text-neutral-800 text-[0.875rem]/[1rem] font-[400] gap-x-2\"\n        >\n          <a\n            [href]=\"leftMenu.href\"\n            class=\"inline-flex text-[0.625rem]/[0.75rem] font-medium\"\n            [ngClass]=\"{\n              'opacity-50 !pointer-events-none !cursor-not-allowed':\n                leftMenu.isDisabled\n            }\"\n          >\n            {{ leftMenu.title }}\n          </a>\n          <img\n            *ngIf=\"leftMenu.image\"\n            [src]=\"leftMenu.image\"\n            alt=\"leftMenu.title\"\n            class=\"w-4 h-4\"\n          />\n        </li>\n      </ng-container>\n    </ul>\n    <ul\n      class=\"flex items-center gap-x-3.5 flex-wrap @3xl:justify-start justify-center\"\n    >\n      <ng-container *ngFor=\"let rightMenu of rightMenus; let last = last\">\n        <li\n          class=\"flex items-center justify-center text-neutral-800 text-[0.875rem]/[1rem] font-[400] gap-x-2\"\n        >\n          <a\n            [href]=\"rightMenu.href\"\n            class=\"inline-flex text-[0.625rem]/[0.75rem] font-medium\"\n            [ngClass]=\"{\n              'opacity-50 !pointer-events-none !cursor-not-allowed':\n                rightMenu.isDisabled\n            }\"\n          >\n            {{ rightMenu.title }}\n          </a>\n          <img\n            *ngIf=\"rightMenu.image\"\n            [src]=\"rightMenu.image\"\n            alt=\"rightMenu.title\"\n            class=\"w-[81.5px]\"\n          />\n        </li>\n      </ng-container>\n    </ul>\n  </div>\n</footer>\n"
            }] }
];
FooterComponent.propDecorators = {
    leftMenus: [{ type: Input }],
    rightMenus: [{ type: Input }],
    className: [{ type: Input }]
};

/**
 * AccordionCardComponent
 *
 * Live demo:
 * <example-url>/demo/ds-accordion-card.component.html</example-url>
 */
class AccordionCardComponent {
    constructor() {
        this.items = [];
        this.className = '';
    }
    isTemplate(ref) {
        return ref instanceof TemplateRef;
    }
}
AccordionCardComponent.decorators = [
    { type: Component, args: [{
                selector: 'ds-accordion-card',
                template: "<ul\n  id=\"ds-accordion-card\"\n  class=\"p-4 rounded bg-neutral-25 flex flex-col gap-4\"\n  [ngClass]=\"className\"\n>\n  <li *ngFor=\"let item of items; let idx = index\" class=\"flex flex-col gap-1\">\n    <span\n      *ngIf=\"item.label\"\n      class=\"inline-block text-[0.875rem]/[1rem] text-neutral-500\"\n    >\n      {{ item.label }}\n    </span>\n\n    <ng-container *ngIf=\"isTemplate(item.value); else showHtml\">\n      <ng-container *ngTemplateOutlet=\"item.value\"></ng-container>\n    </ng-container>\n    <ng-template #showHtml>\n      <div [innerHTML]=\"item.value\" class=\"text-[0.875rem]/[1.125rem] font-bold\"></div>\n    </ng-template>\n  </li>\n</ul>\n"
            }] }
];
AccordionCardComponent.propDecorators = {
    items: [{ type: Input }],
    className: [{ type: Input }]
};

/**
 * CodeInputComponent
 *
 * Live demo:
 * <example-url>/demo/ds-code-input.component.html</example-url>
 */
class CodeInputComponent {
    constructor(host, renderer) {
        this.host = host;
        this.renderer = renderer;
        this.disabled = false;
        this.value = 0;
        this.className = '';
        this.copied = new EventEmitter();
        this.hasProjectedPrefix = false;
        this.hasProjectedSuffix = false;
        this.isCopied = false;
    }
    ngAfterViewInit() {
        const hostAttrs = this.host.nativeElement.attributes;
        for (let i = 0; i < hostAttrs.length; i++) {
            const { name, value } = hostAttrs[i];
            // skip Angular‐internal and any @Inputs you've explicitly declared
            if (name === 'class' ||
                name.startsWith('_ng') ||
                this.hasOwnProperty(name))
                continue;
            this.renderer.setAttribute(this.inner.nativeElement, name, value);
        }
    }
    copyToClipboard() {
        if (this.disabled)
            return;
        navigator.clipboard.writeText(String(this.value)).then(() => {
            this.isCopied = true;
            this.copied.emit(this.value);
            setTimeout(() => {
                this.isCopied = false;
            }, 2000);
        });
    }
}
CodeInputComponent.decorators = [
    { type: Component, args: [{
                selector: 'ds-code-input',
                template: "<div\n  class=\"flex items-center gap-2 rounded shrink-0 bg-red-100 placeholder:text-sm placeholder:text-red-500 placeholder:font-medium py-1.5 px-3 text-[1.25rem]/[1.688rem] font-bold appearance-none text-red-500 outline-none border-none focus:ring-0 w-fit tracking-wider select-none transition-all duration-200\"\n  [ngClass]=\"[\n    disabled\n      ? 'cursor-not-allowed !bg-neutral-100 !text-neutral-500'\n      : 'cursor-pointer',\n    className\n  ]\"\n  (click)=\"copyToClipboard()\"\n>\n  {{ value }}\n  <ds-icon id=\"copy\" class=\"size-4\" *ngIf=\"!isCopied && !disabled\"></ds-icon>\n  <ds-icon id=\"check\" class=\"size-4\" *ngIf=\"isCopied && !disabled\"></ds-icon>\n</div>\n"
            }] }
];
/** @nocollapse */
CodeInputComponent.ctorParameters = () => [
    { type: ElementRef },
    { type: Renderer2 }
];
CodeInputComponent.propDecorators = {
    id: [{ type: Input }],
    name: [{ type: Input }],
    label: [{ type: Input }],
    placeholder: [{ type: Input }],
    disabled: [{ type: Input }],
    value: [{ type: Input }],
    className: [{ type: Input }],
    copied: [{ type: Output }],
    inner: [{ type: ViewChild, args: ['inner', { read: ElementRef },] }]
};

// Component (pin-input.component.ts)
class PinInputComponent {
    constructor() {
        this.isCodeHidden = false;
        this.codeLength = 4;
        this.isCharsCode = false;
        this.inputType = 'tel';
        this.isPrevFocusableAfterClearing = false;
        this.isFocusingOnLastByClickIfFilled = false;
        this.initialFocusField = 0;
        this.code = '';
        this.disabled = false;
        this.autocapitalize = '';
        this.className = '';
        this.onCodeChanged = new EventEmitter();
        this.onCodeCompleted = new EventEmitter();
    }
}
PinInputComponent.decorators = [
    { type: Component, args: [{
                selector: 'ds-pin-input',
                template: "<div\n  id=\"ds-pin-input\"\n  class=\"w-full text-[2.25rem]/[2.938rem] !text-neutral-700 max-w-fit\"\n  [ngClass]=\"className\"\n>\n  <code-input\n    [isCodeHidden]=\"isCodeHidden\"\n    [codeLength]=\"codeLength\"\n    [isCharsCode]=\"isCharsCode\"\n    [inputType]=\"inputType\"\n    [isPrevFocusableAfterClearing]=\"isPrevFocusableAfterClearing\"\n    [isFocusingOnLastByClickIfFilled]=\"isFocusingOnLastByClickIfFilled\"\n    [initialFocusField]=\"initialFocusField\"\n    [code]=\"code\"\n    [disabled]=\"disabled\"\n    [autocapitalize]=\"autocapitalize\"\n    (codeChanged)=\"onCodeChanged.emit($event)\"\n    (codeCompleted)=\"onCodeCompleted.emit($event)\"\n  >\n  </code-input>\n</div>\n\n<style>\n  code-input {\n    --item-spacing: 4px;\n    --item-height: 48px;\n    --item-border: 1px solid rgb(var(--color-neutral-100) / 1);\n    --item-border-bottom: 1px solid rgb(var(--color-neutral-100) / 1);\n    --item-border-has-value: 1px solid rgb(var(--color-neutral-100) / 1);\n    --item-border-bottom-has-value: 1px solid rgb(var(--color-neutral-100) / 1);\n    --item-border-focused: 1px solid rgb(var(--color-red-500) / 1);\n    --item-border-bottom-focused: 1px solid rgb(var(--color-red-500) / 1);\n    --item-shadow-focused: none;\n    --item-border-radius: 6px;\n    --item-font-weight: 700;\n    --item-background-color: #ffffff;\n  }\n\n  ::ng-deep code-input input {\n    padding: 6px;\n    width: 48px !important;\n    color: rgb(var(--color-neutral-700) / 1) !important;\n    background-color: #ffffff !important;\n    background: #ffffff !important;\n  }\n</style>\n"
            }] }
];
PinInputComponent.propDecorators = {
    isCodeHidden: [{ type: Input }],
    codeLength: [{ type: Input }],
    isCharsCode: [{ type: Input }],
    inputType: [{ type: Input }],
    isPrevFocusableAfterClearing: [{ type: Input }],
    isFocusingOnLastByClickIfFilled: [{ type: Input }],
    initialFocusField: [{ type: Input }],
    code: [{ type: Input }],
    disabled: [{ type: Input }],
    autocapitalize: [{ type: Input }],
    className: [{ type: Input }],
    onCodeChanged: [{ type: Output }],
    onCodeCompleted: [{ type: Output }]
};

/**
 * PortfolioComponent
 *
 * Live demo:
 * <example-url>/demo/ds-portfolio.component.html</example-url>
 */
class PortfolioComponent {
    constructor(renderer) {
        this.renderer = renderer;
        this.portfolios = [];
        this.selected = null;
        this.holding = null;
        this.show = false;
        this.showDots = true;
        this.perPage = 4;
        this.totalItems = 0;
        this.className = '';
        this.currentPage = 1; // ← from parent
        this.totalPages = 1; // ← from parent
        // pages: number[] = [];
        /** fire whenever user wants a different page */
        this.pageChange = new EventEmitter();
        this.clicked = new EventEmitter();
        this.displayPortfolio = false;
    }
    get pages() {
        return Array.from({ length: this.totalPages }, (_, i) => i + 1);
    }
    /** Get paginated portfolios for current page */
    getPaginatedPortfolios() {
        const startIndex = (this.currentPage - 1) * this.perPage;
        const endIndex = startIndex + this.perPage;
        return this.portfolios.slice(startIndex, endIndex);
    }
    /** Get start index for display */
    getStartIndex() {
        return (this.currentPage - 1) * this.perPage + 1;
    }
    /** Get end index for display */
    getEndIndex() {
        const endIndex = this.currentPage * this.perPage;
        return Math.min(endIndex, this.portfolios.length);
    }
    ngOnInit() {
        this.resetState();
        this.calculateTotalPages();
    }
    /** Calculate total pages based on portfolios length and perPage */
    calculateTotalPages() {
        this.totalPages = Math.ceil(this.portfolios.length / this.perPage);
    }
    /** Handle input changes */
    ngOnChanges(changes) {
        if (changes['portfolios'] || changes['perPage']) {
            this.calculateTotalPages();
            // Reset to first page if current page is beyond total pages
            if (this.currentPage > this.totalPages) {
                this.currentPage = 1;
            }
        }
    }
    /** Go to next page if available */
    onNextPage(e) {
        e.preventDefault();
        if (this.currentPage < this.totalPages) {
            this.pageChange.emit(this.currentPage + 1);
            this.currentPage = this.currentPage + 1;
        }
    }
    /** Go to previous page if available */
    onPrevPage(event) {
        event.preventDefault();
        if (this.currentPage > 1) {
            this.pageChange.emit(this.currentPage - 1);
            this.currentPage = this.currentPage - 1;
        }
    }
    /** Go to specific page */
    onGoToPage(page) {
        if (page >= 1 && page <= this.totalPages) {
            this.pageChange.emit(page);
            this.currentPage = page;
        }
    }
    resetState() {
        // pick the right “selected” and “holding”
        this.selectedPortfolio = this.selected || this.portfolios[0];
        this.holdingPortfolio = this.holding;
        // set open/closed to whatever `show` was bound as
        this.displayPortfolio = this.show;
        this.setBodyScroll(this.displayPortfolio);
    }
    togglePortfolio() {
        this.displayPortfolio = !this.displayPortfolio;
        this.setBodyScroll(this.displayPortfolio);
    }
    onSelect(portfolio) {
        this.selectedPortfolio = portfolio;
        this.clicked.emit(portfolio);
        this.displayPortfolio = false;
        this.setBodyScroll(false);
    }
    setBodyScroll(isOpen) {
        const body = document.body;
        if (isOpen) {
            this.renderer.addClass(body, 'overflow-hidden');
        }
        else {
            this.renderer.removeClass(body, 'overflow-hidden');
        }
    }
}
PortfolioComponent.decorators = [
    { type: Component, args: [{
                selector: 'ds-portfolio',
                template: "<div\n  id=\"ds-portfolio\"\n  class=\"relative z-[1000] isolate w-full flex flex-col gap-3 shrink-0\"\n  [ngClass]=\"className\"\n>\n  <ds-portfolio-select-card\n    [title]=\"selectedPortfolio.title\"\n    [reference]=\"selectedPortfolio.reference\"\n    [image]=\"selectedPortfolio.image\"\n    [isOpen]=\"displayPortfolio\"\n    [className]=\"'max-w-fit'\"\n    (clicked)=\"togglePortfolio()\"\n  ></ds-portfolio-select-card>\n  <div\n    *ngIf=\"displayPortfolio\"\n    (click)=\"togglePortfolio()\"\n    class=\"fixed z-[999] bg-black/20 inset-0 w-full h-full\"\n  ></div>\n\n  <div\n    @dropdownAnim\n    *ngIf=\"displayPortfolio\"\n    class=\"absolute z-[1000] left-0 top-14 rounded-lg p-[14px] flex flex-col gap-[14px] w-full bg-card-level-5 min-w-[300px] max-w-fit shadow-dropdown\"\n  >\n    <ng-container *ngIf=\"holding\" class=\"flex flex-col gap-y-3\">\n      <ds-portfolio-vision-card\n        [title]=\"holding.title\"\n        [image]=\"holding.image\"\n        (clicked)=\"onSelect(holding)\"\n        [isSelected]=\"holding.id == selectedPortfolio.id\"\n      ></ds-portfolio-vision-card>\n    </ng-container>\n\n    <div class=\"space-y-4\">\n      <div class=\"flex flex-col gap-y-3\">\n        <ds-portfolio-item-card\n          *ngFor=\"let portfolio of getPaginatedPortfolios()\"\n          [title]=\"portfolio.title\"\n          [image]=\"portfolio.image\"\n          [isSelected]=\"portfolio.id == selectedPortfolio.id\"\n          (clicked)=\"onSelect(portfolio)\"\n        ></ds-portfolio-item-card>\n      </div>\n\n      <div class=\"flex justify-between items-center\">\n        <div>\n          <p class=\"text-[0.875rem]/[1rem] font-medium text-neutral-500\">\n            {{ getStartIndex() }}-{{ getEndIndex() }} of {{ portfolios.length }}\n          </p>\n        </div>\n        <div\n          *ngIf=\"showDots && totalPages > 1\"\n          class=\"flex justify-center gap-1 items-center\"\n        >\n          <button\n            (click)=\"onPrevPage($event)\"\n            class=\"p-0.5\"\n            [ngClass]=\"[\n              currentPage === 1\n                ? 'opacity-40 cursor-not-allowed'\n                : 'opacity-100'\n            ]\"\n            [disabled]=\"currentPage === 1 ? true : false\"\n          >\n            <ds-icon size=\"12px\" id=\"arrow-left\"></ds-icon>\n          </button>\n          <button\n            *ngFor=\"let page of pages\"\n            class=\"rounded-full size-2 flex transition-all duration-300 ease-in-out justify-center items-center text-neutral-800 hover:bg-neutral-200\"\n            [ngClass]=\"[page === currentPage ? 'bg-red-500' : 'bg-neutral-50']\"\n            (click)=\"onGoToPage(page)\"\n          ></button>\n          <button\n            [ngClass]=\"[\n              currentPage === totalPages\n                ? 'opacity-40 cursor-not-allowed'\n                : 'opacity-100'\n            ]\"\n            [disabled]=\"currentPage === totalPages ? true : false\"\n            (click)=\"onNextPage($event)\"\n            class=\"p-0.5\"\n          >\n            <ds-icon size=\"12px\" id=\"arrow-right\"></ds-icon>\n          </button>\n        </div>\n      </div>\n    </div>\n  </div>\n</div>\n",
                animations: [
                    trigger('dropdownAnim', [
                        transition(':enter', [
                            style({ opacity: 0, transform: 'scale(0.95)' }),
                            animate('200ms ease-out', style({ opacity: 1, transform: 'scale(1)' })),
                        ]),
                        transition(':leave', [
                            animate('150ms ease-in', style({ opacity: 0, transform: 'scale(0.95)' })),
                        ]),
                    ]),
                ]
            }] }
];
/** @nocollapse */
PortfolioComponent.ctorParameters = () => [
    { type: Renderer2 }
];
PortfolioComponent.propDecorators = {
    portfolios: [{ type: Input }],
    selected: [{ type: Input }],
    holding: [{ type: Input }],
    show: [{ type: Input }],
    showDots: [{ type: Input }],
    perPage: [{ type: Input }],
    totalItems: [{ type: Input }],
    className: [{ type: Input }],
    currentPage: [{ type: Input }],
    totalPages: [{ type: Input }],
    pageChange: [{ type: Output }],
    clicked: [{ type: Output }]
};

/**
 * AccountCardComponent
 *
 * Live demo:
 * <example-url>/demo/ds-account-card.component.html</example-url>
 */
class AccountCardComponent {
    constructor() {
        this.isDiscrete = false;
        this.isFavorite = false;
        this.actionsList = [];
        this.className = '';
    }
    ngOnInit() {
        this.actionsList = this.actionsList.map((action) => (Object.assign({}, action, { onClick: (event) => action.onClick &&
                action.onClick({
                    event: event,
                    data: this.data,
                }) })));
    }
}
AccountCardComponent.decorators = [
    { type: Component, args: [{
                selector: 'ds-account-card',
                template: "<article\n  id=\"ds-account-card\"\n  class=\"shrink-0 text-neutral-900 rounded-lg relative p-px after:rounded-[7px] after:absolute after:inset-0 after:bg-red-10 after:-z-[1] z-[2] bg-level-3\"\n>\n  <!-- [ngStyle]=\"{\n      'background-image':\n        solde_comptable > 0\n          ? 'linear-gradient(325deg, hsl(152deg 82% 95%) 0%, rgb(var(--color-neutral-25)) 30%)'\n          : 'linear-gradient(325deg, hsl(357deg 82% 95%) 0%, rgb(var(--color-neutral-25)) 30%)'\n    }\" -->\n  <!-- Top Block -->\n  <div class=\"relative rounded-t-lg p-4\">\n    <ds-dropdown\n      class=\"absolute top-4 right-3\"\n      [items]=\"actionsList\"\n      anchor=\"bottom end\"\n    >\n      <ds-icon id=\"dot-vertical\" size=\"18\"></ds-icon>\n    </ds-dropdown>\n\n    <!-- Account Info -->\n    <div class=\"flex flex-col gap-3\" *ngIf=\"type || account_number\">\n      <h3 *ngIf=\"type\" class=\"inline-flex gap-2 items-center\">\n        <ds-icon *ngIf=\"!isFavorite\" id=\"bank2\" size=\"14\"></ds-icon>\n        <ds-icon *ngIf=\"isFavorite\" id=\"star-bold\" size=\"14\" class=\"!text-yellow-500\"></ds-icon>\n        <span class=\"text-[1rem]/[20px] font-medium truncate mr-5\">\n          {{type}}\n        </span>\n      </h3>\n\n      <p\n        *ngIf=\"account_number\"\n        class=\"text-[0.875rem]/[1rem] font-bold inline-flex gap-px\"\n      >\n        <sup class=\"inline-flex mt-2.5 font-light\">N\u00B0</sup>\n        {{ account_number }}\n      </p>\n    </div>\n\n    <div class=\"flex items-center justify-between w-full mt-2.5\">\n      <span class=\"text-[0.75rem]/[1rem] text-neutral-900\">\n        Solde en temps r\u00E9el\n      </span>\n\n      <ds-balance-formatter\n        *ngIf=\"solde_temps_reel || currency\"\n        [isDiscrete]=\"isDiscrete\"\n        [balance]=\"solde_temps_reel || 0\"\n        [currency]=\"currency\"\n        [currencyClassName]=\"'text-[0.875rem]/[1rem]'\"\n      >\n      </ds-balance-formatter>\n    </div>\n  </div>\n\n  <hr class=\"w-[80%] mx-auto h-px bg-stroke-3 border-stroke-3\" />\n  <!-- Bottom Block -->\n  <div class=\"px-4 py-3 flex justify-between items-center gap-2\">\n    <span class=\"self-start text-[0.75rem]/[1rem] text-neutral-900\">\n      Solde comptable\n    </span>\n    <ds-balance-formatter\n      *ngIf=\"solde_comptable\"\n      [isDiscrete]=\"isDiscrete\"\n      [balance]=\"solde_comptable\"\n      [currency]=\"currency\"\n      [currencyClassName]=\"'text-[0.875rem]/[1.125rem]'\"\n    >\n    </ds-balance-formatter>\n  </div>\n</article>\n"
            }] }
];
AccountCardComponent.propDecorators = {
    isDiscrete: [{ type: Input }],
    isFavorite: [{ type: Input }],
    account_number: [{ type: Input }],
    balance: [{ type: Input }],
    currency: [{ type: Input }],
    type: [{ type: Input }],
    id: [{ type: Input }],
    actionsList: [{ type: Input }],
    solde_comptable: [{ type: Input }],
    solde_temps_reel: [{ type: Input }],
    className: [{ type: Input }],
    data: [{ type: Input }]
};

// slider-dots.theme.ts
const SliderDotsTheme = {
    /**
     * ──────────────────────────────────────────────────────────────────────────────
     * DEFAULT VARIANT
     * ──────────────────────────────────────────────────────────────────────────────
     */
    default: {
        container: 'flex items-center gap-3',
        dotsWrapper: 'flex items-center justify-center gap-3',
        dot: {
            base: 'rounded-[2px] transition-colors cursor-pointer',
            size: 'size-2',
            activeBg: 'bg-red-500',
            inactiveBg: 'bg-neutral-200',
        },
        arrow: {
            wrapper: 'cursor-pointer flex items-center justify-center',
            activeText: 'text-neutral-500',
            disabledText: 'text-gray-400',
            disabledOpacity: 'opacity-40 !cursor-not-allowed',
        },
    },
};

/**
 * SliderDotsComponent
 *
 * Live demo:
 * <example-url>/demo/ds-slider-dots.component.html</example-url>
 */
class SliderDotsComponent {
    constructor() {
        /**
         * Number of dots/slides to display.
         * Must be ≥ 1.
         **/
        this.count = 3;
        this.className = '';
        /** 0-based index of the currently “active” slide. */
        this.active = 0;
        this.doNotDisableArrows = false;
        /**
         * Which theme (variant) from SliderDotsTheme to use.
         * E.g. 'default', 'red', or any other key in SliderDotsTheme.
         */
        this.variant = 'default';
        /** If false, arrows are completely hidden. */
        this.showArrows = true;
        //
        // ─── OUTPUT EVENTS ─────────────────────────────────────────────────────────────
        //
        /** Emits the chosen dot index (0-based) when the user clicks a dot. */
        this.select = new EventEmitter();
        /** Emits when user clicks the “Prev” arrow (if not disabled). */
        this.prev = new EventEmitter();
        /** Emits when user clicks the “Next” arrow (if not disabled). */
        this.next = new EventEmitter();
    }
    /**
     * Convenience getter: returns the theme object for the current `themeName`,
     * or falls back to `default` if the key is missing.
     */
    get theme() {
        return SliderDotsTheme[this.variant] || SliderDotsTheme['default'];
    }
    /** Build an array [0, 1, 2, …, count-1] to loop over in the template. */
    get indices() {
        return Array(this.count)
            .fill(0)
            .map((_, i) => i);
    }
    /** Is “Prev” arrow currently disabled (because active is already 0)? */
    get isPrevDisabled() {
        return this.active <= 0;
    }
    /** Is “Next” arrow currently disabled (because active is at count-1)? */
    get isNextDisabled() {
        return this.active >= this.count - 1;
    }
    /** Handler for clicking Prev: only emit if not disabled. */
    onPrev() {
        if (this.doNotDisableArrows) {
            this.next.emit();
            return;
        }
        if (!this.isPrevDisabled) {
            this.prev.emit();
        }
    }
    /** Handler for clicking Next: only emit if not disabled. */
    onNext() {
        if (this.doNotDisableArrows) {
            this.next.emit();
            return;
        }
        if (!this.isNextDisabled) {
            this.next.emit();
        }
    }
    /** Handler for clicking a dot at index i: only emit if i !== active. */
    onSelect(i) {
        if (i !== this.active) {
            this.select.emit(i);
        }
    }
    /**
     * CSS classes for the “Prev” arrow’s wrapper.
     * If disabled, append the `disabledOpacity` classes.
     */
    get prevArrowWrapperClass() {
        const base = this.theme.arrow.wrapper;
        if (this.doNotDisableArrows) {
            return base;
        }
        return this.isPrevDisabled
            ? `${base} ${this.theme.arrow.disabledOpacity}`
            : base;
    }
    /**
     * CSS classes for the “Next” arrow’s wrapper.
     * If disabled, append the `disabledOpacity` classes.
     */
    get nextArrowWrapperClass() {
        const base = this.theme.arrow.wrapper;
        if (this.doNotDisableArrows) {
            return base;
        }
        return this.isNextDisabled
            ? `${base} ${this.theme.arrow.disabledOpacity}`
            : base;
    }
    /**
     * CSS classes for the <ds-icon> inside **both** arrows, when “enabled.”
     * (We assume the icon’s color should match `activeText`.)
     * When disabled, we replace that with `disabledText`.
     */
    get prevIconClass() {
        if (this.doNotDisableArrows) {
            return `${this.theme.arrow.activeText}`;
        }
        return this.isPrevDisabled
            ? `${this.theme.arrow.disabledText}`
            : `${this.theme.arrow.activeText}`;
    }
    get nextIconClass() {
        if (this.doNotDisableArrows) {
            return `${this.theme.arrow.activeText}`;
        }
        return this.isNextDisabled
            ? `${this.theme.arrow.disabledText}`
            : `${this.theme.arrow.activeText}`;
    }
}
SliderDotsComponent.decorators = [
    { type: Component, args: [{
                selector: 'ds-slider-dots',
                template: "<!--\n  Outer container: use theme.container to lay out arrows + dots.\n  e.g. 'flex items-center justify-center' or any other classes you put in theme.\n-->\n<div id=\"ds-slider-dots\" [ngClass]=\"[theme.container, className]\">\n  <!-- \u2500\u2500\u2500 PREV ARROW (conditionally shown) \u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500 -->\n  <button\n    *ngIf=\"showArrows\"\n    (click)=\"onPrev()\"\n    [ngClass]=\"prevArrowWrapperClass\"\n  >\n    <!-- \n      We pass [name] to <ds-icon> (change if your icon API is different).\n      We bind [ngClass] so that the icon\u2019s color/size come from the theme.\n    -->\n    <ds-icon [id]=\"'arrow-left'\" size=\"12px\" [class]=\"prevIconClass\"></ds-icon>\n  </button>\n\n  <!-- \u2500\u2500\u2500 DOTS ROW \u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500 -->\n  <div [ngClass]=\"theme.dotsWrapper\">\n    <ng-container *ngFor=\"let _ of indices; let idx = index\">\n      <div\n        (click)=\"onSelect(idx)\"\n        [ngClass]=\"[\n          theme.dot.base,\n          theme.dot.size,\n          idx === active ? theme.dot.activeBg : theme.dot.inactiveBg\n        ]\"\n      ></div>\n    </ng-container>\n  </div>\n\n  <!-- \u2500\u2500\u2500 NEXT ARROW (conditionally shown) \u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500 -->\n  <button\n    *ngIf=\"showArrows\"\n    (click)=\"onNext()\"\n    [ngClass]=\"nextArrowWrapperClass\"\n  >\n    <ds-icon [id]=\"'arrow-right'\" size=\"12px\" [class]=\"nextIconClass\"></ds-icon>\n  </button>\n</div>\n"
            }] }
];
SliderDotsComponent.propDecorators = {
    count: [{ type: Input }],
    className: [{ type: Input }],
    active: [{ type: Input }],
    doNotDisableArrows: [{ type: Input }],
    variant: [{ type: Input }],
    showArrows: [{ type: Input }],
    select: [{ type: Output }],
    prev: [{ type: Output }],
    next: [{ type: Output }]
};

/**
 * TodoCardComponent
 *
 * Live demo:
 * <example-url>/demo/ds-todo-card.component.html</example-url>
 */
class TodoCardComponent {
    constructor() {
        this.title = '';
        this.description = '';
        this.date = '';
        this.badgeText = '';
        this.badgeVariant = '';
        this.icon = '';
        this.isRead = false;
        this.className = '';
    }
}
TodoCardComponent.decorators = [
    { type: Component, args: [{
                selector: 'ds-todo-card',
                template: "<div\n  id=\"ds-todo-card\"\n  class=\"flex gap-2 items-start justify-start p-2\"\n  [ngClass]=\"[\n    className,\n    isRead\n      ? 'border-l border-red-500 bg-card-level-6'\n      : 'border-b border-stroke-1 bg-level-4'\n  ]\"\n>\n  <span\n    *ngIf=\"icon\"\n    class=\"inline-flex shrink-0 border border-stroke-1 bg-card-level-2 rounded-full size-[36px] gap-2 items-center justify-center\"\n  >\n    <ds-icon [id]=\"icon\" size=\"18px\" class=\"text-red-500\"></ds-icon>\n  </span>\n\n  <div class=\"flex flex-col gap-3\">\n    <h3 class=\"text-[0.875rem] leading-[16px] font-bold\">{{ title }}</h3>\n    <p *ngIf=\"description\" class=\"text-[0.75rem] leading-[16px] text-neutral-700\">\n      {{ description }}\n    </p>\n    <ds-badge\n      *ngIf=\"badgeText\"\n      pill=\"true\"\n      [label]=\"badgeText\"\n      size=\"sm\"\n      [variant]=\"badgeVariant\"\n    ></ds-badge>\n\n    <p\n      *ngIf=\"date\"\n      class=\"text-[0.75rem] flex items-center justify-start leading-[16px] text-neutral-700 gap-2\"\n    >\n      <ds-icon id=\"clock\" size=\"14px\" class=\"inline-block\"></ds-icon>\n      <span class=\"inline-block mt-px\">\n        Date d\u2019\u00E9ch\u00E9ance : {{ date | date : \"dd.MM.yyyy\" }}\n      </span>\n    </p>\n  </div>\n</div>\n"
            }] }
];
TodoCardComponent.propDecorators = {
    title: [{ type: Input }],
    description: [{ type: Input }],
    date: [{ type: Input }],
    badgeText: [{ type: Input }],
    badgeVariant: [{ type: Input }],
    icon: [{ type: Input }],
    isRead: [{ type: Input }],
    className: [{ type: Input }]
};

/**
 * TodoTabComponent
 *
 * Live demo:
 * <example-url>/demo/ds-todo-tab.component.html</example-url>
 */
class TodoTabComponent {
    constructor() {
        this.title = '';
        this.count = 0;
        this.icon = '';
        this.isOpen = false;
        this.className = '';
    }
}
TodoTabComponent.decorators = [
    { type: Component, args: [{
                selector: 'ds-todo-tab',
                template: "<div\n  id=\"ds-todo-tab\"\n  class=\"text-neutral-900 flex flex-col gap-2 py-3 border-b transition-all duration-500 ease-in-out\"\n  [ngClass]=\"[className, isOpen ? ' border-red-500' : 'border-transparent']\"\n  (click)=\"onClick && onClick()\"\n  tabindex=\"0\"\n  role=\"button\"\n>\n  <span\n    class=\"inline-flex gap-2 text-neutral-600 items-center font-bold justify-start text-[2rem] leading-[32px]\"\n  >\n    {{ count }}\n    <ds-icon\n      [id]=\"icon\"\n      *ngIf=\"icon\"\n      size=\"20px\"\n      class=\"text-red-500\"\n    ></ds-icon>\n  </span>\n  <div class=\"flex items-center gap-2 justify-between w-full\">\n    <h3 class=\"text-[0.75rem] leading-[16px] font-medium\">{{ title }}</h3>\n    <ds-icon\n      id=\"arrow-down\"\n      [class]=\"[\n        'transition-all duration-500 ease-in-out',\n        isOpen ? 'rotate-180 text-red-500' : ''\n      ]\"\n    ></ds-icon>\n  </div>\n</div>\n"
            }] }
];
TodoTabComponent.propDecorators = {
    title: [{ type: Input }],
    count: [{ type: Input }],
    icon: [{ type: Input }],
    isOpen: [{ type: Input }],
    onClick: [{ type: Input }],
    className: [{ type: Input }]
};

class DatePickerComponent {
    constructor() {
        this.type = 'range';
        this.autoApply = true;
        this.linkedCalendars = true;
        this.showDropdowns = true;
        this.alwaysShowCalendars = false;
        this.keepCalendarOpeningWithRange = false;
        this.showRangeLabelOnInput = false;
        this.customRangeDirection = false;
        this.lockStartDate = false;
        this.choosedDate = new EventEmitter();
        this.isCustomDate = new EventEmitter();
        this.rangeClicked = new EventEmitter();
        this.datesUpdated = new EventEmitter();
    }
    choosedDateHandler(event) {
        this.choosedDate.emit(event);
    }
    isCustomDateHandler(value) {
        this.isCustomDate.emit(value);
    }
}
DatePickerComponent.decorators = [
    { type: Component, args: [{
                selector: 'ds-date-picker',
                template: "<!-- <ng-container *ngIf=\"type === 'range'\">\n  <ngx-daterangepicker-material\n    (choosedDate)=\"choosedDateHandler($event)\"\n    (isCustomDate)=\"isCustomDateHandler($event)\"\n    [autoApply]=\"autoApply\"\n    [linkedCalendars]=\"linkedCalendars\"\n    [showDropdowns]=\"showDropdowns\"\n    [minDate]=\"minDate\"\n    [maxDate]=\"maxDate\"\n    [dateLimit]=\"dateLimit\"\n    [alwaysShowCalendars]=\"alwaysShowCalendars\"\n    [keepCalendarOpeningWithRange]=\"keepCalendarOpeningWithRange\"\n    [showRangeLabelOnInput]=\"showRangeLabelOnInput\"\n    [customRangeDirection]=\"customRangeDirection\"\n    [lockStartDate]=\"lockStartDate\"\n  >\n  </ngx-daterangepicker-material>\n</ng-container>\n<ng-container *ngIf=\"type === 'single'\">\n  <input\n    type=\"text\"\n    ngxDaterangepickerMd\n    [(ngModel)]=\"selected\"\n    class=\"border border-red-500 rounded-md p-2 w-full\"\n    (choosedDate)=\"choosedDateHandler($event)\"\n    (isCustomDate)=\"isCustomDateHandler($event)\"\n    [autoApply]=\"autoApply\"\n    [linkedCalendars]=\"linkedCalendars\"\n    [showDropdowns]=\"showDropdowns\"\n    [minDate]=\"minDate\"\n    [maxDate]=\"maxDate\"\n    [dateLimit]=\"dateLimit\"\n    [alwaysShowCalendars]=\"alwaysShowCalendars\"\n    [keepCalendarOpeningWithRange]=\"keepCalendarOpeningWithRange\"\n    [showRangeLabelOnInput]=\"showRangeLabelOnInput\"\n    [customRangeDirection]=\"customRangeDirection\"\n    [lockStartDate]=\"lockStartDate\"\n  />\n</ng-container>\n\n<style>\n  ::ng-deep ngx-daterangepicker-material {\n    .md-drppicker {\n      border-radius: 8px;\n      background: rgb(var(--color-neutral-25) / 1);\n      /* background: linear-gradient(\n        217deg,\n        rgb(var(--gradient-red) / 1) 2.44%,\n        rgb(var(--gradient) / 1) 43.42%\n      ); */\n\n      /* Main table reset */\n      & .calendar-table {\n        background-color: transparent;\n        border: none;\n      }\n\n      /* Cell base styles (including available:hover) */\n      & td,\n      & td.available:hover {\n        margin: 0 !important;\n        padding: 10px !important;\n        border: none;\n        border-radius: 4px !important;\n        opacity: 100% !important;\n      }\n\n      /* Hover backgrounds for cells and headers */\n      & td.available:hover,\n      & th.available:hover,\n      & td:hover {\n        background-color: rgb(var(--color-neutral-100) / 1);\n      }\n\n      /* Additional hover on any cell */\n      & td:hover {\n        border-color: transparent;\n        color: rgb(var(--color-neutral-900) / 1);\n      }\n\n      /* In-range (but not active) cells */\n      & td.in-range:not(.active) {\n        background-color: rgb(var(--card-level-2) / 1);\n        border-radius: 0 !important;\n        color: rgb(var(--color-neutral-900) / 1);\n      }\n\n      /* Active cell states */\n      & td.active,\n      & td.active:hover {\n        background-color: rgb(var(--color-red-500));\n        border-color: transparent;\n        color: #fff;\n      }\n\n      /* Calendar column widths */\n      & .calendar td,\n      & .calendar th {\n        width: 41px !important;\n      }\n\n      & td.off.available,\n      & td.off.available:hover {\n        opacity: 0 !important;\n        visibility: hidden;\n        cursor: default;\n        background-color: transparent !important;\n        border-color: transparent !important;\n        color: transparent !important;\n      }\n\n      /* \u201COff\u201D days */\n      & td.off,\n      & td.off.in-range,\n      & td.off.start-date {\n        background-color: transparent;\n        border-color: transparent;\n        color: #fff;\n      }\n\n      /* Start/end date rounding */\n      & td.active.start-date {\n        border-radius: 4px 0 0 4px !important;\n      }\n      & td.active.end-date {\n        border-radius: 0 4px 4px 0 !important;\n      }\n      & td.active.end-date.start-date {\n        border-radius: 4px !important;\n      }\n\n      /* Dropdowns width */\n      & .dropdowns {\n        width: 60px !important;\n      }\n    }\n  }\n</style> -->\n\nDATE PICKER COMPONENT\n"
            }] }
];
DatePickerComponent.propDecorators = {
    type: [{ type: Input }],
    autoApply: [{ type: Input }],
    linkedCalendars: [{ type: Input }],
    showDropdowns: [{ type: Input }],
    alwaysShowCalendars: [{ type: Input }],
    keepCalendarOpeningWithRange: [{ type: Input }],
    showRangeLabelOnInput: [{ type: Input }],
    customRangeDirection: [{ type: Input }],
    lockStartDate: [{ type: Input }],
    minDate: [{ type: Input }],
    maxDate: [{ type: Input }],
    dateLimit: [{ type: Input }],
    choosedDate: [{ type: Output }],
    isCustomDate: [{ type: Output }],
    rangeClicked: [{ type: Output }],
    datesUpdated: [{ type: Output }]
};

const uploadFileThemes = {
    default: {
        wrapper: 'relative py-4 px-6 border border-dashed border-neutral-100 flex flex-col gap-3 text-neutral-500 rounded-lg text-center bg-neutral-25 transition cursor-pointer',
        icon: 'mx-auto size-10 shrink-0 flex justify-center items-center bg-white rounded-md text-gray-400',
        text: 'text-sm flex flex-col gap-1',
    },
};

// upload-file.component.ts
/**
 * Upload-fileComponent
 *
 * Live demo:
 * <example-url>/demo/ds-upload-file.component.html</example-url>
 */
class UploadFileComponent {
    constructor() {
        this.variant = 'default';
        this.maxFileSizeMB = 10;
        this.allowedExtensions = ['csv'];
        this.className = '';
        this.isMultiple = false;
        this.errors = [];
        this.hasError = false;
        this.progress = 0;
        this.loading = false;
        /** If true, we'll fake the upload progress (instead of immediately reading). */
        this.simulateSlowUpload = false;
        this.fileSelected = new EventEmitter();
        this.theme = uploadFileThemes;
        /** for preview */
        this.selectedFile = null;
        this.selectedFiles = [];
        this.previewRows = [];
        /** for errors accordion */
        this.showErrors = false;
    }
    ngOnChanges(changes) {
        if (changes['progress']) {
            console.log('Progress changed:', changes['progress'].currentValue);
        }
    }
    ngOnInit() {
        this.currentTheme = this.theme[this.variant] || this.theme.light;
    }
    openFileInput() {
        if (this.fileInput && this.fileInput.nativeElement) {
            this.fileInput.nativeElement.click();
        }
    }
    generateUniqueId() {
        return Date.now().toString(36) + Math.random().toString(36).substr(2);
    }
    addUniqueIdToFile(file) {
        const fileWithId = file;
        fileWithId.uniqueId = this.generateUniqueId();
        return fileWithId;
    }
    onFileChange(evt) {
        const input = evt.target;
        if (!input.files || input.files.length === 0)
            return;
        if (this.isMultiple) {
            this.handleMultipleFiles(Array.from(input.files));
        }
        else {
            this.handleFile(input.files[0]);
        }
    }
    onDrop(evt) {
        evt.preventDefault();
        if (!evt.dataTransfer)
            return;
        this.handleFile(evt.dataTransfer.files[0]);
    }
    onDragOver(evt) {
        evt.preventDefault();
    }
    handleMultipleFiles(files) {
        for (const file of files) {
            this.handleFile(file);
        }
    }
    removeFile(uniqueId) {
        this.selectedFiles = this.selectedFiles.filter(file => file.uniqueId !== uniqueId);
    }
    toggleErrors() {
        this.showErrors = !this.showErrors;
    }
    handleFile(file) {
        // Validate extension
        const ext = (file.name.split('.').pop() || '').toLowerCase();
        if (!this.allowedExtensions.includes(ext)) {
            alert(`Invalid file type. Allowed: ${this.allowedExtensions.join(', ')}`);
            return;
        }
        // Validate size
        if (file.size > this.maxFileSizeMB * 1024 * 1024) {
            alert(`Max file size is ${this.maxFileSizeMB} MB`);
            return;
        }
        // Add unique ID to file
        const fileWithId = this.addUniqueIdToFile(file);
        if (this.isMultiple) {
            this.selectedFiles.push(fileWithId);
            this.loading = true;
            this.progress = 0;
        }
        else {
            this.selectedFile = fileWithId;
        }
        // real‐world: immediately show preview/progress
        // this.parsePreview(fileWithId);
        this.fileSelected.emit(fileWithId);
    }
    getErrorsContent() {
        if (!this.errors || this.errors.length === 0) {
            return '';
        }
        const errorsList = this.errors.map(error => `<li class="text-red-600 text-sm py-1">${error}</li>`).join('');
        return `<ul class="list-disc ml-4 space-y-1">${errorsList}</ul>`;
    }
}
UploadFileComponent.decorators = [
    { type: Component, args: [{
                selector: 'ds-upload-file',
                template: "<div\n  id=\"ds-upload-file\"\n  [ngClass]=\"[currentTheme.wrapper, className]\"\n  (drop)=\"onDrop($event)\"\n  (dragover)=\"onDragOver($event)\"\n  (click)=\"openFileInput()\"\n>\n  <div [ngClass]=\"currentTheme.icon\">\n    <ds-icon id=\"upload-cloud\" size=\"20px\" class=\"text-red-500\"></ds-icon>\n  </div>\n\n  <div [ngClass]=\"[currentTheme.text]\" class=\"relative\">\n    <p><strong>S\u00E9lectionnez votre fichier</strong> ou d\u00E9posez-le</p>\n    <input\n      #fileInput\n      type=\"file\"\n      [accept]=\"'.' + allowedExtensions.join(',.')\"\n      class=\"absolute inset-0 opacity-0 cursor-pointer\"\n      (change)=\"onFileChange($event)\"\n    />\n    <ng-content></ng-content>\n  </div>\n</div>\n\n<ng-container *ngIf=\"loading && !isMultiple; else selected\" class=\"mt-2\">\n  <div\n    *ngIf=\"selectedFile\"\n    class=\"relative border overflow-hidden border-red-200 bg-level-3 rounded-lg p-4 mt-2\"\n  >\n    <div\n      class=\"absolute inset-0 h-full bg-red-50 w-1/4 transition-all duration-300 ease-in-out\"\n      [style.width]=\"progress + '%'\"\n    ></div>\n    <div class=\"relative w-full z-[1] flex gap-4 items-center justify-start\">\n      <div\n        class=\"flex items-center justify-center rounded-md w-8 h-8 bg-level-3 text-red-500\"\n      >\n        <ds-icon id=\"file-edit-02\" size=\"16px\"></ds-icon>\n      </div>\n\n      <div class=\"flex flex-col gap-1 text-neutral-700\">\n        <p class=\"text-[1rem]/[1.375rem] font-bold\">\n          {{ selectedFile.name }}\n        </p>\n        <p class=\"text-[0.875rem]/[1.25rem] font-normal\">\n          {{ (selectedFile.size / 1024 / 1024).toFixed(2) }} Mo\n        </p>\n      </div>\n      <span\n        class=\"absolute right-3 top-1/2 -translate-y-1/2 font-medium text-[1rem]/[1.25rem]\"\n      >\n        {{ progress }} %\n      </span>\n    </div>\n  </div>\n</ng-container>\n\n<!-- Preview section -->\n<ng-template #selected>\n  <div\n    *ngIf=\"selectedFile && !isMultiple\"\n    [ngClass]=\"[\n      'relative border border-green-100 rounded-lg p-4 mt-2',\n      hasError ? 'bg-error-25' : 'bg-level-4'\n    ]\"\n  >\n    <div class=\"flex items-center justify-between gap-4\">\n      <div class=\"flex items-center gap-4\">\n        <div\n          class=\"flex items-center justify-center rounded-md w-8 h-8\"\n          [ngClass]=\"[hasError ? 'bg-rose-100 text-rose-500' : 'bg-green-50 text-green-500']\"\n        >\n          <ds-icon id=\"file-edit-02\" size=\"16px\"></ds-icon>\n        </div>\n        <div\n          [ngClass]=\"[\n            'flex flex-col gap-1',\n            hasError ? 'text-rose-700' : 'text-neutral-700'\n          ]\"\n        >\n          <p class=\"text-[1rem]/[1.375rem] font-medium\">\n            {{ selectedFile.name }}\n          </p>\n          <p class=\"text-[0.875rem]/[1.25rem] font-normal\">\n            {{ (selectedFile.size / 1024 / 1024).toFixed(2) }} Mo - 100% T\u00E9l\u00E9charg\u00E9\n          </p>\n        </div>\n        <span\n          *ngIf=\"!hasError\"\n          class=\"absolute right-3 top-0 bottom-0 m-auto rounded-full text-white bg-green-500 flex items-center justify-center w-5 h-5\"\n        >\n          <ds-icon id=\"check\" size=\"16px\" class=\"shrink-0\"></ds-icon>\n        </span>\n      </div>\n      <button\n        (click)=\"openFileInput()\"\n        *ngIf=\"hasError\"\n        class=\"rounded-full text-rose-700 flex items-center justify-center w-5 h-5\"\n      >\n        <ds-icon id=\"arrow-refresh-03\" size=\"20px\" class=\"shrink-0\"></ds-icon>\n      </button>\n    </div>\n    <div *ngIf=\"errors && errors.length > 0\" class=\"mt-3\">\n      <div class=\"overflow-hidden\">\n        <button\n          type=\"button\"\n          class=\"w-full text-left transition-colors duration-200 flex items-center justify-start gap-x-2\"\n          (click)=\"toggleErrors()\"\n          [attr.aria-expanded]=\"showErrors\"\n          aria-controls=\"errors-panel\"\n        >\n          <ds-icon \n            [id]=\"showErrors ? 'arrow-up' : 'arrow-down'\" \n            size=\"16px\" \n            class=\"transition-transform duration-200\"\n            [ngClass]=\"{'rotate-180': showErrors}\"\n          ></ds-icon>\n          <span class=\"font-medium text-sm text-black\">Please check this errors</span>\n          \n        </button>\n        \n        <div \n          id=\"errors-panel\"\n          class=\"mt-2\"\n          [ngClass]=\"{'max-h-0 overflow-hidden': !showErrors, 'max-h-96 overflow-y-auto': showErrors}\"\n          style=\"transition: max-height 0.3s ease-in-out;\"\n        >\n          <ul class=\"space-y-1\">\n            <li \n              *ngFor=\"let error of errors\" \n              class=\"flex items-start gap-2 text-rose-700\"\n            >\n              <ds-icon id=\"dash\" size=\"16px\" class=\"text-error-500 mt-0.5 flex-shrink-0\"></ds-icon>\n              <span class=\"text-sm\">{{ error }}</span>\n            </li>\n          </ul>\n        </div>\n      </div>\n    </div>\n  </div>\n\n  <!-- Multiple files selected template -->\n  <div\n    *ngIf=\"selectedFiles && selectedFiles.length > 0 && isMultiple\"\n    class=\"mt-4 space-y-3\"\n  >\n    <div\n      *ngFor=\"let file of selectedFiles.slice(0, -1)\"\n      class=\"relative border border-green-100 bg-level-4 rounded-lg p-4 flex gap-4 items-center justify-between\"\n    >\n      <div class=\"flex items-center justify-start gap-4\">\n        <div\n          class=\"flex items-center justify-center rounded-md w-8 h-8\"\n          [ngClass]=\"[hasError ? 'bg-rose-100 text-rose-500' : 'bg-green-50 text-green-500']\"\n        >\n          <ds-icon id=\"file-edit-02\" size=\"16px\"></ds-icon>\n        </div>\n        <div class=\"flex flex-col gap-1 text-neutral-700\">\n          <p class=\"text-[1rem]/[1.375rem] font-bold\">\n            {{ file.name }}\n          </p>\n          <p class=\"text-[0.875rem]/[1.25rem] font-normal\">\n            {{ (file.size / 1024 / 1024).toFixed(2) }} Mo - 100% T\u00E9l\u00E9charg\u00E9\n          </p>\n        </div>\n      </div>\n      <button\n        (click)=\"removeFile(file?.uniqueId)\"\n        class=\"p-2 hover:bg-gray-50 rounded-full\"\n      >\n        <ds-icon id=\"trash\" size=\"16px\" class=\"shrink-0\"></ds-icon>\n      </button>\n    </div>\n\n    <ng-container *ngIf=\"!loading\">\n      <div\n        class=\"relative border border-green-100 bg-level-4 rounded-lg p-4 flex gap-4 items-center justify-between\"\n      >\n        <div class=\"flex items-center justify-start gap-4\">\n          <div\n            class=\"flex items-center justify-center rounded-md w-8 h-8\"\n            [ngClass]=\"[hasError ? 'bg-rose-100 text-rose-500' : 'bg-green-50 text-green-500']\"\n          >\n            <ds-icon id=\"file-edit-02\" size=\"16px\"></ds-icon>\n          </div>\n          <div class=\"flex flex-col gap-1 text-neutral-700\">\n            <p class=\"text-[1rem]/[1.375rem] font-bold\">\n              {{ selectedFiles[selectedFiles.length-1].name }}\n            </p>\n            <p class=\"text-[0.875rem]/[1.25rem] font-normal\">\n              {{ (selectedFiles[selectedFiles.length-1].size / 1024 / 1024).toFixed(2) }} Mo - 100% T\u00E9l\u00E9charg\u00E9\n            </p>\n          </div>\n        </div>\n        <button\n          (click)=\"removeFile(selectedFiles[selectedFiles.length-1]?.uniqueId)\"\n          class=\"p-2 hover:bg-gray-50 rounded-full\"\n        >\n          <ds-icon id=\"trash\" size=\"16px\" class=\"shrink-0\"></ds-icon>\n        </button>\n      </div>\n    </ng-container>\n\n    <ng-container *ngIf=\"loading\">\n      <div\n        class=\"relative border overflow-hidden border-red-200 bg-level-3 rounded-lg p-4 mt-2\"\n      >\n        <div\n          class=\"absolute inset-0 h-full bg-red-50 w-1/4 transition-all duration-300 ease-in-out\"\n          [style.width]=\"progress + '%'\"\n        ></div>\n        <div class=\"relative w-full z-[1] flex gap-4 items-center justify-start\">\n          <div\n            class=\"flex items-center justify-center rounded-md w-8 h-8 bg-level-3 text-red-500\"\n          >\n            <ds-icon id=\"file-edit-02\" size=\"16px\"></ds-icon>\n          </div>\n\n          <div class=\"flex flex-col gap-1 text-neutral-700\">\n            <p class=\"text-[1rem]/[1.375rem] font-bold\">\n              {{ selectedFiles[selectedFiles.length-1].name }}\n            </p>\n            <p class=\"text-[0.875rem]/[1.25rem] font-normal\">\n              {{ (selectedFiles[selectedFiles.length-1].size / 1024 / 1024).toFixed(2) }} Mo\n            </p>\n          </div>\n          <span\n            class=\"absolute right-3 top-1/2 -translate-y-1/2 font-medium text-[1rem]/[1.25rem]\"\n          >\n            {{ progress }} %\n          </span>\n        </div>\n      </div>\n    </ng-container>\n  </div>\n</ng-template>\n"
            }] }
];
UploadFileComponent.propDecorators = {
    variant: [{ type: Input }],
    maxFileSizeMB: [{ type: Input }],
    allowedExtensions: [{ type: Input }],
    className: [{ type: Input }],
    isMultiple: [{ type: Input }],
    errors: [{ type: Input }],
    hasError: [{ type: Input }],
    progress: [{ type: Input }],
    loading: [{ type: Input }],
    simulateSlowUpload: [{ type: Input }],
    fileSelected: [{ type: Output }],
    fileInput: [{ type: ViewChild, args: ['fileInput',] }]
};

const theme$6 = {
    default: {
        element: {
            label: 'inline-block text-neutral-900 font-bold text-sm mb-2',
            button: {
                select: 'cursor-default border text-[0.875rem] border-neutral-50 min-h-[40px] flex items-center justify-between w-full px-3 py-2 rounded bg-level-3 placeholder:text-[0.875rem] focus:ring-0 focus:outline-0 focus:border-primary hover:border-primary focus:outline-0 text-left placeholder:text-gray-700',
                selected: 'flex items-center justify-between gap-2',
                error: 'ring-1 ring-error-400 border-1 border-error-400 outline-1 border-1 border-error-400',
                iconeError: 'text-error-500',
                disabled: '!opacity-50 !bg-gray-100 text-neutral-900 placeholder:text-neutral-800 cursor-not-allowed !border-gray-100 hover:border-gray-100 hover:bg-transparent',
                label: 'text-heading dark:text-white !font-[400]',
                placeholder: 'text-heading dark:text-white text-[0.75rem]',
            },
            field: {
                activated: 'bg-gray-200 dark:bg-neutral-700',
            },
            icone: {
                arrow: 'text-heading dark:text-white w-4 h-4',
                checked: 'text-primary-500 w-5 h-5',
            },
            options: {
                selectedfont: 'flex text-heading dark:text-white items-center justify-between w-full',
                container: 'absolute top-0 border border-neutral-100 bottom-0 mb-1 mt-1 max-h-60 overflow-y-auto w-full rounded-lg bg-level-3 py-1 text-[0.75rem] leading-[14px] focus:outline-none border shadow-dropdown2',
                element: 'shrink-0 w-full hover:bg-neutral-50 rounded cursor-default text-neutral-900 font-bold select-none py-3 px-4',
                fontcolor: 'white',
                available: 'cursor-pointer',
                unavailable: 'cursor-not-allowed opacity-50 hover:bg-transparent',
            },
            error: 'text-error-500 mt-1 relative text-[0.75rem]',
        },
    },
    currency: {
        element: {
            label: 'inline-block text-neutral-900 font-bold text-sm mb-2',
            button: {
                select: 'cursor-default text-[0.625rem] flex items-center justify-end gap-2 w-full px-0 py-1.5 rounded bg-transparent placeholder:text-[0.875rem] focus:ring-0 focus:outline-0 focus:border-primary hover:border-primary focus:outline-0 text-left placeholder:text-gray-700',
                selected: 'flex items-center flex-row-reverse justify-between gap-2',
                error: 'ring-1 ring-error-400 border-1 border-error-400 outline-1 border-1 border-error-400',
                iconeError: 'text-error-500',
                disabled: '!opacity-50 text-neutral-900 placeholder:text-neutral-800 cursor-not-allowed hover:bg-transparent',
                label: 'text-heading dark:text-white !font-[400]',
                placeholder: 'text-heading dark:text-white text-[0.75rem]',
            },
            field: {
                activated: 'bg-gray-200 dark:bg-neutral-700',
            },
            icone: {
                arrow: 'text-heading dark:text-white w-4 h-4',
                checked: 'text-primary-500 w-5 h-5',
            },
            options: {
                selectedfont: 'flex text-heading dark:text-white items-center justify-between w-full ',
                container: 'absolute top-0 border border-neutral-100 bottom-0 p-1 mb-1 mt-1 max-h-60 overflow-y-auto w-full rounded-lg bg-level-3 py-1 text-[0.75rem] leading-[14px] focus:outline-none border shadow-dropdown2',
                element: 'w-full hover:bg-neutral-50 rounded cursor-default text-neutral-900 font-bold select-none py-1.5 px-2',
                fontcolor: 'white',
                available: 'cursor-pointer',
                unavailable: 'cursor-not-allowed opacity-50 hover:bg-transparent',
            },
            error: 'text-error-500 mt-1 relative text-[0.75rem]',
        },
    },
};

/**
 * Accounts-selectComponent
 *
 * Live demo:
 * <example-url>/demo/ds-accounts-select.component.html</example-url>
 */
class AccountsSelectComponent {
    constructor() {
        this.items = [];
        this.placeholder = 'Select an option';
        this.variant = 'default';
        this.disabled = false;
        this.hasError = false;
        this.emptyLabel = 'No options';
        this.multiple = false;
        this.isLoading = false;
        this.value = null;
        this.autoComplete = false;
        this.showCurrencyFlag = false;
        this.required = false;
        this.valueChange = new EventEmitter();
        this.isOpen = false;
        this.searchTerm = '';
        this.filteredItems = [];
        this.selectedValue = null;
        this.containerPosition = {};
        this.containerStyles = {};
        this.theme = theme$6;
    }
    ngOnChanges(changes) {
        if (changes['value']) {
            this.selectedValue =
                this.items.find((option) => option.value === this.value) || null;
        }
        if (changes['items']) {
            this.filteredItems = [].concat(this.items);
        }
    }
    get mergedStyles() {
        return Object.assign({}, this.containerPosition, this.containerStyles, this.customOptionsStyles || {});
    }
    toggleDropdown() {
        if (!this.disabled && !this.isLoading) {
            const myZ = ++AccountsSelectComponent.zIndexCounter;
            this.containerStyles = {
                zIndex: `${myZ}`,
            };
            this.isOpen = !this.isOpen;
            setTimeout(() => this.calculatePosition(), 0);
        }
    }
    shouldAppear() {
        return this.value !== null;
    }
    calculatePosition() {
        if (this.triggerButton &&
            this.triggerButton.nativeElement &&
            this.optionsContainer &&
            this.optionsContainer.nativeElement) {
            const rect = this.triggerButton &&
                this.triggerButton.nativeElement.getBoundingClientRect();
            const spaceBelow = window.innerHeight - rect.bottom;
            const spaceAbove = rect.top;
            this.containerPosition = {
                top: spaceBelow > spaceAbove ? '100%' : 'auto',
                bottom: spaceBelow > spaceAbove ? 'auto' : '100%',
                left: '0px',
                visibility: 'visible',
                position: 'absolute',
            };
        }
    }
    selectOption(item) {
        this.value = item.value;
        this.isOpen = false;
        this.selectedValue = item;
        this.valueChange.emit(this.value);
    }
    isSelected(item) {
        if (this.multiple && Array.isArray(this.value)) {
            return this.value.includes(item.value);
        }
        return this.value === item.value;
    }
    // // tighten returned type to always be a SelectItem
    get selected() {
        const found = this.items.find((i) => i.value === this.value);
        return (found || {
            icon: '',
            value: '',
            accountName: this.placeholder,
            accountNumber: '',
            soldeComptable: { value: 0, currency: '', currency_flag: '' },
            soldeTempsReel: { value: 0, currency: '', currency_flag: '' },
        });
    }
    onClickOutside(event) {
        const target = event.target;
        const clickedTrigger = this.triggerButton && this.triggerButton.nativeElement.contains(target);
        const clickedOptions = this.optionsContainer &&
            this.optionsContainer.nativeElement.contains(target);
        // if you clicked *neither* on the button nor inside the dropdown, close it
        if (!clickedTrigger && !clickedOptions) {
            this.isOpen = false;
        }
    }
    onEscClose(event) {
        this.isOpen = false;
    }
    onAutoCompleteInput(event) {
        this.isOpen = true;
        const target = event.target;
        this.searchTerm = target.value;
        console.log(this.searchTerm);
        this.filteredItems = this.items.filter((item) => item.accountName.toLowerCase().includes(this.searchTerm.toLowerCase()));
        console.log(this.filteredItems);
    }
    clearSearch() {
        this.searchTerm = '';
        this.filteredItems = [].concat(this.items);
        this.selectedValue = null;
        this.value = null;
        this.valueChange.emit(null);
        this.isOpen = true;
        setTimeout(() => this.autoCompleteInput.nativeElement.focus(), 0);
    }
}
AccountsSelectComponent.zIndexCounter = 10000;
AccountsSelectComponent.decorators = [
    { type: Component, args: [{
                selector: 'ds-accounts-select',
                template: "<div id=\"ds-accounts-select\" class=\"relative w-full\" [ngClass]=\"className\">\n  <ng-container *ngIf=\"label\">\n    <label [class]=\"theme[variant].element.label\">{{ label }}</label>\n    <span *ngIf=\"required\" class=\"text-red-500\">*</span>\n  </ng-container>\n\n  <button\n    #triggerButton\n    type=\"button\"\n    (click)=\"toggleDropdown()\"\n    [disabled]=\"disabled || isLoading\"\n    [ngClass]=\"[\n      theme[variant].element.button.select,\n      hasError ? theme[variant].element.button.error : '',\n      disabled ? theme[variant].element.button.disabled : ''\n    ]\"\n  >\n    <ng-container *ngIf=\"selectedValue === null && !autoComplete\">\n      <span class=\"text-neutral-900 text-[0.75rem] leading-[18px]\">\n        {{ placeholder }}\n      </span>\n    </ng-container>\n    <ng-container *ngIf=\"autoComplete && selectedValue === null\">\n      <div class=\"relative mr-2\">\n        <ds-icon id=\"search1\" size=\"16\" class=\"text-neutral-900\"></ds-icon>\n      </div>\n      <input\n        #autoCompleteInput\n        type=\"text\"\n        class=\"w-full outline-none\"\n        [placeholder]=\"placeholder\"\n        class=\"w-full outline-none text-neutral-900 placeholder:text-neutral-900 text-[0.75rem]\"\n        (input)=\"onAutoCompleteInput($event)\"\n        [(ngModel)]=\"searchTerm\"\n      />\n    </ng-container>\n    <ng-container *ngIf=\"selectedValue !== null\">\n      <div class=\"relative w-full flex justify-between items-center mr-2\">\n        <div class=\"w-full flex justify-between items-center gap-3\">\n          <div\n            *ngIf=\"selectedValue.icon\"\n            class=\"size-10 shrink-0 flex items-center justify-center border border-stroke-1 bg-white rounded-full\"\n          >\n            <ds-icon\n              [id]=\"selectedValue.icon\"\n              size=\"20\"\n              class=\"text-red-500\"\n            ></ds-icon>\n          </div>\n          <div class=\"w-full flex items-center justify-between gap-5\">\n            <div class=\"flex-1 flex flex-col\">\n              <span\n                class=\"inline-flex font-normal text-neutral-500 text-[0.75rem] leading-[18px]\"\n              >\n                {{ selectedValue.accountName }}\n              </span>\n              <span class=\"inline-flex font-bold text-[0.75rem] leading-[18px]\">\n                {{ selectedValue.accountNumber }}\n              </span>\n            </div>\n            <div class=\"flex-1 flex flex-col gap-y-2\">\n              <ng-container *ngIf=\"selectedValue.soldeComptable\">\n                <div class=\"flex-1 flex gap-x-2\">\n                  <span\n                    class=\"block text-end whitespace-nowrap font-normal text-neutral-500 text-[0.75rem] leading-[18px] ml-auto\"\n                  >\n                    Solde r\u00E9el\n                  </span>\n                  <div class=\"flex items-center justify-end gap-1.5 shrink-0\">\n                    <ds-balance-formatter\n                      *ngIf=\"selectedValue.soldeComptable.value\"\n                      [balance]=\"selectedValue.soldeComptable.value\"\n                      className=\"!text-[0.75rem] !leading-[18px]\"\n                    ></ds-balance-formatter>\n                    <div class=\"flex items-center gap-1.5 shrink-0\">\n                      <span\n                        class=\"block text-end whitespace-nowrap font-normal text-neutral-500 text-[0.75rem] leading-[18px] ml-auto\"\n                      >\n                        {{ selectedValue.soldeTempsReel.currency }}\n                      </span>\n                      <div\n                        *ngIf=\"showCurrencyFlag\"\n                        class=\"relative rounded-full size-4\"\n                      >\n                        <img\n                          [src]=\"selectedValue.soldeComptable.currency_flag\"\n                          alt=\"[selectedValue.title]\"\n                          class=\"relative rounded-full size-4\"\n                        />\n                      </div>\n                    </div>\n                  </div>\n                </div>\n              </ng-container>\n\n              <ng-container *ngIf=\"selectedValue.soldeTempsReel\">\n                <div class=\"flex-1 flex gap-x-2\">\n                  <span\n                    class=\"block text-end whitespace-nowrap font-normal text-neutral-500 text-[0.75rem] leading-[18px] ml-auto\"\n                  >\n                    Solde comptable\n                  </span>\n                  <div class=\"flex items-center justify-end gap-1.5 shrink-0\">\n                    <ds-balance-formatter\n                      *ngIf=\"selectedValue.soldeTempsReel.value\"\n                      [balance]=\"selectedValue.soldeTempsReel.value\"\n                      className=\"!text-[0.75rem] !leading-[18px]\"\n                    ></ds-balance-formatter>\n                    <div class=\"flex items-center gap-1.5 shrink-0\">\n                      <span\n                        class=\"block text-end whitespace-nowrap font-normal text-neutral-500 text-[0.75rem] leading-[18px] ml-auto\"\n                      >\n                        {{ selectedValue.soldeTempsReel.currency }}\n                      </span>\n                      <div\n                        *ngIf=\"showCurrencyFlag\"\n                        class=\"relative rounded-full size-4\"\n                      >\n                        <img\n                          [src]=\"selectedValue.soldeTempsReel.currency_flag\"\n                          alt=\"[selectedValue.title]\"\n                          class=\"relative rounded-full size-4\"\n                        />\n                      </div>\n                    </div>\n                  </div>\n                </div>\n              </ng-container>\n            </div>\n          </div>\n        </div>\n      </div>\n    </ng-container>\n    <ds-icon\n      *ngIf=\"!isLoading && selectedValue === null && searchTerm === ''\"\n      [id]=\"isOpen ? 'arrow-up' : 'arrow-down'\"\n      [class]=\"theme[variant].element.icone.arrow\"\n    ></ds-icon>\n    <ds-icon\n      *ngIf=\"!isLoading && (selectedValue !== null || searchTerm !== '')\"\n      id=\"close\"\n      [class]=\"theme[variant].element.icone.arrow\"\n      (click)=\"clearSearch()\"\n    ></ds-icon>\n    <ds-icon\n      *ngIf=\"isLoading\"\n      id=\"Loader\"\n      [class]=\"theme[variant].element.icone.arrow + ' animate-spin'\"\n    ></ds-icon>\n  </button>\n\n  <div\n    *ngIf=\"isOpen\"\n    #optionsContainer\n    [ngStyle]=\"mergedStyles\"\n    [ngClass]=\"theme[variant].element.options.container\"\n  >\n    <ng-container *ngIf=\"filteredItems.length > 0; else emptyState\">\n      <div\n        *ngFor=\"let item of filteredItems\"\n        (click)=\"item.unavailable ? null : selectOption(item)\"\n        class=\"relative after:absolute after:-left-1 after:w-0.5 after:h-1/2 after:top-1/2 after:-translate-y-1/2 after:rounded-r border-b border-stroke-1 last-of-type:border-b-0\"\n        [ngClass]=\"[\n          theme[variant].element.options.element,\n          item.unavailable\n            ? theme[variant].element.options.unavailable\n            : theme[variant].element.options.available,\n          isSelected(item) ? 'bg-gray-50' : 'bg-transparent',\n          isSelected(item) ? 'after:bg-gray-500' : 'after:bg-transparent'\n        ]\"\n        [class.cursor-not-allowed]=\"item.unavailable\"\n      >\n        <div class=\"relative w-full flex justify-between items-center\">\n          <div class=\"w-full flex justify-between items-center gap-3\">\n            <div\n              *ngIf=\"item.icon\"\n              class=\"size-10 shrink-0 flex items-center justify-center border border-stroke-1 bg-white rounded-full\"\n            >\n              <ds-icon\n                [id]=\"item.icon\"\n                size=\"20\"\n                class=\"text-red-500\"\n              ></ds-icon>\n            </div>\n            <div class=\"w-full flex items-center justify-between gap-5\">\n              <div class=\"flex-1 flex flex-col\">\n                <span\n                  class=\"inline-flex font-normal text-neutral-500 text-[0.75rem] leading-[18px]\"\n                >\n                  {{ item.accountName }}\n                </span>\n                <span\n                  class=\"inline-flex font-bold text-[0.75rem] leading-[18px]\"\n                >\n                  {{ item.accountNumber }}\n                </span>\n              </div>\n              <div class=\"flex-1 flex flex-col gap-y-2\">\n                <ng-container *ngIf=\"item.soldeComptable\">\n                  <div class=\"flex-1 flex gap-x-2\">\n                    <span\n                      class=\"block text-end whitespace-nowrap font-normal text-neutral-500 text-[0.75rem] leading-[18px] ml-auto\"\n                    >\n                      Solde r\u00E9el\n                    </span>\n                    <div class=\"flex items-center justify-end gap-1.5 shrink-0\">\n                      <ds-balance-formatter\n                        *ngIf=\"item.soldeComptable.value\"\n                        [balance]=\"item.soldeComptable.value\"\n                        className=\"!text-[0.75rem] !leading-[18px]\"\n                      ></ds-balance-formatter>\n                      <div class=\"flex items-center gap-1.5 shrink-0\">\n                        <span\n                          class=\"block text-end whitespace-nowrap font-normal text-neutral-500 text-[0.75rem] leading-[18px] ml-auto\"\n                        >\n                          {{ item.soldeTempsReel.currency }}\n                        </span>\n                        <div\n                          *ngIf=\"showCurrencyFlag\"\n                          class=\"relative rounded-full size-4\"\n                        >\n                          <img\n                            [src]=\"item.soldeComptable.currency_flag\"\n                            alt=\"[item.title]\"\n                            class=\"relative rounded-full size-4\"\n                          />\n                        </div>\n                      </div>\n                    </div>\n                  </div>\n                </ng-container>\n                <ng-container *ngIf=\"item.soldeTempsReel\">\n                  <div class=\"flex-1 flex gap-x-2\">\n                    <span\n                      class=\"block text-end whitespace-nowrap font-normal text-neutral-500 text-[0.75rem] leading-[18px] ml-auto\"\n                    >\n                      Solde comptable\n                    </span>\n                    <div class=\"flex items-center justify-end gap-1.5 shrink-0\">\n                      <ds-balance-formatter\n                        *ngIf=\"item.soldeTempsReel.value\"\n                        [balance]=\"item.soldeTempsReel.value\"\n                        className=\"!text-[0.75rem] !leading-[18px]\"\n                      ></ds-balance-formatter>\n                      <div class=\"flex items-center gap-1.5 shrink-0\">\n                        <span\n                          class=\"block text-end whitespace-nowrap font-normal text-neutral-500 text-[0.75rem] leading-[18px] ml-auto\"\n                        >\n                          {{ item.soldeTempsReel.currency }}\n                        </span>\n                        <div\n                          *ngIf=\"showCurrencyFlag\"\n                          class=\"relative rounded-full size-4\"\n                        >\n                          <img\n                            [src]=\"item.soldeTempsReel.currency_flag\"\n                            alt=\"[item.title]\"\n                            class=\"relative rounded-full size-4\"\n                          />\n                        </div>\n                      </div>\n                    </div>\n                  </div>\n                </ng-container>\n              </div>\n            </div>\n          </div>\n        </div>\n      </div>\n    </ng-container>\n\n    <ng-template #emptyState>\n      <div class=\"p-2 px-4 text-gray-600\">{{ emptyLabel }}</div>\n    </ng-template>\n  </div>\n\n  <ng-container *ngIf=\"hasError && errorMessage\">\n    <span [ngClass]=\"theme[variant].element.error\">{{ errorMessage }}</span>\n  </ng-container>\n</div>\n"
            }] }
];
AccountsSelectComponent.propDecorators = {
    items: [{ type: Input }],
    label: [{ type: Input }],
    errorMessage: [{ type: Input }],
    placeholder: [{ type: Input }],
    variant: [{ type: Input }],
    disabled: [{ type: Input }],
    hasError: [{ type: Input }],
    emptyLabel: [{ type: Input }],
    multiple: [{ type: Input }],
    isLoading: [{ type: Input }],
    className: [{ type: Input }],
    buttonIcon: [{ type: Input }],
    value: [{ type: Input }],
    customOptionsStyles: [{ type: Input }],
    autoComplete: [{ type: Input }],
    showCurrencyFlag: [{ type: Input }],
    required: [{ type: Input }],
    valueChange: [{ type: Output }],
    autoCompleteInput: [{ type: ViewChild, args: ['autoCompleteInput',] }],
    triggerButton: [{ type: ViewChild, args: ['triggerButton',] }],
    optionsContainer: [{ type: ViewChild, args: ['optionsContainer',] }],
    onClickOutside: [{ type: HostListener, args: ['document:click', ['$event'],] }],
    onEscClose: [{ type: HostListener, args: ['document:keydown.escape', ['$event'],] }]
};

// TYPES
// UTILS
const formatMoney = (value, withCurrency, noDecimals = false, isDiscrete) => {
    if (isDiscrete) {
        return '****';
    }
    var config;
    if (withCurrency) {
        config = {
            style: 'currency',
            maximumFractionDigits: 4,
            minimumFractionDigits: 2,
            currency: 'MAD',
        };
    }
    else {
        config = {
            maximumFractionDigits: 4,
            minimumFractionDigits: 2,
        };
    }
    if (noDecimals) {
        delete config.minimumFractionDigits;
        delete config.maximumFractionDigits;
    }
    return new Intl.NumberFormat('fr', config).format(value);
};
const getFirstTwoLetters = (title) => {
    const titleWords = title.split(' ');
    if (titleWords.length === 1) {
        return `${titleWords[0][0]}`.toUpperCase();
    }
    return `${titleWords[0][0]}${titleWords[1][0]}`.toUpperCase();
};

/**
 * Payment-details-cardComponent
 *
 * Live demo:
 * <example-url>/demo/ds-payment-details-card.component.html</example-url>
 */
class PaymentDetailsCardComponent {
    constructor() {
        this.title = '';
        this.titleHeader = '';
        this.date = '';
        this.price = 0;
        this.currency = '';
        this.isSelected = false;
        this.useCheckbox = false;
        this.className = '';
        this.disabled = false;
        this.statusContext = 'green';
        this.onSelect = new EventEmitter();
    }
    get formattedPrice() {
        return formatMoney(this.price, false, false, false);
    }
    onSelectChange(event) {
        this.onSelect.emit({ event: event, data: this.data });
    }
}
PaymentDetailsCardComponent.decorators = [
    { type: Component, args: [{
                selector: 'ds-payment-details-card',
                template: "<div id=\"ds-payment-details-card\" [ngClass]=\"className\" class=\"border border-neutral-50 rounded flex flex-col\">\n  <div class=\"grid grid-cols-5 bg-neutral-25 rounded-t\">\n    <div class=\"col-span-3 flex items-center justify-strat gap-3 py-2 px-4\">\n      <ds-checkbox *ngIf=\"useCheckbox\" [checked]=\"isSelected\" [disabled]=\"disabled\"\n        (change)=\"onSelectChange($event)\"></ds-checkbox>\n      <h3 *ngIf=\"title\" class=\"text-[0.875rem]/[1rem]\">\n        {{ title }}\n      </h3>\n      <ng-container *ngIf=\"status\">\n        <ng-container [ngTemplateOutlet]=\"status\"\n          [ngTemplateOutletContext]=\"{ $implicit: statusContext }\"></ng-container>\n      </ng-container>\n    </div>\n    <div class=\"flex items-center justify-between py-2 px-4\">\n      <span *ngIf=\"date\" class=\"inline-flex text-[0.875rem]/[1rem]\">Date</span>\n    </div>\n    <div class=\"flex items-center justify-between py-2 px-4\">\n      <span *ngIf=\"price\" class=\"inline-flex text-[0.875rem]/[1rem]\">Montant TTC</span>\n    </div>\n  </div>\n  <div class=\"grid grid-cols-5 rounded-b bg-level-3\">\n    <div class=\"col-span-3 text-[0.875rem]/[1.25rem] py-2.5 px-3 justify-start text-neutral-500 items-center\">\n      <ng-content></ng-content>\n    </div>\n    <div class=\"inline-flex text-[0.875rem]/[1rem] font-bold py-2.5 px-3 justify-start items-center\">\n      <span *ngIf=\"date\">\n        {{ date }}\n      </span>\n    </div>\n    <div class=\"inline-flex text-[0.875rem]/[1rem] font-bold py-2.5 px-3 justify-start items-center\">\n      <span *ngIf=\"price\">\n        {{ price | number : \"1.2-2\" : \"fr-FR\" }} {{ currency }}\n      </span>\n    </div>\n  </div>\n</div>"
            }] }
];
PaymentDetailsCardComponent.propDecorators = {
    title: [{ type: Input }],
    titleHeader: [{ type: Input }],
    date: [{ type: Input }],
    price: [{ type: Input }],
    currency: [{ type: Input }],
    isSelected: [{ type: Input }],
    useCheckbox: [{ type: Input }],
    className: [{ type: Input }],
    disabled: [{ type: Input }],
    status: [{ type: Input }],
    statusContext: [{ type: Input }],
    data: [{ type: Input }],
    onSelect: [{ type: Output }]
};

const defaultTheme$1 = {
    base: 'relative w-fit box-border flex items-center justify-center active:outline-none transition ease-in-out duration-300 gap-3 text-center rounded',
    contentWrapper: 'flex items-center justify-center gap-3',
    disabled: {
        primary: 'cursor-not-allowed !bg-red-200 border !border-red-200 hover:bg-red-200 hover:border-red-200 !text-white',
        secondary: 'cursor-not-allowed !bg-neutral-50 border !border-neutral-50 hover:bg-neutral-50 hover:border-neutral-50 !text-neutral-300',
        // gray: 'cursor-not-allowed !bg-neutral-50 border !border-neutral-50 hover:bg-neutral-50 hover:border-neutral-50 !text-neutral-300',
        outline: 'cursor-not-allowed border !border-neutral-50 hover:border-neutral-50 !text-neutral-300',
        text: 'cursor-not-allowed !text-neutral-300 hover:bg-transparent',
        link: 'cursor-not-allowed !text-neutral-300 hover:bg-transparent',
    },
    size: {
        small: {
            text: 'py-2 px-3 text-[0.75rem]/[1rem]',
            icon: 'p-2.5',
        },
        normal: {
            text: 'py-2.5 px-3.5 text-[0.875rem]/[1rem]',
            icon: 'p-2.5',
        },
        medium: {
            text: 'py-3 px-4 text-[1rem]/[1.375rem]',
            icon: 'p-4',
        },
        large: {
            text: 'py-3.5 px-[18px] text-[1.125rem]/[1.5rem]',
            icon: 'p-6',
        },
    },
    variants: {
        primary: 'font-[700] border-2 border-red-500 bg-red-500 text-white hover:bg-red-600 hover:border-red-600',
        secondary: 'font-[700] border-2 border-neutral-50 bg-neutral-50 text-neutral-700 hover:bg-neutral-50 hover:!border-neutral-100/10',
        // gray: 'font-[700] border-2 border-neutral-100 bg-neutral-100 text-neutral-700 hover:bg-neutral-50 hover:!border-neutral-100/10',
        outline: 'font-[700] border-2 border-neutral-100 bg-transparent text-neutral-700 hover:bg-neutral-50 hover:!border-neutral-100/10',
        text: 'font-[700] bg-transparent text-red-500 hover:bg-neutral-25 hover:!border-neutral-100/10',
        link: 'font-[700] bg-transparent text-neutral-700 hover:bg-neutral-25 hover:!border-neutral-100/10',
    },
};

/**
 * ButtonComponent
 *
 * Live demo:
 * <example-url>/demo/ds-button.component.html</example-url>
 */
class ButtonComponent {
    constructor() {
        this.type = 'button';
        this.className = '';
        this.variant = 'primary';
        this.size = 'normal';
        this.disabled = false;
        this.outline = false;
        this.pill = false;
        this.target = null;
        this.isLoading = false;
        this.style = '';
        this.onClick = new EventEmitter();
        this.defaultTheme = defaultTheme$1;
    }
    // Use the provided theme or fall back to the default one
    get appliedTheme() {
        return this.theme || this.defaultTheme;
    }
    // Compute the CSS class string using logic similar to vclsx in React
    get computedClass() {
        const theme = this.appliedTheme;
        const classes = [];
        classes.push(theme.base);
        if (this.icon) {
            classes.push(theme.size[this.size].icon);
        }
        else {
            classes.push(theme.size[this.size].text);
        }
        if (this.outline) {
            classes.push(theme.outlineVariants[this.variant]);
        }
        else {
            classes.push(theme.variants[this.variant]);
        }
        if (this.disabled) {
            classes.push(theme.disabled[this.variant]);
        }
        if (this.className) {
            classes.push(this.className);
        }
        return classes.join(' ');
    }
    ngOnInit() {
        // This replicates the React behavior where a link cannot be disabled.
        if (this.href && this.disabled) {
            throw new Error('A link cannot be disabled.');
        }
    }
}
ButtonComponent.decorators = [
    { type: Component, args: [{
                selector: 'ds-button',
                template: "<!-- If href is provided, render an anchor element -->\n<ng-container *ngIf=\"href; else buttonTemplate\">\n  <a id=\"ds-button\" [href]=\"href\" [style]=\"style\">\n    <ng-content></ng-content>\n  </a>\n</ng-container>\n\n<!-- Button element if no href is provided -->\n<ng-template #buttonTemplate>\n  <button\n    id=\"ds-button\"\n    [type]=\"type\"\n    [disabled]=\"disabled\"\n    [ngClass]=\"computedClass\"\n    (click)=\"onClick.emit($event)\"\n    [style]=\"style\"\n  >\n    <ds-icon\n      *ngIf=\"isLoading\"\n      id=\"Loader\"\n      size=\"16px\"\n      class=\"animate-spin\"\n    ></ds-icon>\n    <span [ngClass]=\"appliedTheme.contentWrapper\">\n      <ng-container *ngIf=\"icon; else projectedContentButton\">\n        <ds-icon [id]=\"icon\" size=\"16px\"></ds-icon>\n      </ng-container>\n      <ng-template #projectedContentButton>\n        <ng-container *ngIf=\"iconLeft\">\n          <ds-icon [id]=\"iconLeft\" size=\"16px\"></ds-icon>\n        </ng-container>\n        <!-- Content projection for button text -->\n        <ng-content></ng-content>\n        <ng-container *ngIf=\"iconRight\">\n          <ds-icon [id]=\"iconRight\" size=\"16px\"></ds-icon>\n        </ng-container>\n      </ng-template>\n    </span>\n  </button>\n</ng-template>\n"
            }] }
];
ButtonComponent.propDecorators = {
    icon: [{ type: Input }],
    iconRight: [{ type: Input }],
    iconLeft: [{ type: Input }],
    type: [{ type: Input }],
    className: [{ type: Input }],
    variant: [{ type: Input }],
    size: [{ type: Input }],
    disabled: [{ type: Input }],
    outline: [{ type: Input }],
    pill: [{ type: Input }],
    href: [{ type: Input }],
    target: [{ type: Input }],
    isLoading: [{ type: Input }],
    theme: [{ type: Input }],
    style: [{ type: Input }],
    onClick: [{ type: Output }]
};

const badge = {
    base: 'inline-flex text-nowrap items-center gap-[7px] font-medium rounded-[2px] w-fit',
    sizes: {
        sm: 'px-4 py-1',
        md: 'px-5 py-1.5',
        lg: 'px-6 py-1.5',
    },
    //bg-amber-500
    //bg-violet-500
    //bg-neutral-500
    variants: {
        default: 'bg-neutral-50 dark:bg-neutral-50 text-neutral-500',
        amber: 'bg-amber-50 text-amber-500',
        blue: 'bg-blue-50 text-blue-500',
        green: 'bg-[#E6F4EF] dark:bg-[#245140] text-success-500',
        red: 'bg-red-50 dark:bg-[#460809] text-red-500',
        orange: 'bg-amber-500 text-black',
        crame: 'bg-crame-50 text-crame-500',
        neutral: 'bg-neutral-300 text-white',
    },
    icon: 'w-4 h-4',
};
const textVariants = {
    sm: 'text-[0.75rem]/[0.875rem] font-medium',
    md: 'text-[0.875rem]/[1rem] font-medium',
    lg: 'text-[1rem]/[1.125rem] font-medium',
};

/**
 * BadgeComponent
 *
 * Live demo:
 * <example-url>/demo/ds-badge.component.html</example-url>
 */
class BadgeComponent {
    constructor() {
        this.pill = true;
        this.variant = 'default';
        this.size = 'md';
        this.withDot = false;
        this.iconRight = false;
        this.className = '';
        this.onClick = new EventEmitter();
        //Theme
        this.badge = badge;
        this.textVariants = textVariants;
    }
    getBadgeClasses() {
        const base = this.badge.base;
        const size = this.badge.sizes[this.size] || '';
        const variant = this.badge.variants[this.variant] || '';
        const pill = this.pill ? 'rounded-full' : '';
        return [base, size, variant, pill, this.className].join(' ').trim();
    }
    getTextClasses() {
        return this.textVariants[this.size] || '';
    }
    handleClick(event) {
        this.onClick.emit(event);
    }
}
BadgeComponent.decorators = [
    { type: Component, args: [{
                selector: 'ds-badge',
                template: "<a id=\"ds-badge\" *ngIf=\"href\" [href]=\"href\" [ngClass]=\"getBadgeClasses()\">\n  <ds-icon *ngIf=\"icon\" [id]=\"icon\" [ngClass]=\"badge.icon\"></ds-icon>\n  <span [ngClass]=\"getTextClasses()\">{{ label }}</span>\n</a>\n\n<span\n  id=\"ds-badge\"\n  *ngIf=\"!href\"\n  [ngClass]=\"getBadgeClasses()\"\n  (click)=\"handleClick($event)\"\n>\n  <ds-icon\n    *ngIf=\"!iconRight && icon\"\n    [id]=\"icon\"\n    [ngClass]=\"badge.icon\"\n  ></ds-icon>\n  <span\n    class=\"size-1.5 rounded-full inline-flex\"\n    [ngClass]=\"[\n      'bg-' + (variant === 'default' ? 'neutral' : variant) + '-500',\n      variant === 'stroke1' ? 'bg-neutral-700' : '',\n      variant === 'green' ? 'bg-success-500' : '',\n      variant === 'orange' ? 'bg-black' : '',\n      variant === 'default' ? 'bg-neutral-500' : '',\n      variant === 'neutral' ? 'bg-white' : '',\n      variant === 'crame' ? 'bg-crame-500' : ''\n    ]\"\n    *ngIf=\"withDot\"\n  ></span>\n  <span [ngClass]=\"getTextClasses()\">{{ label }}</span>\n  <ds-icon\n    *ngIf=\"iconRight && icon\"\n    [id]=\"icon\"\n    [ngClass]=\"badge.icon\"\n  ></ds-icon>\n</span>\n"
            }] }
];
BadgeComponent.propDecorators = {
    icon: [{ type: Input }],
    label: [{ type: Input }],
    href: [{ type: Input }],
    pill: [{ type: Input }],
    variant: [{ type: Input }],
    size: [{ type: Input }],
    withDot: [{ type: Input }],
    iconRight: [{ type: Input }],
    className: [{ type: Input }],
    onClick: [{ type: Output }]
};

/**
 * IconComponent
 *
 * Live demo:
 * <example-url>/demo/ds-icon.component.html</example-url>
 */
class IconComponent {
    constructor() {
        this.size = '1rem';
        this.class = '';
        this.style = '';
    }
}
IconComponent.decorators = [
    { type: Component, args: [{
                selector: 'ds-icon',
                template: `
    <svg
      id="ds-icon"
      [attr.width]="size"
      [attr.height]="size"
      [ngClass]="class"
      [style]="style"
      xmlns="http://www.w3.org/2000/svg"
    >
      <use [attr.href]="'/assets/icons.svg#' + id" class="fill-current"></use>
    </svg>
  `
            }] }
];
IconComponent.propDecorators = {
    id: [{ type: Input }],
    size: [{ type: Input }],
    class: [{ type: Input }],
    style: [{ type: Input }]
};

const theme$7 = {
    default: {
        container: 'mx-auto w-full space-y-[10px]',
        disclosure: '',
        button: {
            base: 'w-full space-y-2 bg-level-3 rounded-b-lg py-4 px-6 text-left focus:outline-none outline-none border-none shadow-accordion overflow-hidden',
            title: 'text-[0.875rem]/[1.5rem] font-bold text-neutral-900',
            active: '',
            titleWrapper: 'flex items-center justify-end flex-row-reverse gap-[11px]',
            icon: {
                base: 'transition ease-in duration-300',
                classActive: '',
                classInactive: '',
                inactiveId: 'arrow-down',
                activeId: 'arrow-up',
                size: '16px',
            },
        },
        panel: {
            base: 'p-5 overflow-hidden rounded-b-lg border-t border-stroke-1 bg-level-3',
        },
    },
    borderless: {
        container: 'mx-auto w-full space-y-[17px] rounded-2xl',
        disclosure: 'space-y-1 rounded-lg',
        button: {
            base: 'w-full hover:text-red-500 text-neutral-700 space-y-2 pb-3 text-left text-sm font-medium focus:outline-none',
            active: '',
            title: 'text-[0.875rem]/[1.125rem] font-bold',
            titleWrapper: 'w-full flex items-center justify-between justify-between',
            icon: {
                base: 'transition ease-in duration-300',
                classActive: '',
                classInactive: '',
                inactiveId: 'arrow-down',
                activeId: 'arrow-up',
                size: '16px',
            },
        },
        panel: { base: '' },
    },
    'borderless-reversed': {
        container: 'mx-auto w-full space-y-[17px] rounded-2xl',
        disclosure: 'space-y-1 rounded-lg',
        button: {
            base: 'w-full hover:text-red-500 text-neutral-700 space-y-2 pb-3 text-left text-sm font-medium focus:outline-none',
            active: '',
            title: 'text-[0.875rem]/[1.125rem] font-bold',
            titleWrapper: 'w-full flex flex-row-reverse items-center gap-2 justify-end',
            icon: {
                base: 'transition ease-in duration-300',
                classActive: '',
                classInactive: '',
                inactiveId: 'arrow-down',
                activeId: 'arrow-up',
                size: '16px',
            },
        },
        panel: { base: 'border-t border-stroke-1' },
    },
    shadowless: {
        container: 'mx-auto w-full space-y-[10px]',
        disclosure: '',
        button: {
            base: 'w-full space-y-2 bg-level-3 rounded py-4 px-4 text-left focus:outline-none outline-none border-none rounded overflow-hidden',
            title: 'text-[0.875rem]/[1.5rem] font-bold text-neutral-900',
            active: 'rounded-b-none',
            titleWrapper: 'flex items-center justify-end flex-row-reverse gap-[11px]',
            icon: {
                base: 'transition ease-in duration-300',
                classActive: '',
                classInactive: '',
                inactiveId: 'arrow-down',
                activeId: 'arrow-up',
                size: '16px',
            },
        },
        panel: {
            base: 'p-5 overflow-hidden rounded-b-lg border-t border-stroke-1 bg-level-3',
        },
    },
};

/**
 * AccordionComponent
 *
 * Live demo:
 * <example-url>/demo/ds-accordion.component.html</example-url>
 */
class AccordionComponent {
    constructor() {
        this.variant = 'default';
        this.items = [];
        this.allowMultiple = false;
        this.textClassName = '';
        this.className = '';
        this.openHandler = new EventEmitter();
        this.localItems = [];
        /** copy of your theme object from React, trimmed to only the bits we use */
        this.theme = theme$7;
    }
    ngOnInit() {
        this.buildLocalItems();
    }
    ngOnChanges(changes) {
        if (changes.items) {
            this.buildLocalItems();
        }
    }
    buildLocalItems() {
        this.localItems = this.items.map((it) => (Object.assign({}, it, { isOpen: it.open ? (this.allowMultiple ? true : it.open) : false })));
    }
    handleChange(item) {
        if (this.allowMultiple) {
            item.isOpen = !item.isOpen;
        }
        else {
            this.localItems.forEach((it) => it.id === item.id ? (it.isOpen = !it.isOpen) : (it.isOpen = false));
        }
        this.openHandler.emit(item);
    }
    getContainerClasses() {
        return [this.theme[this.variant].container, this.className];
    }
    getDisclosureClasses(isOpen) {
        return [
            this.theme[this.variant].disclosure,
            isOpen
                ? `${this.variant === 'default' ? 'bg-level-4 rounded-b-lg' : ''}`
                : '',
        ];
    }
    getButtonClasses(isOpen) {
        const btn = this.theme[this.variant].button;
        return [btn.base, isOpen ? btn.active : ''];
    }
    getIconId(isOpen) {
        const icon = this.theme[this.variant].button.icon;
        return isOpen ? icon.activeId : icon.inactiveId;
    }
    getIconClasses(isOpen) {
        const icon = this.theme[this.variant].button.icon;
        return [icon.base, isOpen ? icon.classActive : icon.classInactive];
    }
    getPanelClasses() {
        return this.theme[this.variant].panel.base;
    }
    isTemplate(ref) {
        return ref instanceof TemplateRef;
    }
}
AccordionComponent.decorators = [
    { type: Component, args: [{
                selector: 'ds-accordion',
                template: "<div id=\"ds-accordion\" [ngClass]=\"getContainerClasses()\">\n  <div\n    *ngFor=\"let item of localItems\"\n    [attr.data-open]=\"item.isOpen.toString()\"\n    [ngClass]=\"getDisclosureClasses(item.isOpen)\"\n  >\n    <!-- header -->\n    <button\n      type=\"button\"\n      (click)=\"handleChange(item)\"\n      [ngClass]=\"getButtonClasses(item.isOpen)\"\n    >\n      <div class=\"flex items-center justify-between gap-2\">\n        <div [class]=\"theme[variant].button.titleWrapper\">\n          <div\n            *ngIf=\"item.count\"\n            [ngClass]=\"['flex items-center flex-row-reverse gap-2']\"\n          >\n            <!-- count -->\n            <span\n              [ngClass]=\"[\n                'rounded-full font-bold text-white text-[0.75rem]/[1rem] inline-flex justify-center items-center size-[20px]',\n                item.countColor || 'bg-red-500'\n              ]\"\n            >\n              {{ item.count }}\n            </span>\n            <!-- title -->\n            <span\n              [ngClass]=\"[\n                textClassName,\n                theme[this.variant].button.title || ''\n              ]\"\n              >{{ item.title }}</span\n            >\n          </div>\n          <!-- title -->\n          <span\n            *ngIf=\"!item.count\"\n            [ngClass]=\"[textClassName, theme[this.variant].button.title || '']\"\n            >{{ item.title }}</span\n          >\n          <!-- icon -->\n          <ds-icon\n            [id]=\"getIconId(item.isOpen)\"\n            [size]=\"theme[variant].button.icon.size\"\n            [class]=\"getIconClasses(item.isOpen)\"\n          ></ds-icon>\n        </div>\n        <ng-container *ngIf=\"item.buttonTemplate\">\n          <ng-container\n            *ngTemplateOutlet=\"item.buttonTemplate; context: item\"\n          ></ng-container>\n        </ng-container>\n      </div>\n    </button>\n\n    <!-- panel -->\n    <div *ngIf=\"item.isOpen\" [ngClass]=\"getPanelClasses()\">\n      <ng-container *ngIf=\"isTemplate(item.content); else showHtml\">\n        <ng-container\n          *ngTemplateOutlet=\"item.content; context: item.context\"\n        ></ng-container>\n      </ng-container>\n      <ng-template #showHtml>\n        <div [innerHTML]=\"item.content\"></div>\n      </ng-template>\n    </div>\n  </div>\n</div>\n"
            }] }
];
AccordionComponent.propDecorators = {
    variant: [{ type: Input }],
    items: [{ type: Input }],
    allowMultiple: [{ type: Input }],
    textClassName: [{ type: Input }],
    className: [{ type: Input }],
    openHandler: [{ type: Output }]
};

const avatar = {
    default: {
        base: 'inline-block rounded-full object-cover',
    },
    placeholder: {
        base: 'inline-block rounded-full overflow-hidden bg-gray-100',
        svg: 'h-full w-full text-gray-300',
    },
    initials: {
        base: 'inline-flex items-center justify-center rounded-full bg-gray-500',
        text: 'text-xs font-medium leading-none text-white',
        textSizes: {
            small: 'text-xs font-medium',
            normal: 'text-sm font-medium',
            large: 'font-medium',
            xlarge: 'text-lg font-medium',
            xxlarge: 'text-xl font-medium',
        },
    },
    size: {
        small: 'h-6 w-6',
        normal: 'h-8 w-8',
        large: 'h-10 w-10',
        xlarge: 'h-12 w-12',
        xxlarge: 'h-14 w-14',
    },
};

/**
 * AvatarComponent
 *
 * Live demo:
 * <example-url>/demo/ds-avatar.component.html</example-url>
 */
class AvatarComponent {
    constructor() {
        this.variant = 'default';
        this.size = 'normal';
        this.alt = '';
        this.src = 'https://images.unsplash.com/photo-1472099645785-5658abf4ff4e?...'; // same default
        this.className = '';
        this.avatar = avatar;
    }
    get classes() {
        return [
            this.avatar[this.variant].base,
            this.avatar.size[this.size],
            this.className,
        ]
            .filter(Boolean)
            .join(' ');
    }
    get textSize() {
        return this.avatar.initials.textSizes[this.size];
    }
}
AvatarComponent.decorators = [
    { type: Component, args: [{
                selector: 'ds-avatar',
                template: "<ng-container [ngSwitch]=\"variant\">\n  <div id=\"ds-avatar\" *ngSwitchCase=\"'placeholder'\" [ngClass]=\"classes\">\n    <svg\n      [ngClass]=\"avatar.placeholder.svg\"\n      fill=\"currentColor\"\n      viewBox=\"0 0 24 24\"\n    >\n      <path\n        d=\"M24 20.993V24H0v-2.996A14.977 14.977 0 0112.004 15c4.904 0 9.26 2.354 11.996 5.993zM16.002 8.999a4 4 0 11-8 0 4 4 0 018 0z\"\n      />\n    </svg>\n  </div>\n  <span *ngSwitchCase=\"'initials'\" [ngClass]=\"classes\">\n    <span [ngClass]=\"[avatar.initials.text, textSize]\">\n      {{ children }}\n    </span>\n  </span>\n\n  <img\n    id=\"ds-avatar\"\n    *ngSwitchDefault\n    [ngClass]=\"classes\"\n    [src]=\"src\"\n    [alt]=\"alt\"\n    width=\"100\"\n    height=\"100\"\n  />\n</ng-container>\n",
                changeDetection: ChangeDetectionStrategy.OnPush,
                encapsulation: ViewEncapsulation.None
            }] }
];
AvatarComponent.propDecorators = {
    variant: [{ type: Input }],
    size: [{ type: Input }],
    alt: [{ type: Input }],
    src: [{ type: Input }],
    className: [{ type: Input }],
    children: [{ type: Input }]
};

const theme$8 = {
    default: {
        wrapper: 'w-full',
        list: {
            container: 'flex space-x-2 rounded-lg bg-level-3 p-1 w-fit',
            tab: {
                base: 'w-fit text-[0.75rem]/[1.125rem] rounded p-3 !outline-none focus:!outline-none focus:!border-none focus:!ring-0 text-nowrap transition-all duration-300 ease-in-out',
                selected: 'font-bold bg-red-50 text-red-500',
                unselected: 'bg-transparent text-neutral-600 hover:bg-red-50 hover:text-red-500  disabled:hover:bg-transparent disabled:hover:text-neutral-600',
            },
        },
        panels: {
            container: '',
            panel: {
                base: 'rounded-md text-heading dark:text-white py-3 focus:outline-none',
            },
        },
    },
    noBackground: {
        wrapper: 'w-full px-3',
        list: {
            container: 'flex space-x-2 w-fit',
            tab: {
                base: 'w-fit relative text-[0.875rem]/[1.125rem] rounded-t-lg py-2 px-3 focus:!outline-none !outline-none text-nowrap focus:!border-none focus:!ring-0 transition-all duration-300 ease-in-out after:absolute after:bottom-0 after:left-1/2 after:-translate-x-1/2 after:w-[18px] after:rounded-t-full after:h-[3px] after:bg-red-500 after:transition-all after:duration-300 after:ease-in-out after:opacity-0 after:content-[""]',
                selected: 'font-bold bg-level-4 text-neutral-900 after:opacity-100',
                unselected: 'bg-transparent text-neutral-600 hover:bg-level-4 hover:text-neutral-900 hover:after:opacity-100 disabled:hover:bg-transparent disabled:hover:text-neutral-600 disabled:hover:after:opacity-0',
            },
        },
        panels: {
            container: '',
            panel: {
                base: 'rounded-md !-mx-3 focus:outline-none',
            },
        },
    },
    withBorder: {
        wrapper: 'w-full ',
        list: {
            container: 'flex space-x-2 rounded bg-crame-100 p-1 w-fit',
            tab: {
                base: 'w-fit relative text-[0.875rem]/[1.125rem] rounded py-3 px-3 !shadow-none focus:!shadow-now focus:!outline-none !outline-none text-nowrap focus:!border-none focus:!ring-0 transition-all duration-300 ease-in-out after:absolute after:bottom-0 after:left-1/2 after:-translate-x-1/2 after:w-[70%] after:rounded-t-full after:h-[3px] after:bg-red-500 after:transition-all after:duration-300 after:ease-in-out after:opacity-0 after:content-[""]',
                selected: 'bg-level-3 text-neutral-900 after:opacity-100 font-bold',
                unselected: 'bg-transparent text-neutral-900 hover:bg-level-3 hover:text-neutral-900 hover:after:opacity-100 disabled:hover:bg-transparent disabled:hover:text-neutral-500 disabled:hover:after:opacity-0',
            },
        },
        panels: {
            container: '',
            panel: {
                base: 'rounded-md text-heading dark:text-white py-3 focus:outline-none',
            },
        },
    },
};

/**
 * TabsComponent
 *
 * Live demo:
 * <example-url>/demo/ds-tabs.component.html</example-url>
 */
class DsTabsComponent {
    constructor() {
        this.items = [];
        this.className = '';
        this.variant = 'default';
        this.onSelect = new EventEmitter();
        this.selectedIndex = 0;
        this.theme = theme$8;
    }
    selectTab(event, tab, index) {
        if (tab.disabled || tab.href) {
            return;
        }
        this.selectedIndex = index;
        this.onSelect.emit({ event, tab, index });
    }
    isSelected(index) {
        return this.selectedIndex === index;
    }
    isTemplate(ref) {
        return ref instanceof TemplateRef;
    }
}
DsTabsComponent.decorators = [
    { type: Component, args: [{
                selector: 'ds-tabs',
                template: "<div id=\"ds-tabs\" [ngClass]=\"[theme[variant].wrapper, className]\">\n  <div class=\"flex items-center justify-between\">\n    <div [ngClass]=\"[theme[variant].list.container]\">\n      <ng-container *ngFor=\"let tab of items; let idx = index\">\n        <button\n          *ngIf=\"!tab.href; else linkTab\"\n          (click)=\"selectTab($event, tab, idx)\"\n          [ngClass]=\"[\n            theme[variant].list.tab.base,\n            isSelected(idx)\n              ? theme[variant].list.tab.selected\n              : theme[variant].list.tab.unselected,\n            tab.disabled ? 'cursor-not-allowed opacity-40' : ''\n          ]\"\n          [attr.aria-selected]=\"isSelected(idx) ? 'true' : 'false'\"\n          [attr.aria-disabled]=\"tab.disabled ? 'true' : null\"\n          [attr.disabled]=\"tab.disabled ? true : null\"\n          [style.box-shadow]=\"'none !important'\"\n          [style.outline]=\"'none !important'\"\n        >\n          {{ tab.title }}\n        </button>\n\n        <ng-template #linkTab>\n          <a\n            [href]=\"tab.href\"\n            [routerLink]=\"tab.link\"\n            [ngClass]=\"[\n              theme[variant].list.tab.base || '',\n              isSelected(idx)\n                ? theme[variant].list.tab.selected || ''\n                : theme[variant].list.tab.unselected || ''\n            ]\"\n            [attr.aria-disabled]=\"tab.disabled ? 'true' : null\"\n            [attr.disabled]=\"tab.disabled ? true : null\"\n          >\n            {{ tab.title }}\n          </a>\n        </ng-template>\n      </ng-container>\n    </div>\n    <ng-container *ngIf=\"rightContent\">\n      <ng-container *ngTemplateOutlet=\"rightContent\"></ng-container>\n    </ng-container>\n  </div>\n\n  <div [ngClass]=\"[theme[variant].panels.container]\">\n    <div\n      *ngFor=\"let tab of items; let idx = index\"\n      [hidden]=\"!isSelected(idx)\"\n      [ngClass]=\"theme[variant].panels.panel.base || ''\"\n    >\n      <ng-container *ngIf=\"isTemplate(tab.panel); else showHtml\">\n        <ng-container *ngTemplateOutlet=\"tab.panel\"></ng-container>\n      </ng-container>\n      <ng-template #showHtml>\n        <div [innerHTML]=\"tab.panel\"></div>\n      </ng-template>\n    </div>\n  </div>\n</div>\n"
            }] }
];
DsTabsComponent.propDecorators = {
    items: [{ type: Input }],
    className: [{ type: Input }],
    variant: [{ type: Input }],
    rightContent: [{ type: Input }],
    onSelect: [{ type: Output }],
    selectedIndex: [{ type: Input }]
};

const typography = {
    'text-3xs/Light': 'text-3xs font-light',
    'text-3xs/Regular': 'text-3xs font-normal',
    'text-3xs/Medium': 'text-3xs font-medium',
    'text-3xs/Semibold': 'text-3xs font-semibold',
    'text-3xs/Bold': 'text-3xs font-bold',
    'body/Medium': 'text-3xs font-medium',
    'text-2xs/Light': 'text-2xs font-light',
    'text-2xs/Regular': 'text-2xs font-normal',
    'text-2xs/Medium': 'text-2xs font-medium',
    'text-2xs/Semibold': 'text-2xs font-semibold',
    'text-2xs/Bold': 'text-2xs font-bold',
    'text-xs/Light': 'text-xs font-light',
    'text-xs/Regular': 'text-xs font-normal',
    'text-xs/Medium': 'text-xs font-medium',
    'text-xs/Semibold': 'text-xs font-semibold',
    'text-xs/Bold': 'text-xs font-bold',
    'text-sm/Light': 'text-sm font-light',
    'text-sm/Regular': 'text-sm font-normal',
    'text-sm/Medium': 'text-sm font-medium',
    'text-sm/Semibold': 'text-sm font-semibold',
    'text-sm/Bold': 'text-sm font-bold',
    'text-base/Light': 'text-base font-light',
    'text-base/Regular': 'text-base font-normal',
    'text-base/Medium': 'text-base font-medium',
    'text-base/Semibold': 'text-base font-semibold',
    'text-base/Bold': 'text-base font-bold',
    'text-md/Light': 'text-md font-light',
    'text-md/Regular': 'text-md font-normal',
    'text-md/Medium': 'text-md font-medium',
    'text-md/Semibold': 'text-md font-semibold',
    'text-md/Bold': 'text-md font-bold',
    'text-lg/Light': 'text-lg font-light',
    'text-lg/Regular': 'text-lg font-normal',
    'text-lg/Medium': 'text-lg font-medium',
    'text-lg/Semibold': 'text-lg font-semibold',
    'text-lg/Bold': 'text-lg font-bold',
    'text-xl/Light': 'text-xl font-light',
    'text-xl/Regular': 'text-xl font-normal',
    'text-xl/Medium': 'text-xl font-medium',
    'text-xl/Semibold': 'text-xl font-semibold',
    'text-xl/Bold': 'text-xl font-bold',
    'text-2xl/Light': 'text-2xl font-light',
    'text-2xl/Regular': 'text-2xl font-normal',
    'text-2xl/Medium': 'text-2xl font-medium',
    'text-2xl/Semibold': 'text-2xl font-semibold',
    'text-2xl/Bold': 'text-2xl font-bold',
    'paragraph-title': 'text-[1.375rem] leading-[28px] md:text-[2rem] md:leading-[45px] font-semibold',
    nostyle: '',
};

/**
 * TextComponent
 *
 * Live demo:
 * <example-url>/demo/ds-text.component.html</example-url>
 */
class DsTextComponent {
    constructor(el, renderer) {
        this.el = el;
        this.renderer = renderer;
        this.variant = 'text-base/Regular';
        this.tag = 'p';
        this.className = '';
        this.content = '';
        this.currentTag = 'p';
    }
    ngAfterViewInit() {
        this.createElement(); // Initial render
    }
    ngOnChanges(changes) {
        if (!this.tagElement)
            return;
        // If tag name changed, replace the element
        if (changes['tag'] && changes['tag'].currentValue !== this.currentTag) {
            this.replaceElement();
        }
        else {
            this.updateElement(); // just update class/content
        }
    }
    createElement() {
        this.currentTag = this.tag || 'p';
        this.tagElement = this.renderer.createElement(this.currentTag);
        this.renderer.appendChild(this.el.nativeElement, this.tagElement);
        this.updateElement();
    }
    replaceElement() {
        if (this.tagElement) {
            this.renderer.removeChild(this.el.nativeElement, this.tagElement);
        }
        this.createElement();
    }
    updateElement() {
        const variantClass = typography[this.variant] || '';
        const allClasses = `${variantClass} ${this.className}`.trim();
        this.renderer.setAttribute(this.tagElement, 'class', allClasses || '');
        this.renderer.setAttribute(this.tagElement, 'id', 'ds-text');
        this.renderer.setProperty(this.tagElement, 'innerHTML', this.content || '');
    }
}
DsTextComponent.decorators = [
    { type: Component, args: [{
                selector: 'ds-text',
                template: ''
            }] }
];
/** @nocollapse */
DsTextComponent.ctorParameters = () => [
    { type: ElementRef },
    { type: Renderer2 }
];
DsTextComponent.propDecorators = {
    variant: [{ type: Input }],
    tag: [{ type: Input }],
    className: [{ type: Input }],
    content: [{ type: Input }]
};

const Theme = {
    textTitle: 'text-md font-semibold',
    textDescription: 'text-md',
};

/**
 * Empty-cardComponent
 *
 * Live demo:
 * <example-url>/demo/ds-empty-card.component.html</example-url>
 */
class EmptyCardComponent {
    constructor() {
        this.isLoading = false;
        this.onClick = new EventEmitter();
        this.theme = Theme;
    }
    handleClick(event) {
        event.preventDefault();
        this.onClick.emit({ event: event, data: this.data });
    }
}
EmptyCardComponent.decorators = [
    { type: Component, args: [{
                selector: 'ds-empty-card',
                template: "<div\n  id=\"ds-empty-card\"\n  class=\"flex items-center justify-center py-16 relative text-primary-600\"\n>\n  <div\n    *ngIf=\"isLoading\"\n    class=\"absolute inset-0 z-50 flex items-center justify-center dark:bg-black/60 bg-white/60\"\n  >\n    <ds-icon id=\"Loader\" class=\"size-7 animate-spin\"></ds-icon>\n  </div>\n\n  <div class=\"flex flex-col items-center gap-y-6\">\n    <img\n      [src]=\"image\"\n      alt=\"error icon\"\n      width=\"64\"\n      height=\"64\"\n      class=\"size-16\"\n    />\n\n    <span *ngIf=\"title\" class=\"text-gray-700\" [ngClass]=\"theme.textTitle\">\n      {{ title }}\n    </span>\n\n    <span class=\"text-gray-600\" [ngClass]=\"theme.textDescription\">\n      {{ description }}\n    </span>\n\n    <ds-button\n      *ngIf=\"buttonLabel\"\n      variant=\"secondary\"\n      (onClick)=\"handleClick($event)\"\n    >\n      {{ buttonLabel }}\n    </ds-button>\n  </div>\n</div>\n"
            }] }
];
EmptyCardComponent.propDecorators = {
    title: [{ type: Input }],
    description: [{ type: Input }],
    buttonLabel: [{ type: Input }],
    image: [{ type: Input }],
    isLoading: [{ type: Input }],
    data: [{ type: Input }],
    onClick: [{ type: Output }]
};

const breadcrumb = {
    default: {
        wrapper: 'text-neutral-500 font-normal flex items-center justify-start gap-2',
        list: 'flex items-center',
        listElement: 'flex items-center group',
        link: 'text-[0.75rem]/[0.875rem] hover:text-primary-400 no-underline active:text-neutral-700',
        linkActive: 'text-[0.75rem]/[0.875rem] text-neutral-900 font-bold no-underline',
        separator: 'mx-2 text-neutral-500',
    },
};

/**
 * BreadcrumbComponent
 *
 * Live demo:
 * <example-url>/demo/ds-breadcrumb.component.html</example-url>
 */
class DsBreadcrumbComponent {
    constructor() {
        this.nextUrl = '';
        this.nextClassName = '';
        this.prevUrl = '';
        this.prevClassName = '';
        this.homeUrl = '';
        this.className = '';
        this.variant = 'default';
        this.pages = [];
        this.showLimit = false;
    }
    get list() {
        if (this.homeUrl && this.pages.length > 2 && this.showLimit) {
            return this.pages.slice(0, 1);
        }
        else if (this.pages.length > 3 && this.showLimit) {
            return this.pages.slice(0, 2);
        }
        return this.pages;
    }
    get lastPage() {
        return this.pages[this.pages.length - 1];
    }
    get theme() {
        return breadcrumb[this.variant];
    }
}
DsBreadcrumbComponent.decorators = [
    { type: Component, args: [{
                selector: 'ds-breadcrumb',
                template: "<div id=\"ds-breadcrumb\" [ngClass]=\"theme.wrapper\" [class]=\"className\">\n  <a [href]=\"prevUrl\" [class]=\"prevClassName\">\n    <ds-icon id=\"arrow-left\" size=\"12px\"> </ds-icon>\n  </a>\n  <a [href]=\"nextUrl\" [class]=\"nextClassName\">\n    <ds-icon id=\"arrow-right\" size=\"12px\"> </ds-icon>\n  </a>\n\n  <ol role=\"list\" [ngClass]=\"theme.list\">\n    <li *ngIf=\"homeUrl\" [ngClass]=\"theme.listElement\">\n      <a [href]=\"homeUrl\" [ngClass]=\"theme.link\">\n        <span *ngIf=\"!showLimit\" [ngClass]=\"theme.link\"> Accueil </span>\n        <ds-icon id=\"home\" size=\"12px\" *ngIf=\"showLimit\" [ngClass]=\"theme.link\"></ds-icon>\n      </a>\n    </li>\n\n    <ng-container *ngFor=\"let page of list; let i = index\">\n      <li [ngClass]=\"theme.listElement\">\n        <span *ngIf=\"i !== 0 || homeUrl\" [ngClass]=\"theme.separator\">/</span>\n\n        <a\n          *ngIf=\"i < list.length - 1\"\n          [href]=\"page.href || '#.'\"\n          [attr.aria-current]=\"page.current ? 'page' : null\"\n          [ngClass]=\"page.current ? theme.linkActive : theme.link\"\n        >\n          {{ page.name }}\n        </a>\n        <div\n          *ngIf=\"i === list.length - 1\"\n          [attr.aria-current]=\"page.current ? 'page' : null\"\n          [ngClass]=\"page.current ? theme.linkActive : theme.link\"\n        >\n          {{ page.name }}\n        </div>\n      </li>\n    </ng-container>\n\n    <ng-container *ngIf=\"list.length !== pages.length\">\n      <li [ngClass]=\"theme.listElement\">\n        <span [ngClass]=\"theme.separator\">/</span>\n        <span [ngClass]=\"theme.link\"> ... </span>\n      </li>\n\n      <li [ngClass]=\"theme.listElement\">\n        <span [ngClass]=\"theme.separator\">/</span>\n        <div\n          [ngClass]=\"lastPage.current ? theme.linkActive : theme.link\"\n          [attr.aria-current]=\"lastPage.current ? 'page' : null\"\n        >\n          <span [ngClass]=\"theme.link\">\n            {{ lastPage.name }}\n          </span>\n        </div>\n      </li>\n    </ng-container>\n  </ol>\n</div>\n"
            }] }
];
DsBreadcrumbComponent.propDecorators = {
    nextUrl: [{ type: Input }],
    nextClassName: [{ type: Input }],
    prevUrl: [{ type: Input }],
    prevClassName: [{ type: Input }],
    homeUrl: [{ type: Input }],
    className: [{ type: Input }],
    variant: [{ type: Input }],
    pages: [{ type: Input }],
    showLimit: [{ type: Input }]
};

const ToggleTheme = {
    default: {
        switch: {
            className: 'relative inline-flex items-center transition-all duration-300 ease-in h-[20px] rounded-full w-[36px]',
            enabled: 'bg-success-500',
            disabled: 'bg-neutral-200',
            span: {
                enabled: 'translate-x-[17px] rtl:-translate-x-[17px]',
                disabled: 'translate-x-[2px] rtl:-translate-x-[2px]',
                className: 'inline-block transition-all duration-150 ease-in w-[17px] h-[17px] transform bg-level-4 rounded-full',
            },
        },
    },
};
const Theme$1 = {
    toggle: ToggleTheme,
};

/**
 * ToggleComponent
 *
 * Live demo:
 * <example-url>/demo/ds-toggle.component.html</example-url>
 */
class DsToggleComponent {
    constructor() {
        this.variant = 'default';
        this.className = '';
        this.disabled = false;
        this.checked = false;
        this.onChange = new EventEmitter();
        this.enabled = false;
        this.theme = Theme$1;
    }
    ngOnChanges(changes) {
        if (changes.checked) {
            this.enabled = this.checked;
        }
    }
    toggleChecked() {
        if (!this.disabled) {
            this.enabled = !this.enabled;
            this.onChange.emit(this.enabled);
        }
    }
}
DsToggleComponent.decorators = [
    { type: Component, args: [{
                selector: 'ds-toggle',
                template: "<div\n  id=\"ds-toggle\"\n  (click)=\"toggleChecked()\"\n  class=\"relative inline-flex cursor-pointer items-center h-[20px] rounded-full w-[36px]\"\n  [ngClass]=\"[\n    enabled\n      ? theme.toggle[variant].switch.enabled\n      : theme.toggle[variant].switch.disabled,\n    theme.toggle[variant].switch.className,\n    disabled ? 'cursor-not-allowed opacity-50' : '',\n    className\n  ]\"\n>\n  <span\n    [ngClass]=\"[\n      enabled\n        ? theme.toggle[variant].switch.span.enabled\n        : theme.toggle[variant].switch.span.disabled,\n      theme.toggle[variant].switch.span.className\n    ]\"\n  ></span>\n</div>\n"
            }] }
];
DsToggleComponent.propDecorators = {
    variant: [{ type: Input }],
    className: [{ type: Input }],
    disabled: [{ type: Input }],
    checked: [{ type: Input }],
    onChange: [{ type: Output }]
};

const theme$9 = {
    base: '',
    variants: {
        base: 'relative overflow-hidden',
        neutral: {
            bar: 'bg-neutral-50 h-2 w-full rounded-full',
            progress: 'absolute left-0 top-0 bottom-0 bg-neutral-300 rounded-full',
        },
        success: {
            bar: 'bg-neutral-50 h-2 w-full rounded-full',
            progress: 'absolute left-0 top-0 bottom-0 bg-success-500 rounded-full',
        },
        warning: {
            bar: 'bg-neutral-50 h-2 w-full rounded-full',
            progress: 'absolute left-0 top-0 bottom-0 bg-amber-500 rounded-full',
        },
        error: {
            bar: 'bg-neutral-50 h-2 w-full rounded-full',
            progress: 'absolute left-0 top-0 bottom-0 bg-error-500 rounded-full',
        },
    },
};

/**
 * ProgressComponent
 *
 * Live demo:
 * <example-url>/demo/ds-progress.component.html</example-url>
 */
class ProgressComponent {
    constructor() {
        this.variant = 'neutral';
        this.type = 'block';
        this.percentage = 0;
        this.suffix = '';
        this.className = '';
        this.appliedTheme = theme$9;
    }
    get calcPercentage() {
        if (!this.total) {
            return this.percentage;
        }
        return (this.percentage / this.total) * 100;
    }
}
ProgressComponent.decorators = [
    { type: Component, args: [{
                selector: 'ds-progress',
                template: "<div\n  id=\"ds-progress\"\n  [ngClass]=\"[\n    'w-full',\n    type === 'inline' ? 'flex justify-start items-center gap-4' : '',\n    className\n  ]\"\n>\n  <span\n    *ngIf=\"type === 'block'\"\n    [ngClass]=\"[\n      'inline-flex mb-1 w-full items-center',\n      label ? 'justify-between' : 'justify-end'\n    ]\"\n  >\n    <span *ngIf=\"label\" class=\"text-neutral-900 text-[1rem]/normal font-medium\">\n      {{ label }}\n    </span>\n    <span class=\"text-neutral-900 text-[1rem]/[1.375rem] font-bold\">\n      {{ percentage }}{{ suffix }}{{ total ? \"/\" + total : \"\" }}\n    </span>\n  </span>\n\n  <div\n    [ngClass]=\"[\n      appliedTheme.variants.base || '',\n      appliedTheme.variants[variant].bar || ''\n    ]\"\n  >\n    <div\n      class=\"transition-[color, width] duration-300 ease-in-out\"\n      [ngClass]=\"appliedTheme.variants[variant].progress || ''\"\n      [style.width.%]=\"calcPercentage\"\n    ></div>\n  </div>\n\n  <span\n    *ngIf=\"type === 'inline'\"\n    class=\"text-neutral-900 text-[1rem]/[1.375rem] font-bold\"\n  >\n    {{ percentage }}{{ suffix }}{{ total ? \"/\" + total : \"\" }}\n  </span>\n</div>\n"
            }] }
];
ProgressComponent.propDecorators = {
    variant: [{ type: Input }],
    type: [{ type: Input }],
    label: [{ type: Input }],
    percentage: [{ type: Input }],
    suffix: [{ type: Input }],
    total: [{ type: Input }],
    className: [{ type: Input }]
};

const dropdown = {
    base: 'relative isolate inline-block',
    button: {
        base: 'flex w-full items-center gap-2 justify-between focus:outline-none focus:border-none data-[hover]:text-custom-black',
        active: '',
    },
    container: 'p-1 absolute mt-2 min-w-[150px] origin-top-right rounded-md border border-neutral-100 bg-level-4 text-neutral-900 shadow-dropdown focus:outline-none',
    item: {
        base: 'group whitespace-nowrap flex justify-start gap-2 w-full items-center rounded-md p-3 hover:bg-neutral-50 text-[0.875rem]/normal font-[400]',
    },
    variants: {
        base: '',
        select: 'border border-gray-300 py-2 px-2 rounded',
    },
    icon: 'text-heading shrink-0 dark:text-white h-5 w-5 font-semibold',
};

// dropdown.component.ts
/**
 * DropdownComponent
 *
 * Live demo:
 * <example-url>/demo/ds-dropdown.component.html</example-url>
 */
class DsDropdownComponent {
    constructor(cd, vcr, cfr, appRef, injector, document) {
        this.cd = cd;
        this.vcr = vcr;
        this.cfr = cfr;
        this.appRef = appRef;
        this.injector = injector;
        this.document = document;
        this.items = [];
        this.variant = 'base';
        this.className = '';
        this.isOpen = false;
        this.menuStyles = {};
        this.handleOutsideClick = (e) => {
            const tgt = e.target;
            if (this.isOpen &&
                !this.trigger.nativeElement.contains(tgt) &&
                this.menu &&
                !this.menu.nativeElement.contains(tgt)) {
                this.closeMenu();
            }
        };
        this.dropdown = dropdown;
    }
    ngOnInit() {
        // set up a portal host on <body>
        this.portalHost = new DomPortalHost(this.document.body, this.cfr, this.appRef, this.injector);
        document.addEventListener('click', this.handleOutsideClick, true);
    }
    ngOnDestroy() {
        document.removeEventListener('click', this.handleOutsideClick, true);
        this.portalHost.detach(); // clean up
    }
    toggleMenu() {
        if (!this.isOpen) {
            // prepare a fresh portal
            this.menuPortal = new TemplatePortal(this.menuTpl, this.vcr);
            // attach it (renders the <ng-template> into <body>)
            this.portalHost.attach(this.menuPortal);
            this.menuStyles = {
                position: 'fixed',
                visibility: 'hidden',
                top: '0px',
                left: '0px',
                zIndex: `${++DsDropdownComponent.zIndexCounter}`,
            };
            this.isOpen = true;
            this.cd.detectChanges();
            this.setMenuPosition();
            this.menuStyles.visibility = 'visible';
        }
        else {
            this.closeMenu();
        }
    }
    setMenuPosition() {
        const t = this.trigger.nativeElement.getBoundingClientRect();
        const mEl = this.menu.nativeElement;
        const mW = mEl.offsetWidth, mH = mEl.offsetHeight;
        const vw = window.innerWidth, vh = window.innerHeight;
        let top = t.bottom;
        if (t.bottom + mH > vh) {
            top = t.top - mH;
        }
        top = Math.max(0, top);
        let left = t.left;
        if (t.left + mW > vw) {
            left = t.right - mW;
        }
        left = Math.max(0, left);
        Object.assign(this.menuStyles, {
            top: `${top}px`,
            left: `${left}px`,
        });
    }
    closeMenu() {
        if (this.portalHost.hasAttached()) {
            this.portalHost.detach();
        }
        this.isOpen = false;
        this.menuStyles = {};
    }
    onItemClick(event, cb) {
        if (cb) {
            cb(event);
        }
        this.closeMenu();
    }
    stopEvent(event) {
        event.stopPropagation();
    }
}
DsDropdownComponent.zIndexCounter = 10000;
DsDropdownComponent.decorators = [
    { type: Component, args: [{
                selector: 'ds-dropdown',
                template: "<div id=\"ds-dropdown\" [ngClass]=\"[dropdown.base, className]\">\n  <button\n    #trigger\n    (click)=\"toggleMenu()\"\n    [ngClass]=\"[\n      dropdown.button.base,\n      isOpen ? dropdown.button.active : '',\n      dropdown.variants[variant] || ''\n    ]\"\n  >\n    <ng-content></ng-content>\n  </button>\n\n  <!-- drop this inline *ngIf block\u2026 -->\n  <ng-template #menuTpl>\n    <div\n      #menu\n      @dropdownAnim\n      [ngClass]=\"dropdown.container\"\n      [ngStyle]=\"menuStyles\"\n    >\n      <button\n        *ngFor=\"let item of items\"\n        (click)=\"onItemClick($event, item.onClick)\"\n        [ngClass]=\"dropdown.item.base\"\n        type=\"button\"\n      >\n        <ds-icon\n          *ngIf=\"item.icon\"\n          [id]=\"item.icon\"\n          [className]=\"dropdown.icon\"\n        ></ds-icon>\n        <span class=\"text-[0.875rem]/[1.125rem] font-semibold\">{{ item.label }}</span>\n      </button>\n    </div>\n  </ng-template>\n</div>\n",
                animations: [
                    trigger('dropdownAnim', [
                        // enter: from nothing → visible
                        transition(':enter', [
                            style({ opacity: 0, transform: 'scale(0.95)' }),
                            animate('120ms ease-out', style({ opacity: 1, transform: 'scale(1)' })),
                        ]),
                        // leave: from visible → nothing
                        transition(':leave', [
                            animate('100ms ease-in', style({ opacity: 0, transform: 'scale(0.95)' })),
                        ]),
                    ]),
                ]
            }] }
];
/** @nocollapse */
DsDropdownComponent.ctorParameters = () => [
    { type: ChangeDetectorRef },
    { type: ViewContainerRef },
    { type: ComponentFactoryResolver },
    { type: ApplicationRef },
    { type: Injector },
    { type: undefined, decorators: [{ type: Inject, args: [DOCUMENT,] }] }
];
DsDropdownComponent.propDecorators = {
    items: [{ type: Input }],
    variant: [{ type: Input }],
    className: [{ type: Input }],
    trigger: [{ type: ViewChild, args: ['trigger',] }],
    menuTpl: [{ type: ViewChild, args: ['menuTpl',] }],
    menu: [{ type: ViewChild, args: ['menu',] }],
    stopEvent: [{ type: HostListener, args: ['click', ['$event'],] }]
};

const theme$a = {
    base: 'fixed z-[1001]',
    overlay: 'fixed inset-0 dark:bg-black/60 bg-black/40 transition-opacity',
    rounded: 'rounded',
    panel: 'mx-auto w-auto max-w-full h-auto overflow-hidden dark:bg-black bg-white',
    variants: {
        modal: {
            base: 'fixed left-1/2 top-1/2 -translate-x-1/2 -translate-y-1/2 flex items-center justify-center max-w-fit',
            panel: 'rounded p-6 pt-7 h-fit flex flex-col items-start',
        },
        slideLeft: {
            base: 'top-0 right-0 bottom-0 fixed max-w-fit',
            panel: 'p-6 h-full',
        },
        slideRight: {
            base: 'top-0 left-0 bottom-0 fixed max-w-fit',
            panel: 'p-4 h-full',
        },
    },
};

/**
 * PopupComponent
 *
 * Live demo:
 * <example-url>/demo/ds-popup.component.html</example-url>
 */
class DsPopupComponent {
    constructor(_elementRef, _renderer) {
        this._elementRef = _elementRef;
        this._renderer = _renderer;
        this.isShown = false;
        this.icon = '';
        this.type = 'info';
        this.variant = 'modal';
        this.className = '';
        this.panelClassName = '';
        this.isFullScreen = false;
        this.close = () => { };
        this.theme = theme$a;
    }
    onEscPressed(event) {
        if (this.isShown) {
            this.close();
        }
    }
    onClose() {
        this.isShown = false;
        this.close();
    }
    ngOnDestroy() {
        this.removeListeners();
    }
    removeListeners() {
        // Cleanup logic if needed
    }
    onBackdropClick(event) {
        if (event.target.classList.contains('popup-overlay')) {
            this.close();
        }
    }
    getAnimationClass() {
        if (this.variant === 'slideLeft') {
            return 'animate-slideInLeft';
        }
        else if (this.variant === 'slideRight') {
            return 'animate-slideInRight';
        }
        else {
            return 'animate-fadeInScale';
        }
    }
}
DsPopupComponent.decorators = [
    { type: Component, args: [{
                selector: 'ds-popup',
                template: "<div\n  id=\"ds-popup\"\n  *ngIf=\"isShown\"\n  class=\"fixed inset-0\"\n  [ngClass]=\"[theme.base, className]\"\n>\n  <!-- Backdrop -->\n  <div\n    class=\"popup-overlay\"\n    [ngClass]=\"theme.overlay\"\n    (click)=\"onBackdropClick($event)\"\n  ></div>\n\n  <!-- Transition Panel -->\n  <div\n    class=\"absolute\"\n    [ngClass]=\"[\n      theme.variants[variant].base,\n      isFullScreen ? 'h-screen' : 'max-h-fit'\n    ]\"\n  >\n    <div\n      [ngClass]=\"[\n        theme.panel,\n        theme.variants[variant].panel,\n        getAnimationClass(),\n        panelClassName\n      ]\"\n    >\n      <button (click)=\"onClose()\" class=\"absolute top-1.5 right-1.5\">\n        <ds-icon id=\"close\" size=\"24px\"></ds-icon>\n      </button>\n      <div\n        *ngIf=\"icon\"\n        class=\"flex items-center justify-center p-2 rounded-full mb-3.5\"\n        [ngClass]=\"\n          type === 'success'\n            ? 'bg-green-100'\n            : type === 'warning'\n            ? 'bg-amber-100'\n            : type === 'error'\n            ? 'bg-red-100'\n            : 'bg-blue-100'\n        \"\n      >\n        <ds-icon\n          [id]=\"icon\"\n          size=\"1.25rem\"\n          [ngClass]=\"\n            type === 'success'\n              ? 'text-green-500'\n              : type === 'warning'\n              ? 'text-amber-500'\n              : type === 'error'\n              ? 'text-red-500'\n              : 'text-blue-500'\n          \"\n        ></ds-icon>\n      </div>\n      <h2 *ngIf=\"heading\" class=\"text-[1.25rem]/[1.5rem] font-bold\">\n        {{ heading }}\n      </h2>\n      <ng-content></ng-content>\n    </div>\n  </div>\n</div>\n"
            }] }
];
/** @nocollapse */
DsPopupComponent.ctorParameters = () => [
    { type: ElementRef },
    { type: Renderer2 }
];
DsPopupComponent.propDecorators = {
    isShown: [{ type: Input }],
    icon: [{ type: Input }],
    type: [{ type: Input }],
    heading: [{ type: Input }],
    variant: [{ type: Input }],
    className: [{ type: Input }],
    panelClassName: [{ type: Input }],
    isFullScreen: [{ type: Input }],
    close: [{ type: Input }],
    onEscPressed: [{ type: HostListener, args: ['document:keydown.escape', ['$event'],] }]
};

const theme$b = {
    default: {
        wrapper: 'text-[0.875rem]/[1.25rem] inline-block text-neutral-900 font-bold flex flex-row items-center justify-center w-fit gap-1',
        currency: 'inline-block align-text-top font-bold text-neutral-900 dark:text-white font-[400] ',
    },
};

/**
 * Balance-formatterComponent
 *
 * Live demo:
 * <example-url>/demo/ds-balance-formatter.component.html</example-url>
 */
class DsBalanceFormatterComponent {
    constructor() {
        this.isDiscrete = false;
        this.variant = 'default';
        this.balance = 0;
        this.noIcon = false;
        this.theme = theme$b;
    }
    get num() {
        return Math.abs(this.balance);
    }
    get wrapperClass() {
        return [
            this.theme[this.variant].wrapper || '',
            this.className,
            this.isDiscrete ? 'font-medium' : '',
        ].join(' ');
    }
    get iconClass() {
        return this.balance > 0 ? 'text-green-500' : 'text-red-500';
    }
    get showIcon() {
        return !this.noIcon && this.balance !== 0;
    }
    get iconId() {
        return this.balance > 0 ? 'plus2' : 'minus';
    }
}
DsBalanceFormatterComponent.decorators = [
    { type: Component, args: [{
                selector: 'ds-balance-formatter',
                template: "<ng-container *ngIf=\"balance !== 0\">\n  <span id=\"ds-balance-formatter\" [ngClass]=\"wrapperClass\">\n    <ng-container *ngIf=\"showIcon && !isDiscrete\">\n      <ds-icon [id]=\"iconId\" size=\"16px\"></ds-icon>\n    </ng-container>\n\n    <span *ngIf=\"isDiscrete; else formattedBalance\">\n      <span> ******* </span>\n    </span>\n    <ng-template #formattedBalance>\n      {{ num | number : \"1.2-2\" : \"fr-FR\" }}\n    </ng-template>\n\n    <ng-container *ngIf=\"currency\">\n      <span\n        [ngClass]=\"theme[variant]?.currency + ' ' + (currencyClassName || '')\"\n      >\n        {{ currency }}\n      </span>\n    </ng-container>\n  </span>\n</ng-container>\n"
            }] }
];
DsBalanceFormatterComponent.propDecorators = {
    isDiscrete: [{ type: Input }],
    variant: [{ type: Input }],
    balance: [{ type: Input }],
    currency: [{ type: Input }],
    className: [{ type: Input }],
    currencyClassName: [{ type: Input }],
    noIcon: [{ type: Input }]
};

/**
 * @ignore
 */
class DsDisplayValueComponent {
    get hasValue() {
        return !!this.value;
    }
}
DsDisplayValueComponent.decorators = [
    { type: Component, args: [{
                selector: 'ds-display-value',
                template: "<ng-container *ngIf=\"hasValue; else emptyValue\">\n  <ng-content></ng-content>\n</ng-container>\n\n<ng-template #emptyValue>\n  <span id=\"ds-display-value\" class=\"inline-block dark:text-white text-heading\">\n    -\n  </span>\n</ng-template>\n"
            }] }
];
DsDisplayValueComponent.propDecorators = {
    value: [{ type: Input }],
    className: [{ type: Input }]
};

/**
 * Theme-toggleComponent
 *
 * Live demo:
 * <example-url>/demo/ds-theme-toggle.component.html</example-url>
 */
class DsThemeToggleComponent {
    constructor() {
        this.theme = 'light';
        this.onThemeChange = new EventEmitter();
    }
    ngOnInit() {
        this.initTheme();
    }
    initTheme() {
        const storedTheme = localStorage.getItem('storybook-theme');
        this.theme = storedTheme || 'light';
        this.applyThemeClass();
    }
    applyThemeClass() {
        const body = document.body;
        body.classList.toggle('dark', this.theme === 'dark');
        body.classList.toggle('light', this.theme === 'light');
    }
    toggleTheme() {
        this.theme = this.theme === 'dark' ? 'light' : 'dark';
        this.applyThemeClass();
        this.onThemeChange.emit(this.theme);
        localStorage.setItem('storybook-theme', this.theme);
        console.log('Theme toggled:', this.theme);
    }
}
DsThemeToggleComponent.decorators = [
    { type: Component, args: [{
                selector: 'ds-theme-toggle',
                template: `
    <button
      id="ds-theme-toggle"
      class="flex items-center justify-center"
      (click)="toggleTheme()"
      [attr.aria-label]="
        'Toggle theme to ' + (theme === 'dark' ? 'light' : 'dark')
      "
    >
      <ds-icon [id]="theme === 'dark' ? 'sun' : 'moon'"></ds-icon>
    </button>
  `
            }] }
];
DsThemeToggleComponent.propDecorators = {
    onThemeChange: [{ type: Output }]
};

const paginationVariants = {
    default: {
        wrapper: 'ds-pagination flex flex-wrap items-center justify-between gap-4 rounded',
        container: 'bg-level-3 border flex flex-wrap items-stretch justify-center border-neutral-100 rounded-md overflow-hidden',
        nextPrevButtons: {
            base: 'inline-flex font-medium text-neutral-500 items-center gap-2 text-[0.875rem]/[1.125rem] px-3 py-2 disabled:opacity-40 disabled:cursor-not-allowed',
            prev: {
                base: '',
                id: 'arrow-left',
                size: '1rem',
            },
            next: {
                base: '',
                id: 'arrow-right',
                size: '1rem',
            },
        },
        buttons: {
            base: 'flex items-stretch',
            button: {
                base: ' text-[0.875rem]/[1.125rem] border-r border-neutral-100 text-neutral-500 w-[32px] h-full flex items-center justify-center',
                active: 'bg-neutral-100  text-neutral-500 font-bold',
                inactive: 'bg-level-4 font-medium',
            },
            ellipsis: 'px-2 text-neutral-500 w-[32px] h-full flex items-center justify-center border-r border-neutral-100 h-full block',
        },
        info: 'inline-flex font-medium items-center gap-x-[2px] text-neutral-500 text-[1rem]/[1.25rem]',
        perPage: {
            wrapper: 'flex items-center gap-x-2',
            label: 'text-[1rem]/normal text-gray-600 dark:text-gray-300',
            select: {
                base: 'px-2 py-1 border border-gray-300 dark:border-gray-600 rounded bg-white dark:bg-gray-700 text-gray-800 dark:text-gray-200 focus:outline-none',
                option: '',
            },
        },
    },
};

/**
 * PaginationComponent
 *
 * Live demo:
 * <example-url>/demo/ds-pagination.component.html</example-url>
 */
class DsPaginationComponent {
    constructor() {
        this.firstItem = 1;
        this.totalItems = 0;
        this.currentPage = 1;
        this.variant = 'default';
        this.className = '';
        this.showPerPage = true;
        this.minimized = false;
        this.pageChange = new EventEmitter();
        this.perPageChange = new EventEmitter();
        // ← boundary counts
        this.boundaryStartCount = 2;
        this.boundaryEndCount = 2;
        // ← how many neighbours around current page
        this.windowSize = 1;
        this.prevLabel = 'Précédent';
        this.nextLabel = 'Suivant';
        this.perPageLabel = 'Par page';
        this.perPageOptions = [25, 50, 100];
        this.maxPageButtons = 5;
        this.theme = paginationVariants;
        this.pages = [];
        this.pageCount = 0;
        this.itemsPerPage = this.perPageOptions[0];
    }
    ngOnChanges(changes) {
        if (changes.totalItems ||
            changes.itemsPerPage ||
            changes.currentPage ||
            changes.variant) {
            this.calculatePages();
        }
    }
    calculatePages() {
        this.pageCount = Math.max(1, Math.ceil(this.totalItems / this.itemsPerPage));
        const total = this.pageCount;
        // never request more boundary pages than we actually have
        const startCnt = Math.min(this.boundaryStartCount, total);
        const endCnt = Math.min(this.boundaryEndCount, total);
        const win = this.windowSize;
        // build the three sets, now guaranteed within [1…total]
        const startPages = Array.from({ length: startCnt }, (_, i) => i + 1);
        const endPages = Array.from({ length: endCnt }, (_, i) => total - endCnt + 1 + i);
        // sliding window
        const windowStart = Math.max(this.currentPage - win, startCnt + 1);
        const windowEnd = Math.min(this.currentPage + win, total - endCnt);
        const windowPages = [];
        for (let i = windowStart; i <= windowEnd; i++) {
            windowPages.push(i);
        }
        // merge & inject ellipses
        const all = startPages
            .concat(windowPages, endPages)
            .filter((v, i, arr) => arr.indexOf(v) === i) // dedupe
            .sort((a, b) => a - b);
        const pages = [all[0]];
        for (let i = 1; i < all.length; i++) {
            const prev = all[i - 1];
            const curr = all[i];
            if (curr === prev + 1) {
                pages.push(curr);
            }
            else {
                pages.push('...', curr);
            }
        }
        this.pages = pages;
    }
    selectPage(page) {
        if (page < 1 || page > this.pageCount || page === this.currentPage) {
            return;
        }
        this.currentPage = page;
        this.pageChange.emit(this.currentPage);
        this.calculatePages();
    }
    prev() {
        this.selectPage(this.currentPage - 1);
    }
    next() {
        this.selectPage(this.currentPage + 1);
    }
    changePerPage(count) {
        this.itemsPerPage = count;
        this.perPageChange.emit(count);
        this.selectPage(1);
    }
}
DsPaginationComponent.decorators = [
    { type: Component, args: [{
                selector: 'ds-pagination',
                template: "<nav\n  *ngIf=\"pageCount > 1\"\n  id=\"ds-pagination\"\n  [ngClass]=\"[theme[variant].wrapper, className]\"\n>\n  <div class=\"flex items-center justify-center gap-x-2\">\n    <span [ngClass]=\"[theme[variant].info]\">\n      <span>(</span>\n      <span>{{ firstItem }}</span>\n      <span>-</span>\n      <span>{{ itemsPerPage }}</span>\n      <span>/</span>\n      <span>{{ totalItems }}</span>\n      <span>)</span>\n    </span>\n    <span *ngIf=\"showPerPage\" [ngClass]=\"[theme[variant].info]\">Par page:</span>\n    <ul *ngIf=\"showPerPage\" class=\"flex items-center justify-center gap-2\">\n      <li\n        class=\"text-[1rem]/[1.25rem]\"\n        [ngClass]=\"[\n          itemsPerPage === item ? 'text-red-500 font-bold' : 'text-neutral-700'\n        ]\"\n        *ngFor=\"let item of perPageOptions\"\n      >\n        <button (click)=\"changePerPage(item)\">\n          {{ item }}\n        </button>\n      </li>\n    </ul>\n  </div>\n  <div [ngClass]=\"[theme[variant].container]\">\n    <!-- Prev Button -->\n    <button\n      (click)=\"prev()\"\n      [disabled]=\"currentPage <= 1\"\n      [ngClass]=\"[\n        theme[variant].nextPrevButtons.base,\n        theme[variant].nextPrevButtons.prev.base,\n        currentPage <= 1\n          ? 'opacity-40 cursor-not-allowed'\n          : 'hover:bg-neutral-50'\n      ]\"\n    >\n      <ds-icon\n        [id]=\"theme[variant].nextPrevButtons.prev.id\"\n        [size]=\"theme[variant].nextPrevButtons.prev.size\"\n        [class]=\"theme[variant].nextPrevButtons.prev.base\"\n      >\n      </ds-icon>\n      {{ minimized ? \"\" : prevLabel }}\n    </button>\n\n    <!-- Page Buttons + Ellipsis -->\n    <ul [ngClass]=\"[theme[variant].buttons.base]\">\n      <li *ngFor=\"let pNum of pages\">\n        <ng-container *ngIf=\"pNum !== '...'\">\n          <button\n            (click)=\"selectPage(+pNum)\"\n            [ngClass]=\"[\n              theme[variant].buttons.button.base,\n              pNum === currentPage\n                ? theme[variant].buttons.button.active\n                : theme[variant].buttons.button.inactive,\n              pNum === 1 ? 'border-l' : ''\n            ]\"\n          >\n            {{ pNum }}\n          </button>\n        </ng-container>\n        <ng-container\n          *ngIf=\"pNum === '...'\"\n          class=\"border-r border-neutral-100 h-full\"\n        >\n          <span [ngClass]=\"[theme[variant].buttons.ellipsis]\">\u2026</span>\n        </ng-container>\n      </li>\n    </ul>\n\n    <!-- Next Button -->\n    <button\n      (click)=\"next()\"\n      [disabled]=\"currentPage >= pageCount\"\n      [ngClass]=\"[\n        theme[variant].nextPrevButtons.base,\n        theme[variant].nextPrevButtons.next.base,\n        currentPage >= pageCount\n          ? 'opacity-40 cursor-not-allowed'\n          : 'hover:bg-neutral-50'\n      ]\"\n    >\n      {{ minimized ? \"\" : nextLabel }}\n      <ds-icon\n        [id]=\"theme[variant].nextPrevButtons.next.id\"\n        [size]=\"theme[variant].nextPrevButtons.next.size\"\n        [class]=\"theme[variant].nextPrevButtons.next.base\"\n      >\n      </ds-icon>\n    </button>\n  </div>\n</nav>\n"
            }] }
];
/** @nocollapse */
DsPaginationComponent.ctorParameters = () => [];
DsPaginationComponent.propDecorators = {
    firstItem: [{ type: Input }],
    totalItems: [{ type: Input }],
    itemsPerPage: [{ type: Input }],
    currentPage: [{ type: Input }],
    variant: [{ type: Input }],
    className: [{ type: Input }],
    showPerPage: [{ type: Input }],
    minimized: [{ type: Input }],
    pageChange: [{ type: Output }],
    perPageChange: [{ type: Output }],
    boundaryStartCount: [{ type: Input }],
    boundaryEndCount: [{ type: Input }],
    windowSize: [{ type: Input }],
    prevLabel: [{ type: Input }],
    nextLabel: [{ type: Input }],
    perPageLabel: [{ type: Input }],
    perPageOptions: [{ type: Input }],
    maxPageButtons: [{ type: Input }]
};

/**
 * @ignore
 */
class DsBottomMenusComponent {
    constructor(host) {
        this.host = host;
        this.fontSize = localStorage.getItem('mybusiness-fontsize') || 'M';
        this.showCaps = false;
        this.sizes = [];
        this.defaultCap = { name: 'L', size: 18 };
        this.currentCap = this.defaultCap;
        this.profileMenus = [];
        this.lastLoginDate = 'Le 03.10.2024, à 16h45';
        this.language = {
            src: '/assets/france-flag.svg',
            alt: 'Français',
        };
        this.disableBottomMenus = false;
        this.callingOnClick = new EventEmitter();
        this.reclamationOnClick = new EventEmitter();
        this.languageOnClick = new EventEmitter();
        this.settingsOnClick = new EventEmitter();
        this.onThemeChange = new EventEmitter();
    }
    ngOnInit() {
        // Set the initial font size based on localStorage or default to 'M'
        const storedFontSize = localStorage.getItem('mybusiness-fontsize') || 'L';
        this.currentCap =
            this.sizes.find((item) => item.name === storedFontSize) || this.currentCap;
        document.documentElement.style.setProperty('--font-size', `${this.currentCap.size}px`);
        document.body.style.setProperty('--font-size', `${this.currentCap.size}px`);
        document.body.setAttribute('data-fontSize', `${JSON.stringify(this.currentCap)}`);
    }
    capsClick(event) {
        event.preventDefault();
        event.stopPropagation();
        this.showCaps = !this.showCaps;
    }
    onSizeChange(size) {
        this.currentCap = size;
        this.showCaps = false;
        document.documentElement.style.setProperty('--font-size', `${size.size}px`);
        document.body.style.setProperty('--font-size', `${size.size}px`);
        document.body.setAttribute('data-fontSize', `${JSON.stringify(this.currentCap)}`);
        localStorage.setItem('mybusiness-fontsize', size.name);
    }
    _onThemeChange(theme) {
        this.onThemeChange.emit(theme);
    }
    // ← listen to *all* clicks on the page
    onClickOutside(target) {
        // if the dropdown is open, but click was *not* inside this component, close it
        if (this.showCaps && !this.host.nativeElement.contains(target)) {
            this.showCaps = false;
            // if you ever see ExpressionChanged… errors here, you can:
            // this.cdr.detectChanges();
        }
    }
}
DsBottomMenusComponent.decorators = [
    { type: Component, args: [{
                selector: 'ds-bottom-menus',
                template: "<ul\n  class=\"w-full space-y-3.5 [&_li]:cursor-pointer text-white flex justify-center items-center flex-col pb-6\"\n>\n  <hr class=\"w-full border-[#355A57] mx-auto\" />\n\n  <li (click)=\"callingOnClick.emit($event)\" class=\"flex items-center justify-center group relative\" [ngClass]=\"{ 'cursor-not-allowed opacity-50 pointer-events-none': disableBottomMenus }\">\n    <ds-icon id=\"calling\" class=\"size-4\" [ngClass]=\"{ 'cursor-not-allowed': disableBottomMenus }\"></ds-icon>\n    <span *ngIf=\"!disableBottomMenus\" class=\"absolute bg-white py-2.5 px-3 text-[0.875rem] leading-[14px] font-bold rounded left-[calc(100%+20px)] top-1/2 w-max text-black -translate-y-1/2 inline-block shadow-tooltip opacity-0 group-hover:opacity-100 group-hover:-translate-x-0 z-[9998]\">\n      Besoin d'assistance\n    </span>\n  </li>\n  <li (click)=\"reclamationOnClick.emit($event)\" class=\"flex items-center justify-center group relative\" [ngClass]=\"{ 'cursor-not-allowed opacity-50 pointer-events-none': disableBottomMenus }\">\n    <ds-icon id=\"reclamation\" class=\"size-4\" [ngClass]=\"{ 'cursor-not-allowed': disableBottomMenus }\"></ds-icon>\n    <span *ngIf=\"!disableBottomMenus\" class=\"absolute bg-white py-2.5 px-3 text-[0.875rem] leading-[14px] font-bold rounded-lg left-[calc(100%+20px)] top-1/2 w-max text-black -translate-y-1/2 inline-block shadow-tooltip opacity-0 group-hover:opacity-100 group-hover:-translate-x-0 z-[9998]\">\n      Avez-vous une r\u00E9clamation ?\n    </span>\n  </li>\n  <li *ngIf=\"sizes.length > 0\" class=\"flex items-center justify-center group relative\">\n    <button (click)=\"capsClick($event)\">\n      <ds-icon id=\"smallcaps\" class=\"size-4\"></ds-icon>\n    </button>\n    <span *ngIf=\"!disableBottomMenus\" class=\"absolute bg-white py-2.5 px-3 text-[0.875rem] leading-[14px] font-bold rounded left-[calc(100%+20px)] top-1/2 w-max text-black -translate-y-1/2 inline-block shadow-tooltip opacity-0 group-hover:opacity-100 group-hover:-translate-x-0 z-[9998]\">\n      Accessibilit\u00E9\n    </span>\n    <ul\n      @dropdown\n      *ngIf=\"showCaps\"\n      class=\"absolute bg-white flex text-neutral-900 text-center justify-start items-center shadow-lg border border-neutral-100 left-[calc(100%+20px)] py-2 px-4 top-1/2 rounded-md gap-2 -translate-y-1/2 z-[9999]\"\n    >\n      <li\n        *ngFor=\"let size of sizes\"\n        class=\"border border-neutral-50 rounded shrink-0 w-10 inline-flex items-center justify-center aspect-square\"\n        [ngClass]=\"{ 'bg-neutral-100': currentCap.name === size.name }\"\n        (click)=\"onSizeChange(size)\"\n      >\n        {{ size.name }}\n      </li>\n    </ul>\n  </li>\n\n  <li (click)=\"languageOnClick.emit($event)\" class=\"flex items-center justify-center group relative\" [ngClass]=\"{ 'cursor-not-allowed opacity-50 pointer-events-none': disableBottomMenus }\">\n    <img\n      [alt]=\"language.alt || ''\"\n      [src]=\"language.src\"\n      class=\"size-4\"\n      [ngClass]=\"[\n      language.className,\n      { 'cursor-not-allowed': disableBottomMenus }\n      ]\"\n    />\n    <span *ngIf=\"!disableBottomMenus\" class=\"absolute bg-white py-2.5 px-3 text-[0.875rem] leading-[14px] font-bold rounded left-[calc(100%+20px)] top-1/2 w-max text-black -translate-y-1/2 inline-block shadow-tooltip opacity-0 group-hover:opacity-100 group-hover:-translate-x-0 z-[9998]\">\n      Choix de langue\n    </span>\n  </li>\n\n  <li class=\"flex items-center justify-center group relative\" [ngClass]=\"{ 'cursor-not-allowed opacity-50 pointer-events-none': disableBottomMenus }\">\n    <ds-theme-toggle (onThemeChange)=\"_onThemeChange($event)\" [ngClass]=\"{ 'cursor-not-allowed': disableBottomMenus }\"></ds-theme-toggle>\n    <span *ngIf=\"!disableBottomMenus\" class=\"absolute bg-white py-2.5 px-3 text-[0.875rem] leading-[14px] font-bold rounded left-[calc(100%+20px)] top-1/2 w-max text-black -translate-y-1/2 inline-block shadow-tooltip opacity-0 group-hover:opacity-100 group-hover:-translate-x-0 z-[9998]\">\n      Mode Sombre\n    </span>\n  </li>\n\n  <li (click)=\"settingsOnClick.emit($event)\" class=\"flex items-center justify-center group relative\" [ngClass]=\"{ 'cursor-not-allowed opacity-50 pointer-events-none': disableBottomMenus }\">\n    <ds-icon id=\"settings\" class=\"size-4\" [ngClass]=\"{ 'cursor-not-allowed': disableBottomMenus }\"></ds-icon>\n    <span *ngIf=\"!disableBottomMenus\" class=\"absolute bg-white py-2.5 px-3 text-[0.875rem] leading-[14px] font-bold rounded left-[calc(100%+20px)] top-1/2 w-max text-black -translate-y-1/2 inline-block shadow-tooltip opacity-0 group-hover:opacity-100 group-hover:-translate-x-0 z-[9998]\">\n      Param\u00E8tres\n    </span>\n  </li>\n\n  <hr class=\"w-full border-[#355A57] mx-auto\" />\n\n  <li [ngClass]=\"{ 'cursor-not-allowed opacity-50 pointer-events-none': disableBottomMenus }\">\n    <ds-profile-dropdown\n      [list]=\"profileMenus\"\n      position=\"bottomLeft\"\n      class=\"z-[1100]\"\n    >\n      <img\n        src=\"https://placehold.co/60\"\n        class=\"size-6 rounded-full\"\n        alt=\"current user logo\"\n        [ngClass]=\"{ 'cursor-not-allowed': disableBottomMenus }\"\n      />\n\n      <ng-template #suffix>\n        <li\n          class=\"font-medium text-[0.5rem] leading-[8px] space-y-2 bg-neutral-50 p-3\"\n        >\n          <span class=\"inline-block text-neutral-700\">Derniere Connexion</span>\n          <p class=\"text-neutral-900\">{{ lastLoginDate }}</p>\n        </li>\n      </ng-template>\n    </ds-profile-dropdown>\n  </li>\n</ul>\n",
                animations: [
                    trigger('dropdown', [
                        transition(':enter', [
                            style({
                                opacity: 0,
                                transform: 'translate(4px, var(--tw-translate-y)) scale(0.95)',
                            }),
                            animate('150ms ease-out', style({
                                opacity: 1,
                                transform: 'translate(0px, var(--tw-translate-y)) scale(1)',
                            })),
                        ]),
                        transition(':leave', [
                            animate('100ms ease-in', style({
                                opacity: 0,
                                transform: 'translate(-4px, var(--tw-translate-y)) scale(0.95)',
                            })),
                        ]),
                    ]),
                ]
            }] }
];
/** @nocollapse */
DsBottomMenusComponent.ctorParameters = () => [
    { type: ElementRef }
];
DsBottomMenusComponent.propDecorators = {
    sizes: [{ type: Input }],
    defaultCap: [{ type: Input }],
    profileMenus: [{ type: Input }],
    lastLoginDate: [{ type: Input }],
    language: [{ type: Input }],
    disableBottomMenus: [{ type: Input }],
    callingOnClick: [{ type: Output }],
    reclamationOnClick: [{ type: Output }],
    languageOnClick: [{ type: Output }],
    settingsOnClick: [{ type: Output }],
    onThemeChange: [{ type: Output }],
    onClickOutside: [{ type: HostListener, args: ['document:click', ['$event.target'],] }]
};

/**
 * @ignore
 */
class DsMenuItemComponent {
    constructor() {
        this.isFirst = false;
        this.disableMainMenus = false;
        this.href = '#';
        this.onClick = new EventEmitter();
    }
    get isActive() {
        return ((this.subMenuData && this.subMenuData.title) ===
            (this.menus && this.menus.title));
    }
    get wrapperClass() {
        let base = 'px-4 py-2.5 relative after:absolute flex justify-center items-center after:right-0 after:top-1/2 after:-translate-y-1/2 after:w-0 after:h-0 after:border-t-[6px] after:border-t-transparent after:border-r-[6px] after:border-b-[6px] after:border-b-transparent ';
        if (this.isActive) {
            base += this.subSidebarIsOpen
                ? 'after:border-r-white dark:after:border-r-white'
                : 'after:border-r-white dark:after:border-r-white-bg-dark';
        }
        else {
            base += 'after:border-r-transparent';
        }
        if (!this.subSidebarIsOpen && this.title) {
            base += ' group-hover:after:border-r-white';
        }
        return base;
    }
    handleClick() {
        if (!this.disableMainMenus) {
            this.onClick.emit();
        }
    }
}
DsMenuItemComponent.decorators = [
    { type: Component, args: [{
                selector: 'ds-menu-item',
                template: "<ng-container *ngIf=\"menus?.items?.length > 0; else linkTemplate\">\n  <button\n    (click)=\"handleClick()\"\n    [ngClass]=\"['group', isFirst ? 'text-black' : 'text-white']\"\n  >\n    <li [ngClass]=\"wrapperClass\">\n      <span\n        *ngIf=\"!subSidebarIsOpen && title\"\n        class=\"absolute bg-white py-2.5 px-3 text-[0.875rem] leading-[14px] font-bold rounded-lg left-[54px] top-1/2 w-max text-black -translate-y-1/2 inline-block shadow-tooltip opacity-0 group-hover:opacity-100 group-hover:-translate-x-0 -translate-x-full z-[9998]\"\n      >\n        {{ title }}\n      </span>\n\n      <span\n        [ngClass]=\"[\n          'rounded-[3px] size-[22px] inline-flex justify-center items-center transition-opacity duration-300 ease-in-out',\n          color,\n          !subSidebarIsOpen && title ? 'group-hover:opacity-60' : '',\n          disableMainMenus ? 'cursor-not-allowed opacity-60' : ''\n        ]\"\n      >\n        <ds-icon *ngIf=\"icon\" [id]=\"icon\" class=\"shrink-0 size-4\"></ds-icon>\n      </span>\n    </li>\n  </button>\n</ng-container>\n\n<ng-template #linkTemplate>\n  <a\n    [href]=\"disableMainMenus ? '#' : href\"\n    [ngClass]=\"['group', isFirst ? 'text-black' : 'text-white']\"\n  >\n    <li [ngClass]=\"wrapperClass\">\n      <span\n        *ngIf=\"!subSidebarIsOpen && title\"\n        class=\"absolute bg-white py-2.5 px-3 text-[0.875rem] leading-[14px] font-bold rounded-lg left-[54px] top-1/2 w-max text-black -translate-y-1/2 inline-block shadow-tooltip opacity-0 group-hover:opacity-100 group-hover:-translate-x-0 -translate-x-full z-[9998]\"\n      >\n        {{ title }}\n      </span>\n\n      <span\n        [ngClass]=\"[\n          'rounded-[3px] size-[22px] inline-flex justify-center items-center transition-opacity duration-300 ease-in-out',\n          color,\n          !subSidebarIsOpen && title ? 'group-hover:opacity-60' : '',\n          disableMainMenus ? 'cursor-not-allowed opacity-60' : ''\n        ]\"\n      >\n        <ds-icon *ngIf=\"icon\" [id]=\"icon\" class=\"shrink-0 size-4\"></ds-icon>\n      </span>\n    </li>\n  </a>\n</ng-template>\n"
            }] }
];
DsMenuItemComponent.propDecorators = {
    subSidebarIsOpen: [{ type: Input }],
    subMenuData: [{ type: Input }],
    title: [{ type: Input }],
    icon: [{ type: Input }],
    color: [{ type: Input }],
    menus: [{ type: Input }],
    isFirst: [{ type: Input }],
    disableMainMenus: [{ type: Input }],
    href: [{ type: Input }],
    onClick: [{ type: Output }]
};

// ds-menu-list.component.ts
/**
 * @ignore
 */
class DsMenuListComponent {
    constructor(router) {
        this.router = router;
        this.data = [];
        this.currentURL = '/';
        this.openMap = new WeakMap();
    }
    toggle(item) {
        const isOpen = this.openMap.get(item);
        this.openMap.set(item, !isOpen);
    }
    isOpen(item) {
        return this.openMap.get(item) ? true : false;
    }
    hasChildren(item) {
        return Array.isArray(item.items) && item.items.length > 0;
    }
    ngOnInit() {
        this.currentURL = this.router.url;
        console.log('datadatadata', this.data);
    }
}
DsMenuListComponent.decorators = [
    { type: Component, args: [{
                selector: 'ds-menu-list',
                template: "<!-- ds-menu-list.component.html -->\n<ul class=\"menu-wrapper w-full max-w-[280px] mt-4\">\n  <ng-container *ngFor=\"let item of data\">\n    <li\n      class=\"relative after:absolute after:top-[30px] after:bottom-0 after:left-[6px] after:w-px after:h-[calc(100%-50px)] after:bg-white\">\n      <ng-container *ngIf=\"hasChildren(item); else linkLevel1\">\n        <div tabindex=\"0\" role=\"button\" class=\"flex w-full justify-between items-center\" (click)=\"toggle(item)\">\n          <div class=\"flex gap-2 items-center\">\n            <ds-icon [id]=\"item.icon\" class=\"size-4\"></ds-icon>\n            <span class=\"text-sm\">{{ item.title }}</span>\n          </div>\n          <ds-icon id=\"arrow-down\" class=\"size-3 transition-transform duration-300\"\n            [ngClass]=\"{ 'rotate-180': isOpen(item) }\">\n          </ds-icon>\n        </div>\n\n        <ul *ngIf=\"isOpen(item)\">\n          <ng-container *ngFor=\"let subItem of item.items\">\n            <li\n              class=\"relative before:absolute before:-left-[22px] before:border-white before:rounded-bl-md before:border-l before:border-b before:border-r-transparent before:border-t-transparent before:-top-[16px] before:content-[''] before:w-4 before:h-[26.5px] font-light\">\n              <ng-container *ngIf=\"hasChildren(subItem); else linkLevel2\">\n                <div tabindex=\"0\" role=\"button\" class=\"flex w-full justify-between items-center pl-0.5\"\n                  (click)=\"toggle(subItem)\">\n                  <div class=\"flex gap-2 items-center\">\n                    <ds-icon [id]=\"subItem.icon\" class=\"size-4\"></ds-icon>\n                    <span class=\"text-sm\">{{ subItem.title }}</span>\n                  </div>\n                  <ds-icon id=\"arrow-down\" class=\"size-3 transition-transform duration-300\"\n                    [ngClass]=\"{ 'rotate-180': isOpen(subItem) }\"></ds-icon>\n                </div>\n                <ul *ngIf=\"isOpen(subItem)\" class=\"pl-4\">\n                  <li *ngFor=\"let subSub of subItem.items\">\n                    <a class=\"flex relative items-center gap-2 before:absolute before:content-[''] before:-left-4 before:top-1/2 before:-translate-y-1/2 before:size-1.5 before:rounded-full hover:before:bg-white before:transition-colors before:duration-300 before:ease-in-out\"\n                      [ngClass]=\"[\n                        currentURL === subSub.href\n                          ? 'before:bg-white'\n                          : 'before:bg-transparent'\n                      ]\" [href]=\"subSub.href\">\n                      <span class=\"text-sm\">{{ subSub.title }} </span>\n                      <span *ngIf=\"subSub.isNew\"\n                        class=\"absolute top-1/2 -translate-y-1/2 -left-10 text-neutral-900 inline-flex py-0.5 px-1.5 rounded-full text-[0.625rem] leading-[12px] font-bold bg-amber-400 z-[10]\">New</span>\n                    </a>\n                  </li>\n                </ul>\n              </ng-container>\n              <ng-template #linkLevel2>\n                <a class=\"pl-0.5 pr-2 relative flex items-center gap-2 after:rounded-md after:z-[1] before:z-[3] after:absolute after:p-2 after:-inset-1 after:w-full after:content-[''] before:absolute before:content-[''] before:-left-1 before:top-1/2 before:-translate-y-1/2 before:w-[3px] before:h-3/4 before:rounded-r-full hover:before:bg-primary-500 hover:after:bg-green-700 before:transition-colors before:duration-300 before:ease-in-out after:transition-colors after:duration-300 after:ease-in-out\"\n                  [href]=\"subItem.href\" [ngClass]=\"[\n                    currentURL === subItem.href\n                      ? 'before:bg-primary-500 after:bg-[#323334]'\n                      : 'before:bg-transparent after:bg-transparent'\n                  ]\">\n                  <ds-icon [id]=\"subItem.icon\" class=\"size-4 relative z-[2]\"></ds-icon>\n                  <span class=\"text-sm pr-2 relative z-[2]\">{{\n                    subItem.title\n                    }}</span>\n\n\n                  <span *ngIf=\"subItem.isNew\"\n                    class=\"absolute top-1/2 -translate-y-1/2 right-1.5 text-neutral-900 inline-flex py-0.5 px-1.5 rounded-full text-[0.625rem] leading-[12px] font-bold bg-amber-400 z-[10]\">New</span>\n                </a>\n              </ng-template>\n            </li>\n          </ng-container>\n        </ul>\n      </ng-container>\n      <ng-template #linkLevel1>\n        <a class=\"relative flex items-center gap-2\" [href]=\"item.href\">\n          <ds-icon [id]=\"item.icon\" class=\"size-4\"></ds-icon>\n          <span class=\"text-sm\">{{ item.title }}</span>\n          <span *ngIf=\"item.isNew\"\n            class=\"absolute top-1/2 -translate-y-1/2 right-0 text-neutral-900 inline-flex py-0.5 px-1.5 rounded-full text-[0.625rem] leading-[12px] font-bold bg-amber-400\">New</span>\n        </a>\n      </ng-template>\n    </li>\n  </ng-container>\n</ul>"
            }] }
];
/** @nocollapse */
DsMenuListComponent.ctorParameters = () => [
    { type: Router }
];
DsMenuListComponent.propDecorators = {
    data: [{ type: Input }]
};

// ds-sidebar.component.ts
/**
 * SidebarComponent
 *
 * Live demo:
 * <example-url>/demo/ds-sidebar.component.html</example-url>
 */
class DsSidebarComponent {
    constructor() {
        this.className = '';
        this.profileMenus = [];
        this.mainMenus = [];
        this.disableMainMenus = false;
        this.disableBottomMenus = false;
        this.sizes = [];
        this.defaultCap = { name: 'L', size: 18 };
        this.logo = '/assets/logo-mybusiness.svg';
        this.miniLogo = '/assets/mini-logo.svg';
        this.language = {
            src: '/assets/france-flag.svg',
            alt: 'Français',
        };
        this.onThemeChange = new EventEmitter();
        this.subSidebarIsOpen = false;
        this.callingOnClick = new EventEmitter();
        this.reclamationOnClick = new EventEmitter();
        this.languageOnClick = new EventEmitter();
        this.settingsOnClick = new EventEmitter();
        this.onOpenSidebar = new EventEmitter();
        this.openMainMenuIndex = -1;
        this.subMenuData = { title: '', items: [] };
    }
    _onThemeChange(theme) {
        console.log('theme sidebar', theme);
        this.onThemeChange.emit(theme);
    }
    openSubSidebar(menus, idx) {
        if (menus) {
            this.subSidebarIsOpen = true;
            document.body.classList.add('main-menu-open');
            this.subMenuData = menus;
            this.openMainMenuIndex = this.openMainMenuIndex === idx ? -1 : idx;
            // Emit the event to notify the parent component
            this.onOpenSidebar.emit({
                subMenuData: menus,
                open: true,
                openMainMenuIndex: this.openMainMenuIndex === idx ? -1 : idx,
            });
        }
    }
    closeSubSidebar() {
        this.subSidebarIsOpen = false;
        document.body.classList.remove('main-menu-open');
        this.subMenuData = { title: '', items: [] };
        //Emiit the event to notify the parent component
        this.onOpenSidebar.emit({
            subMenuData: { title: '', items: [] },
            openMainMenuIndex: this.openMainMenuIndex,
            open: false,
        });
    }
    toggleMainMenu(idx) {
        this.openMainMenuIndex = this.openMainMenuIndex === idx ? -1 : idx;
        this.subMenuData = this.mainMenus[idx].menus;
        //Emiit the event to notify the parent component
        this.onOpenSidebar.emit({
            subMenuData: this.mainMenus[idx].menus,
            openMainMenuIndex: this.openMainMenuIndex === idx ? -1 : idx,
            open: this.subSidebarIsOpen,
        });
    }
}
DsSidebarComponent.decorators = [
    { type: Component, args: [{
                selector: 'ds-sidebar',
                template: "<!-- ds-sidebar.component.html -->\n<aside\n  id=\"ds-sidebar\"\n  class=\"sticky left-0 top-0 text-white h-screen shrink-0 z-[9999]\"\n  [ngClass]=\"className\"\n>\n  <div class=\"px-4 py-6 flex justify-between items-center\">\n    <img\n      *ngIf=\"!subSidebarIsOpen\"\n      [src]=\"miniLogo\"\n      alt=\"mini logo svg\"\n      class=\"w-5 h-auto object-cover\"\n    />\n\n    <img\n      *ngIf=\"subSidebarIsOpen\"\n      [src]=\"logo\"\n      alt=\"mybusiness logo svg\"\n      class=\"w-[140px] h-auto\"\n    />\n\n    <button *ngIf=\"subSidebarIsOpen\" (click)=\"closeSubSidebar()\">\n      <ds-icon id=\"sidebar-right\" class=\"size-5\"></ds-icon>\n    </button>\n  </div>\n\n  <div class=\"flex items-start justify-start w-max h-[calc(100%-64px)]\">\n    <div class=\"shrink-0 flex flex-col h-full justify-between items-center\">\n      <div>\n        <hr class=\"w-1/2 border-[#355A57] mx-auto\" />\n        <ul class=\"flex flex-col py-3.5\">\n          <ds-menu-item\n            *ngFor=\"let item of mainMenus; let i = index\"\n            [disableMainMenus]=\"disableMainMenus\"\n            [isFirst]=\"i === 0\"\n            [subSidebarIsOpen]=\"subSidebarIsOpen\"\n            [subMenuData]=\"subMenuData\"\n            [title]=\"item.title\"\n            [icon]=\"item.icon\"\n            [color]=\"item.color\"\n            [menus]=\"item.menus\"\n            [href]=\"item.href\"\n            (onClick)=\"openSubSidebar(item.menus, i)\"\n          ></ds-menu-item>\n        </ul>\n      </div>\n\n      <div class=\"w-full\">\n        <ds-bottom-menus\n        [disableBottomMenus]=\"disableBottomMenus\"\n        (onThemeChange)=\"_onThemeChange($event)\"\n        [sizes]=\"sizes\"\n        [defaultCap]=\"defaultCap\"\n        [language]=\"language\"\n        (callingOnClick)=\"callingOnClick.emit($event)\"\n        (reclamationOnClick)=\"reclamationOnClick.emit($event)\"\n        (languageOnClick)=\"languageOnClick.emit($event)\"\n        (settingsOnClick)=\"settingsOnClick.emit($event)\"\n        [profileMenus]=\"profileMenus\"\n      ></ds-bottom-menus>\n      </div>\n \n      \n    </div>\n\n    <div\n      class=\"space-y-5 bg-level-2 rounded-l-lg transition-all duration-300 ease-in-out overflow-y-auto\"\n      [ngClass]=\"{\n        'min-w-[260px] w-auto py-5 px-3.5 opacity-100 h-[calc(100%-14px)]':\n          subSidebarIsOpen && subMenuData?.items?.length > 0,\n        'w-0 p-0 opacity-0 h-[calc(100%-64px-14px)]':\n          !subSidebarIsOpen || !subMenuData?.items?.length\n      }\"\n    >\n      <div class=\"flex flex-col\">\n        <div\n          *ngFor=\"let item of mainMenus; let idx = index\"\n          class=\"pt-[9px] pb-4 w-full\"\n        >\n          <a\n            *ngIf=\"!item.menus\"\n            [href]=\"item.href\"\n            class=\"flex justify-between items-center w-full\"\n          >\n            <h4 class=\"text-[0.875rem] leading-[16px] font-bold\">\n              {{ item?.title }}\n            </h4>\n          </a>\n          <button\n            *ngIf=\"item.menus\"\n            class=\"flex justify-between items-center w-full\"\n            (click)=\"toggleMainMenu(idx)\"\n          >\n            <h4 class=\"text-[0.875rem] leading-[16px] font-bold\">\n              {{ item?.title }}\n            </h4>\n\n            <ds-icon id=\"arrow-down\" class=\"shrink-0 size-3\"></ds-icon>\n          </button>\n          <ds-menu-list\n            *ngIf=\"item.menus && openMainMenuIndex === idx\"\n            [data]=\"item.menus.items\"\n          ></ds-menu-list>\n        </div>\n      </div>\n    </div>\n  </div>\n</aside>\n"
            }] }
];
DsSidebarComponent.propDecorators = {
    className: [{ type: Input }],
    profileMenus: [{ type: Input }],
    mainMenus: [{ type: Input }],
    disableMainMenus: [{ type: Input }],
    disableBottomMenus: [{ type: Input }],
    sizes: [{ type: Input }],
    defaultCap: [{ type: Input }],
    logo: [{ type: Input }],
    miniLogo: [{ type: Input }],
    language: [{ type: Input }],
    onThemeChange: [{ type: Output }],
    subSidebarIsOpen: [{ type: Input }],
    callingOnClick: [{ type: Output }],
    reclamationOnClick: [{ type: Output }],
    languageOnClick: [{ type: Output }],
    settingsOnClick: [{ type: Output }],
    onOpenSidebar: [{ type: Output }],
    subMenuData: [{ type: Input }]
};

const checkbox = {
    default: {
        wrapper: 'flex gap-x-2 items-center',
        checkbox: {
            base: 'relative flex h-4 w-4 items-center justify-center rounded shrink-0',
            enabled: {
                checked: 'border !border-primary-500 bg-red-50 text-red-500',
                unchecked: 'bg-card-level-2 border !border-neutral-300 hover:bg-red-50 hover:border-red-500 focus-within:border-red-500',
            },
            disabled: {
                checked: 'bg-neutral-100 border !border-neutral-200 text-gray-400 cursor-not-allowed',
                unchecked: 'bg-neutral-100 border !border-neutral-200 text-neutral-400 cursor-not-allowed',
            },
            error: 'border-error-500',
            label: {
                base: 'text-neutral-900',
                checked: 'dark:text-primary/90 text-primary',
                disabled: 'dark:text-neutral-500 text-neutral-400',
            },
        },
        errorMessage: 'text-sm text-red-500',
    },
    autocomplete: {
        wrapper: 'flex gap-x-2 items-center',
        checkbox: {
            base: 'relative flex size-4 items-center justify-center rounded shrink-0',
            enabled: {
                checked: 'border border-red-500 bg-red-50 text-red-500',
                unchecked: 'bg-neutral-50 border border-neutral-200 hover:bg-red-50 hover:border-red-500 focus-within:border-red-500',
            },
            disabled: {
                checked: 'bg-gray-100 border border-gray-300 text-gray-400 cursor-not-allowed',
                unchecked: 'bg-gray-100 border border-gray-300 text-gray-400 cursor-not-allowed',
            },
            error: 'border-error-500',
            label: {
                base: 'text-sm font-medium text-neutral-500 inline-block',
                checked: 'dark:text-primary/90 text-primary',
                disabled: 'dark:text-neutral-500 text-neutral-400',
            },
        },
        errorMessage: 'text-sm text-red-500',
    },
};

/**
 * CheckboxComponent
 *
 * Live demo:
 * <example-url>/demo/ds-checkbox.component.html</example-url>
 */
class DsCheckboxComponent {
    constructor() {
        this.variant = 'default';
        this.checked = false;
        this.disabled = false;
        this.hasError = false;
        this.isIndeterminate = false;
        this.change = () => { };
        this.checkbox = checkbox;
    }
    get wrapperClass() {
        return `${checkbox[this.variant].wrapper} ${this.className || ''}`;
    }
    get checkboxClass() {
        const variantStyles = checkbox[this.variant].checkbox;
        if (this.disabled) {
            return `${variantStyles.base} ${this.checked
                ? variantStyles.disabled.checked
                : variantStyles.disabled.unchecked} ${this.hasError ? variantStyles.error : ''}`;
        }
        else {
            return `${variantStyles.base} ${this.checked
                ? variantStyles.enabled.checked
                : variantStyles.enabled.unchecked} ${this.hasError ? variantStyles.error : ''}`;
        }
    }
    get labelClass() {
        const labelStyles = checkbox[this.variant].checkbox.label;
        if (this.disabled) {
            return `${labelStyles.base} ${labelStyles.disabled}`;
        }
        else if (this.checked) {
            return `${labelStyles.base} ${labelStyles.checked}`;
        }
        else {
            return `${labelStyles.base}`;
        }
    }
}
DsCheckboxComponent.decorators = [
    { type: Component, args: [{
                selector: 'ds-checkbox',
                template: "<label id=\"ds-checkbox\" class=\"cursor-pointer\">\n  <div [ngClass]=\"wrapperClass\">\n    <div [ngClass]=\"checkboxClass + 'relative overflow-hidden'\">\n      <input\n        type=\"checkbox\"\n        class=\"absolute size-0 opacity-0 flex justify-center items-center\"\n        [value]=\"value\"\n        [name]=\"name\"\n        [checked]=\"checked\"\n        [disabled]=\"disabled\"\n        (change)=\"change()\"\n      />\n      <!-- checkbox[variant]?.checkbox?.icon + -->\n      <!-- *ngIf=\"checked\" -->\n      <ds-icon\n        [id]=\"[!isIndeterminate ? 'check' : 'minus']\"\n        [ngClass]=\"[\n          'transition-opacity duration-200 ease-in-out absolute size-4',\n          checked ? 'opacity-100' : 'opacity-0',\n          disabled ? 'text-neutral-400' : 'text-red-500'\n        ]\"\n      ></ds-icon>\n      <!-- <span\n        class=\"bg-red-600 rounded-full size-2 absolute top-1/2 left-1/2 -translate-x-1/2 translate-y-1/2\"\n      ></span> -->\n    </div>\n\n    <ng-container *ngIf=\"label\">\n      <span [ngClass]=\"labelClass\">\n        {{ label }}\n      </span>\n    </ng-container>\n  </div>\n\n  <ng-container *ngIf=\"hasError && errorMessage\">\n    <span [ngClass]=\"checkbox[variant].errorMessage\">{{ errorMessage }}</span>\n  </ng-container>\n</label>\n"
            }] }
];
DsCheckboxComponent.propDecorators = {
    variant: [{ type: Input }],
    name: [{ type: Input }],
    checked: [{ type: Input }],
    disabled: [{ type: Input }],
    hasError: [{ type: Input }],
    value: [{ type: Input }],
    label: [{ type: Input }],
    errorMessage: [{ type: Input }],
    className: [{ type: Input }],
    isIndeterminate: [{ type: Input }],
    change: [{ type: Input }]
};

const input = {
    default: {
        container: 'relative w-full',
        wrapper: {
            base: 'border relative bg-level-4 h-[40px] flex flex-grow items-center gap-3 px-3 w-full rounded',
            enabled: 'border-stroke-1 hover:border-primary-500 focus-within:!border-primary-500',
            disabled: 'border-neutral-100 bg-neutral-100 [&_input]:!text-neutral-500 cursor-not-allowed ',
        },
        label: 'inline-block text-neutral-900 font-normal text-[0.75rem]/[0.875rem] mb-0',
        input: 'text-xs font-bold w-full text-gray-800 dark:text-white bg-transparent appearance-none dark:placeholder-gray-300 placeholder-gray-400 placeholder-text-sm placeholder:font-medium outline-none border-none focus:ring-0 p-0',
        prefix: 'mr-1 text-gray-500',
        sufix: 'ml-1 text-gray-500',
        errorMessage: 'text-error-500 text-xs mt-1',
        hasError: '!border-red-500 [&_input]:!text-red-500 [&_input]:placeholder:!text-red-500/50 hover:border-red-600 focus-within:!border-red-400',
        description: 'text-xs text-gray-500 mt-1',
    },
    search: {
        container: 'relative w-full',
        wrapper: {
            base: 'border relative bg-level-3 h-[40px] flex flex-grow items-center gap-3 px-3 w-full rounded',
            enabled: 'border-stroke-1 hover:border-primary-500 focus-within:!border-primary-500',
            disabled: 'border-stroke-1 opacity-40',
        },
        label: 'inline-block text-sm leading-[16px] font-bold text-neutral-900 mb-2',
        input: 'text-sm font-bold w-full text-gray-800 dark:text-white bg-transparent appearance-none dark:placeholder-gray-300 placeholder-gray-400 placeholder-text-sm placeholder:font-medium outline-none border-none focus:ring-0 p-0',
        prefix: 'mr-1 text-gray-500',
        sufix: 'ml-1 text-gray-500',
        errorMessage: 'text-error-500 text-xs mt-1',
        hasError: '!border-red-500 [&_input]:!text-red-500 [&_input]:placeholder:!text-red-500/50 hover:border-red-600 focus-within:!border-red-400',
        description: 'text-xs text-gray-500 mt-1',
    },
};

/**
 * InputComponent
 *
 * Live demo:
 * <example-url>/demo/ds-input.component.html</example-url>
 */
class DsInputComponent {
    constructor(host, renderer) {
        this.host = host;
        this.renderer = renderer;
        this.variant = 'default';
        this.display = 'block';
        this.type = 'text';
        this.hasError = false;
        this.disabled = false;
        this.required = false;
        this.className = '';
        this.inputClassName = '';
        this.password = false;
        this.autoComplete = 'on';
        this.passwordVisible = false;
        this.onClick = new EventEmitter();
        this.onInput = new EventEmitter();
        this.onChange = new EventEmitter();
        this.onFocus = new EventEmitter();
        this.onBlur = new EventEmitter();
        this.onKeydown = new EventEmitter();
        this.onKeyup = new EventEmitter();
        this.onEnter = new EventEmitter();
        this.onEscape = new EventEmitter();
        this.onPaste = new EventEmitter();
        this.onSelect = new EventEmitter();
        this.input = input;
        this.hasProjectedPrefix = false;
        this.hasProjectedSuffix = false;
        // these will be filled in by Angular
        this._onChange = () => { };
        this._onTouched = () => { };
    }
    // -----------------------------------------------------
    // ControlValueAccessor methods
    // -----------------------------------------------------
    writeValue(value) {
        this.value = value;
    }
    registerOnChange(fn) {
        this._onChange = fn;
    }
    registerOnTouched(fn) {
        this._onTouched = fn;
    }
    setDisabledState(isDisabled) {
        this.disabled = isDisabled;
    }
    // -----------------------------------------------------
    // Hook into your native <input> events
    // -----------------------------------------------------
    onNativeInput(event) {
        const v = event.target.value;
        this.value = v;
        this._onChange(v); // notify Angular forms
        this.onInput.emit(event); // still emit your public output
    }
    onNativeBlur(event) {
        this._onTouched();
        this.onBlur.emit(event);
    }
    togglePassword() {
        this.passwordVisible = !this.passwordVisible;
    }
    ngAfterViewInit() {
        const hostAttrs = this.host.nativeElement.attributes;
        for (let i = 0; i < hostAttrs.length; i++) {
            const { name, value } = hostAttrs[i];
            // skip Angular‐internal and any @Inputs you’ve explicitly declared
            if (name === 'class' ||
                name.startsWith('_ng') ||
                this.hasOwnProperty(name))
                continue;
            this.renderer.setAttribute(this.inner.nativeElement, name, value);
        }
    }
}
DsInputComponent.decorators = [
    { type: Component, args: [{
                selector: 'ds-input',
                template: "<div id=\"ds-input\" [ngClass]=\"[\n    'relative w-full',\n    input[variant].container,\n    display === 'inline' ? 'flex flex-row items-center gap-2' : '',\n    className\n  ]\">\n  <ng-container *ngIf=\"type !== 'hidden' && label\">\n    <div class=\"flex items-center gap-2 mb-2\">\n      <label [for]=\"id\" [ngClass]=\"[\n          'shrink-0',\n          input[variant].label || '',\n          hasError && errorMessage ? '!text-error-500' : '',\n          display === 'inline' ? '!mb-0' : '',\n          display === 'inline' && (description || (hasError && errorMessage))\n            ? 'self-start mt-2.5'\n            : ''\n        ]\">\n        {{ label }}\n        <span *ngIf=\"required\" class=\"text-red-500\">*</span>\n      </label>\n      <ds-tooltip *ngIf=\"tooltip\" [content]=\"tooltip\" position=\"right\">\n        <ds-icon id=\"info-circle\" class=\"size-4\"></ds-icon>\n      </ds-tooltip>\n    </div>\n  </ng-container>\n  <div class=\"w-full\">\n    <div [ngClass]=\"[\n        input[variant].wrapper.base,\n        disabled\n          ? input[variant].wrapper.disabled\n          : input[variant].wrapper.enabled,\n        type === 'hidden' ? 'border-none' : '',\n        hasError ? input[variant].hasError : ''\n      ]\">\n      <ng-content select=\"[prefix]\"></ng-content>\n\n      <div *ngIf=\"prefix && !hasProjectedPrefix\" [ngClass]=\"input[variant].prefix\">\n        {{ prefix }}\n      </div>\n\n\n      <input #inner [type]=\"password ? (passwordVisible ? type : 'password') : type\" [id]=\"id\" [attr.name]=\"name\"\n        [placeholder]=\"placeholder || ''\" [disabled]=\"disabled\" [value]=\"value\" (click)=\"onClick.emit($event)\"\n        (input)=\"onNativeInput($event)\" (change)=\"onChange.emit($event)\" (focus)=\"onFocus.emit($event)\"\n        (blur)=\"onNativeBlur($event)\" (keydown)=\"onKeydown.emit($event)\" (keyup)=\"onKeyup.emit($event)\"\n        (keydown.enter)=\"onEnter.emit($event)\" (keydown.escape)=\"onEscape.emit($event)\" (paste)=\"onPaste.emit($event)\"\n        (select)=\"onSelect.emit($event)\" [autocomplete]=\"autoComplete\" [ngClass]=\"[\n          input[variant].input,\n          disabled ? 'cursor-not-allowed bg-gray-50' : '',\n          type === 'number' ? '[appearance:textfield]' : '',\n          hasError ? '!text-red-500' : '',\n          inputClassName\n        ]\" />\n\n      <ds-icon [id]=\"passwordVisible ? 'eye' : 'eye-slash'\" class=\"size-4\" *ngIf=\"password\"\n        (click)=\"togglePassword()\"></ds-icon>\n      <div *ngIf=\"suffix && !hasProjectedSuffix && !password\" [ngClass]=\"input[variant].sufix\">\n        {{ suffix }}\n      </div>\n\n      <ng-content select=\"[suffix]\"></ng-content>\n    </div>\n    <div *ngIf=\"description\" [ngClass]=\"input[variant].description\">\n      {{ description }}\n    </div>\n\n    <div *ngIf=\"hasError && errorMessage\" [ngClass]=\"input[variant].errorMessage\">\n      {{ errorMessage }}\n    </div>\n  </div>\n</div>",
                providers: [
                    {
                        provide: NG_VALUE_ACCESSOR,
                        useExisting: forwardRef(() => DsInputComponent),
                        multi: true,
                    },
                ]
            }] }
];
/** @nocollapse */
DsInputComponent.ctorParameters = () => [
    { type: ElementRef },
    { type: Renderer2 }
];
DsInputComponent.propDecorators = {
    id: [{ type: Input }],
    name: [{ type: Input }],
    label: [{ type: Input }],
    variant: [{ type: Input }],
    display: [{ type: Input }],
    placeholder: [{ type: Input }],
    prefix: [{ type: Input }],
    suffix: [{ type: Input }],
    type: [{ type: Input }],
    hasError: [{ type: Input }],
    errorMessage: [{ type: Input }],
    description: [{ type: Input }],
    disabled: [{ type: Input }],
    required: [{ type: Input }],
    value: [{ type: Input }],
    className: [{ type: Input }],
    inputClassName: [{ type: Input }],
    tooltip: [{ type: Input }],
    password: [{ type: Input }],
    autoComplete: [{ type: Input }],
    onClick: [{ type: Output }],
    onInput: [{ type: Output }],
    onChange: [{ type: Output }],
    onFocus: [{ type: Output }],
    onBlur: [{ type: Output }],
    onKeydown: [{ type: Output }],
    onKeyup: [{ type: Output }],
    onEnter: [{ type: Output }],
    onEscape: [{ type: Output }],
    onPaste: [{ type: Output }],
    onSelect: [{ type: Output }],
    inner: [{ type: ViewChild, args: ['inner', { read: ElementRef },] }]
};

const radio = {
    default: {
        wrapper: 'flex gap-x-2 items-center',
        base: 'text-neutral-900 relative flex h-4 w-4 items-center justify-center rounded-full border cursor-pointer',
        enabled: {
            checked: 'border-red-500 bg-red-50',
            unchecked: 'border-neutral-300 bg-transparent dark:border-neutral-500',
        },
        disabled: {
            checked: 'cursor-not-allowed border-red-500 opacity-50 bg-red-500',
            unchecked: 'cursor-not-allowed border-neutral-300 opacity-50 bg-neutral-300',
        },
        icon: {
            base: 'h-1.5 w-1.5 rounded-full',
            enabled: 'bg-red-500',
            disabled: 'opacity-50 cursor-not-allowed',
        },
        error: 'border-error-500',
        label: {
            base: 'text-[0.875rem]/[1rem] font-normal',
            disabled: 'text-neutral-900 cursor-not-allowed opacity-50',
            unchecked: 'text-black dark:text-white cursor-pointer',
            checked: 'font-semibold cursor-pointer',
            error: 'text-error-500',
        },
    },
};

/**
 * RadioComponent
 *
 * Live demo:
 * <example-url>/demo/ds-radio.component.html</example-url>
 */
class DsRadioComponent {
    constructor() {
        this.variant = 'default';
        this.disabled = false;
        this.hasError = false;
        this.modelValueChange = new EventEmitter();
        this.radio = radio;
    }
    get checked() {
        return this.modelValue === this.value;
    }
    get wrapperClass() {
        return `${radio[this.variant].wrapper} ${this.className || ''}`;
    }
    get radioClass() {
        const variantStyles = radio[this.variant];
        if (this.disabled) {
            return `${variantStyles.base} ${this.checked
                ? variantStyles.disabled.checked
                : variantStyles.disabled.unchecked} ${this.hasError ? variantStyles.error : ''}`;
        }
        else {
            return `${variantStyles.base} ${this.checked
                ? variantStyles.enabled.checked
                : variantStyles.enabled.unchecked} ${this.hasError ? variantStyles.error : ''}`;
        }
    }
    get labelClass() {
        const labelStyles = radio[this.variant].label;
        if (this.disabled) {
            return labelStyles.disabled;
        }
        else if (this.hasError) {
            return labelStyles.error;
        }
        else if (this.checked) {
            return labelStyles.checked;
        }
        else {
            return labelStyles.unchecked;
        }
    }
    onInputChange() {
        if (!this.disabled) {
            this.modelValueChange.emit(this.value || '');
        }
    }
}
DsRadioComponent.decorators = [
    { type: Component, args: [{
                selector: 'ds-radio',
                template: "<label id=\"ds-radio\" class=\"cursor-pointer inline-block\">\n  <div [ngClass]=\"wrapperClass\">\n    <div [ngClass]=\"radioClass\">\n      <input\n        type=\"radio\"\n        class=\"absolute size-0 opacity-0\"\n        [value]=\"value\"\n        [checked]=\"modelValue === value\"\n        (change)=\"onInputChange()\"\n        [name]=\"name\"\n        [disabled]=\"disabled\"\n      />\n      <div\n        [ngClass]=\"[\n          checked ? 'opacity-100' : 'opacity-0',\n          radio[variant]?.icon?.base,\n          disabled\n            ? radio[variant]?.icon?.disabled\n            : radio[variant]?.icon?.enabled\n        ]\"\n      ></div>\n    </div>\n\n    <span *ngIf=\"label\" [ngClass]=\"[radio[variant].label.base, labelClass]\">\n      {{ label }}\n    </span>\n  </div>\n\n  <ng-container *ngIf=\"hasError && errorMessage\">\n    <span class=\"text-error-500 text-[0.875rem]/normal\">{{ errorMessage }}</span>\n  </ng-container>\n</label>\n"
            }] }
];
DsRadioComponent.propDecorators = {
    variant: [{ type: Input }],
    name: [{ type: Input }],
    value: [{ type: Input }],
    disabled: [{ type: Input }],
    hasError: [{ type: Input }],
    label: [{ type: Input }],
    errorMessage: [{ type: Input }],
    className: [{ type: Input }],
    modelValue: [{ type: Input }],
    modelValueChange: [{ type: Output }]
};

// a simple map of Tailwind classes per “variant”
const RangeSelectorTheme = {
    default: {
        container: 'relative w-full select-none touch-none',
        track: 'h-2 bg-neutral-50 rounded-full',
        range: 'h-2 bg-red-500 rounded-full',
        thumb: 'w-6 h-6 bg-white rounded-full border border-red-600 shadow',
    },
};

class DsRangeComponent {
    constructor() {
        this.rangeType = 'single';
        this.min = 0;
        this.unit = '';
        this.max = 100;
        this.step = 1;
        // single‐thumb
        this.value = this.min;
        this.valueChange = new EventEmitter();
        // two‐thumb
        this.values = [this.min, this.max];
        this.valuesChange = new EventEmitter();
        this.variant = 'default';
        this.theme = RangeSelectorTheme;
        this.dragging = null;
        this.singleDragging = false;
        this.onPointerMove = (e) => {
            if (!this.dragging || !this.trackEl)
                return;
            const { left, width } = this.trackEl.nativeElement.getBoundingClientRect();
            const x = Math.min(Math.max(e.clientX - left, 0), width);
            const ratio = x / width;
            const raw = this.min + ratio * (this.max - this.min);
            this.setThumbValue(raw);
        };
        this.onPointerUp = () => {
            this.dragging = null;
            window.removeEventListener('pointermove', this.onPointerMove);
            window.removeEventListener('pointerup', this.onPointerUp);
            window.removeEventListener('pointercancel', this.onPointerUp);
        };
        this.onSinglePointerMove = (e) => {
            if (!this.singleDragging)
                return;
            const { left, width } = this.singleTrackEl.nativeElement.getBoundingClientRect();
            const x = Math.min(Math.max(e.clientX - left, 0), width);
            this.setSingleValueFromX(x, width);
        };
        this.onSinglePointerUp = () => {
            this.singleDragging = false;
            window.removeEventListener('pointermove', this.onSinglePointerMove);
            window.removeEventListener('pointerup', this.onSinglePointerUp);
        };
    }
    // Helpers to compute percentages
    get percentRange() {
        const [lo, hi] = this.values;
        const total = this.max - this.min;
        return {
            min: ((lo - this.min) / total) * 100,
            max: ((hi - this.min) / total) * 100,
        };
    }
    // Called on mousedown (pointerdown) on the track
    onRangePointerDown(e) {
        e.preventDefault();
        if (!this.trackEl)
            return;
        const { left, width } = this.trackEl.nativeElement.getBoundingClientRect();
        const clickX = Math.min(Math.max(e.clientX - left, 0), width);
        const ratio = clickX / width;
        const clickedValue = this.min + ratio * (this.max - this.min);
        // pick the nearest thumb
        const distLo = Math.abs(clickedValue - this.values[0]);
        const distHi = Math.abs(clickedValue - this.values[1]);
        this.dragging = distLo <= distHi ? 'min' : 'max';
        // immediately set the value at the click spot
        this.setThumbValue(clickedValue);
        // listen for moves and end
        window.addEventListener('pointermove', this.onPointerMove);
        window.addEventListener('pointerup', this.onPointerUp);
        window.addEventListener('pointercancel', this.onPointerUp);
    }
    setThumbValue(raw) {
        // snap to step
        const stepped = Math.round((raw - this.min) / this.step) * this.step + this.min;
        let [lo, hi] = this.values;
        if (this.dragging === 'min') {
            lo = Math.min(Math.max(stepped, this.min), hi);
        }
        else {
            hi = Math.max(Math.min(stepped, this.max), lo);
        }
        this.values = [lo, hi];
        this.valuesChange.emit(this.values);
    }
    // clean up if component is destroyed mid-drag
    ngOnDestroy() {
        this.onPointerUp();
    }
    /** percent position for single thumb */
    get percent() {
        return ((this.value - this.min) / (this.max - this.min)) * 100;
    }
    onSingleChange(e) {
        const v = +e.target.value;
        this.value = v;
        this.valueChange.emit(v);
    }
    onMinChange(e) {
        let v = +e.target.value;
        if (v > this.values[1])
            v = this.values[1];
        this.values = [v, this.values[1]];
        this.valuesChange.emit(this.values);
    }
    onMaxChange(e) {
        let v = +e.target.value;
        if (v < this.values[0])
            v = this.values[0];
        this.values = [this.values[0], v];
        this.valuesChange.emit(this.values);
    }
    // ───── SINGLE POINTER LOGIC ─────
    onSinglePointerDown(e) {
        e.preventDefault();
        const { left, width } = this.singleTrackEl.nativeElement.getBoundingClientRect();
        const x = Math.min(Math.max(e.clientX - left, 0), width);
        this.setSingleValueFromX(x, width);
        this.singleDragging = true;
        window.addEventListener('pointermove', this.onSinglePointerMove);
        window.addEventListener('pointerup', this.onSinglePointerUp);
    }
    setSingleValueFromX(x, width) {
        const ratio = x / width;
        const raw = this.min + ratio * (this.max - this.min);
        const stepped = Math.round((raw - this.min) / this.step) * this.step + this.min;
        const v = this.clamp(stepped);
        this.value = v;
        this.valueChange.emit(v);
    }
    // clamp helper
    clamp(v) {
        return Math.min(Math.max(v, this.min), this.max);
    }
}
DsRangeComponent.decorators = [
    { type: Component, args: [{
                selector: 'ds-range',
                template: "<div id=\"ds-range\" [ngClass]=\"theme[variant].container\">\n  <!-- single-thumb slider -->\n  <ng-container *ngIf=\"rangeType === 'single'\">\n    <div\n      #singleTrack\n      class=\"relative w-full h-6 select-none\"\n      (pointerdown)=\"onSinglePointerDown($event)\"\n    >\n      <!-- full track -->\n      <div [ngClass]=\"theme[variant].track\" class=\"absolute inset-0\"></div>\n\n      <!-- filled portion -->\n      <div\n        [ngClass]=\"theme[variant].range\"\n        class=\"absolute\"\n        [ngStyle]=\"{ 'width.%': percent }\"\n      ></div>\n\n      <!-- custom thumb -->\n      <div\n        [ngClass]=\"[theme[variant].thumb, value <= 0 ? 'ml-0' : '-ml-6']\"\n        class=\"group absolute -mt-2\"\n        [ngStyle]=\"{ 'left.%': percent }\"\n      >\n        <div\n          class=\"group-hover:opacity-100 opacity-0 font-medium transition-all duration-300 group-hover:translate-y-0 translate-y-1.5 ease-in-out pointer-events-none inline-flex justify-center items-center text-[0.875rem]/[1.25rem] absolute bottom-8 left-1/2 -translate-x-1/2 w-fit min-w-[42px] h-[34px] dark:bg-black bg-white rounded-lg shadow text-neutral-800 after:absolute after:content-[''] after:w-0 after:h-0 after:border-[6px] after:border-solid after:border-transparent dark:after:border-t-black after:border-t-white after:top-full after:left-1/2 after:-translate-x-1/2 text-center\"\n        >\n          <span class=\"px-1\">\n            {{ value }} {{ unit }}\n          </span>\n        </div>\n      </div>\n    </div>\n  </ng-container>\n\n  <!-- \u2026 your two-thumb markup stays as we last wrote it \u2026 -->\n\n  <!-- two-thumb (min/max) slider -->\n  <ng-container *ngIf=\"rangeType === 'range'\">\n    <div\n      #track\n      class=\"relative w-full h-6 select-none\"\n      (pointerdown)=\"onRangePointerDown($event)\"\n    >\n      <!-- full track -->\n      <div [ngClass]=\"theme[variant].track\" class=\"absolute inset-0\"></div>\n      <!-- filled range between thumbs -->\n      <div\n        [ngClass]=\"theme[variant].range\"\n        class=\"absolute\"\n        [ngStyle]=\"{\n          left: percentRange.min + '%',\n          width: percentRange.max - percentRange.min + '%'\n        }\"\n      ></div>\n\n      <!-- thumbs -->\n      <div\n        [ngClass]=\"[theme[variant].thumb]\"\n        class=\"absolute -mt-2 -mr-6 group\"\n        [ngStyle]=\"{ 'left.%': percentRange.min }\"\n      >\n        <div\n          class=\"group-hover:opacity-100 opacity-0 transition-all duration-300 group-hover:translate-y-0 translate-y-1.5 ease-in-out pointer-events-none inline-flex justify-center items-center text-[0.875rem]/[1.25rem] absolute bottom-8 left-1/2 -translate-x-1/2 w-fit min-w-[42px] h-[34px] dark:bg-black bg-white rounded-lg shadow font-medium text-neutral-800 after:absolute after:content-[''] after:w-0 after:h-0 after:border-[6px] after:border-solid after:border-transparent dark:after:border-t-black after:border-t-white after:top-full after:left-1/2 after:-translate-x-1/2 text-center\"\n        >\n          <span class=\"px-1\">\n            {{ values[0] }} {{ unit }}\n          </span>\n        </div>\n      </div>\n      <div\n        [ngClass]=\"[theme[variant].thumb]\"\n        class=\"group absolute -mt-2 -ml-6\"\n        [ngStyle]=\"{ 'left.%': percentRange.max }\"\n      >\n        <div\n          class=\"group-hover:opacity-100 opacity-0 font-medium transition-all duration-300 group-hover:translate-y-0 translate-y-1.5 ease-in-out pointer-events-none inline-flex justify-center items-center text-[0.875rem]/[1.25rem] absolute bottom-8 left-1/2 -translate-x-1/2 w-fit min-w-[42px] h-[34px] bg-white rounded-lg shadow text-neutral-800 after:absolute after:content-[''] after:w-0 after:h-0 after:border-[6px] after:border-solid after:border-transparent after:border-t-white after:top-full after:left-1/2 after:-translate-x-1/2 text-center\"\n        >\n          <span class=\"px-1\">\n            {{ values[1] }} {{ unit }}\n          </span>\n        </div>\n      </div>\n    </div>\n  </ng-container>\n</div>\n"
            }] }
];
DsRangeComponent.propDecorators = {
    rangeType: [{ type: Input }],
    min: [{ type: Input }],
    unit: [{ type: Input }],
    max: [{ type: Input }],
    step: [{ type: Input }],
    value: [{ type: Input }],
    valueChange: [{ type: Output }],
    values: [{ type: Input }],
    valuesChange: [{ type: Output }],
    variant: [{ type: Input }],
    trackEl: [{ type: ViewChild, args: ['track',] }],
    singleTrackEl: [{ type: ViewChild, args: ['singleTrack',] }]
};

const textarea = {
    default: {
        base: 'font-semibold text-neutral-900 text-[0.75rem]/[0.875rem] block relative w-full p-2 border border-neutral-50 focus:ring-0 focus:outline-0 hover:border-primary-500 focus:border-primary-500 rounded placeholder-gray-500 placeholder-text-[1rem]/[1.25rem]',
        label: 'inline-block text-neutral-900 font-normal text-[0.75rem]/[0.875rem] mb-0',
        counter: 'absolute bottom-2 right-2 text-[1rem]/[1.25rem]',
        resize: 'resize-none',
        description: 'text-[0.75rem]/[0.875rem] inline-block text-gray-500 mt-1',
        errorMessage: 'text-[0.75rem]/[0.875rem] inline-block text-error-500 mt-1',
        hasError: 'border border-error-400 hover:border-error-500 focus:border-error-500 focus-within:ring-error-500',
        disabled: 'bg-gray-50 cursor-not-allowed',
    },
};

/**
 * TextareaComponent
 *
 * Live demo:
 * <example-url>/demo/ds-textarea.component.html</example-url>
 */
class DsTextareaComponent {
    constructor() {
        this.variant = 'default';
        this.disabled = false;
        this.hasError = false;
        this.rows = 1;
        this.resize = true;
        this.required = false;
        this.value = '';
        this.valueChange = new EventEmitter();
        this.textarea = textarea;
    }
    ngOnChanges(changes) {
        // nothing needed now but structure kept for future extension
    }
    onTextareaChange(event) {
        const input = event.target;
        this.valueChange.emit(input.value);
    }
    get classes() {
        return [
            textarea[this.variant].base,
            this.disabled ? textarea[this.variant].disabled : '',
            this.hasError ? textarea[this.variant].hasError : '',
            this.resize ? '' : textarea[this.variant].resize,
        ].join(' ');
    }
}
DsTextareaComponent.decorators = [
    { type: Component, args: [{
                selector: 'ds-textarea',
                template: "<div id=\"ds-textarea\" class=\"relative w-full\">\n  <ng-container *ngIf=\"label\">\n    <div class=\"flex items-center gap-2 mb-2\">  \n      <label [ngClass]=\"textarea[variant].label\">\n        {{ label }}\n        <span *ngIf=\"required\" class=\"text-red-500\">*</span>\n      </label>\n      <ds-tooltip *ngIf=\"tooltip\" [content]=\"tooltip\" position=\"right\">\n        <ds-icon id=\"info-circle\" class=\"size-4\"></ds-icon>\n      </ds-tooltip>\n    </div>\n  </ng-container>\n\n  <textarea\n    [value]=\"value\"\n    [name]=\"name\"\n    [placeholder]=\"placeholder\"\n    [disabled]=\"disabled\"\n    [rows]=\"rows\"\n    [attr.maxlength]=\"maxLength\"\n    (input)=\"onTextareaChange($event)\"\n    [ngClass]=\"classes\"\n  ></textarea>\n\n  <ng-container *ngIf=\"hasError && errorMessage\">\n    <span [ngClass]=\"textarea[variant].errorMessage\">{{ errorMessage }}</span>\n  </ng-container>\n\n  <ng-container *ngIf=\"description\">\n    <span [ngClass]=\"textarea[variant].description\">{{ description }}</span>\n  </ng-container>\n</div>\n"
            }] }
];
DsTextareaComponent.propDecorators = {
    variant: [{ type: Input }],
    placeholder: [{ type: Input }],
    name: [{ type: Input }],
    disabled: [{ type: Input }],
    hasError: [{ type: Input }],
    errorMessage: [{ type: Input }],
    description: [{ type: Input }],
    rows: [{ type: Input }],
    maxLength: [{ type: Input }],
    resize: [{ type: Input }],
    label: [{ type: Input }],
    required: [{ type: Input }],
    tooltip: [{ type: Input }],
    value: [{ type: Input }],
    valueChange: [{ type: Output }]
};

const theme$c = {
    default: {
        element: {
            label: 'inline-block text-neutral-900 font-normal text-[0.75rem]/[0.875rem] mb-0',
            button: {
                select: 'relative cursor-default border text-[0.75rem]/[1.125rem] border-stroke-1 min-h-[40px] flex items-center gap-x-2 justify-between w-full px-3 py-2 rounded bg-level-3 placeholder:text-[0.75rem]/[1.125rem] focus:ring-0 focus:outline-0 focus:border-primary hover:border-primary focus:outline-0 text-left placeholder:text-gray-700',
                selected: 'flex items-center gap-2 overflow-hidden w-full relative',
                error: 'ring-1 ring-error-400 border-1 border-error-400 outline-1 border-1 border-error-400',
                iconeError: 'text-error-500',
                disabled: '!bg-neutral-100 !text-neutral-500 placeholder:!text-neutral-800 cursor-not-allowed hover:bg-transparent !border-neutral-100 hover:border-neutral-100',
                label: 'inline-block text-neutral-900 font-bold text-[0.75rem]/normal mb-0',
                placeholder: 'font-medium dark:text-white text-[0.75rem]/normal text-neutral-900 mr-2',
            },
            field: {
                activated: 'bg-gray-200 dark:bg-neutral-700',
            },
            icone: {
                arrow: 'text-heading absolute right-3 bottom-[11px] dark:text-white w-4 h-4',
                checked: 'text-primary-500 w-5 h-5',
            },
            options: {
                selectedfont: 'flex text-heading dark:text-white items-center justify-between w-full',
                container: 'absolute left-0 top-0 border border-neutral-100 bottom-0 p-1 mb-1 mt-1 min-w-32 max-h-60 w-fit min-w-full rounded-lg bg-level-3 py-1 text-[0.75rem]/[1rem] focus:outline-none border shadow-dropdown2 flex flex-col',
                element: 'w-full hover:bg-neutral-50 rounded cursor-default text-neutral-900 font-semibold select-none py-3 px-4',
                fontcolor: 'white',
                available: 'cursor-pointer',
                unavailable: 'cursor-not-allowed opacity-50 hover:bg-transparent',
            },
            error: 'text-error-500 mt-1 text-xs relative text-[0.875rem]/normal',
            description: 'text-gray-500 text-xs mt-1 relative text-[0.875rem]/normal',
        },
    },
    currency: {
        element: {
            label: 'inline-block text-neutral-900 font-normal text-[0.75rem]/[0.875rem] mb-0',
            button: {
                select: 'cursor-default  text-[0.75rem]/normal flex items-center justify-end gap-2 w-full px-0 py-1.5 rounded bg-transparent placeholder:text-[1rem]/normal focus:ring-0 focus:outline-0 focus:border-primary hover:border-primary focus:outline-0 text-left placeholder:text-gray-700',
                selected: 'flex items-center flex-row-reverse justify-between gap-2',
                error: 'ring-1 ring-error-400 border-1 border-error-400 outline-1 border-1 border-error-400',
                iconeError: 'text-error-500',
                disabled: '!opacity-50 !bg-neutral-100 !text-neutral-500 placeholder:text-neutral-800 cursor-not-allowed hover:bg-transparent !border-neutral-100 hover:border-neutral-100',
                label: 'inline-block text-neutral-900 font-normal text-[0.75rem]/[0.875rem] mb-0',
                placeholder: 'font-semibold dark:text-white text-[0.875rem]/normal mr-2',
            },
            field: {
                activated: 'bg-gray-200 dark:bg-neutral-700',
            },
            icone: {
                arrow: 'text-heading dark:text-white w-4 h-4',
                checked: 'text-primary-500 w-5 h-5',
            },
            options: {
                selectedfont: 'flex text-heading dark:text-white items-center justify-between w-full ',
                container: 'absolute top-0 border right-0 border-neutral-100 bottom-0 p-1 mb-1 mt-1 min-w-28 max-h-60 overflow-y-auto w-fit rounded-lg bg-level-3 py-1 text-[0.875rem]/[1rem] focus:outline-none border shadow-dropdown2',
                element: 'w-full hover:bg-neutral-50 rounded cursor-default text-neutral-900 font-semibold select-none py-1.5 px-2',
                fontcolor: 'white',
                available: 'cursor-pointer',
                unavailable: 'cursor-not-allowed opacity-50 hover:bg-transparent',
            },
            error: 'text-error-500 mt-1 relative text-[0.875rem]/normal',
            description: 'text-gray-500 text-xs mt-1 relative text-[0.875rem]/normal',
        },
    },
};

/**
 * SelectComponent
 *
 * Live demo:
 * <example-url>/demo/ds-select.component.html</example-url>
 */
class DsSelectComponent {
    constructor() {
        this.items = [];
        this.placeholder = 'Select an option';
        this.variant = 'default';
        this.disabled = false;
        this.hasError = false;
        this.pill = false;
        this.emptyLabel = 'No options';
        this.multiple = false;
        this.isLoading = false;
        this.value = null;
        this.autoComplete = false;
        this.debounceTime = 300; // Default debounce time in milliseconds
        this.required = false;
        this.allowClear = false;
        this.onSearch = new EventEmitter();
        this.valueChange = new EventEmitter();
        this.searchable = false;
        this.filteredItems = [];
        this.searchTerm = '';
        this.destroy$ = new Subject();
        this.isOpen = false;
        this.containerPosition = {};
        this.containerStyles = {};
        this.theme = theme$c;
        this._onChange = () => { };
        this._onTouched = () => { };
    }
    clearSelection() {
        if (!this.allowClear && !this.autoComplete && this.searchTerm == '')
            return;
        this.value = null;
        this.searchTerm = '';
        this.filteredItems = [].concat(this.items);
        this.valueChange.emit(null);
    }
    ngOnInit() {
        this.filteredItems = [].concat(this.items);
    }
    ngOnChanges(changes) {
        if (changes['items'] && changes['items'].currentValue) {
            this.filteredItems = [].concat(this.items);
        }
    }
    ngOnDestroy() {
        this.destroy$.next();
        this.destroy$.complete();
    }
    onSearchInput(searchTerm) {
        this.isOpen = true;
        this.filteredItems = this.items.filter((item) => item.label.toLowerCase().includes(searchTerm.toLowerCase()));
        this.onSearch.emit(searchTerm);
    }
    writeValue(obj) {
        this.value = obj;
    }
    registerOnChange(fn) {
        this._onChange = fn;
    }
    registerOnTouched(fn) {
        this._onTouched = fn;
    }
    setDisabledState(isDisabled) {
        this.disabled = isDisabled;
    }
    get mergedStyles() {
        return Object.assign({}, this.containerPosition, this.containerStyles, this.customOptionsStyles || {});
    }
    toggleDropdown() {
        if (!this.disabled && !this.isLoading) {
            const myZ = ++DsSelectComponent.zIndexCounter;
            this.containerStyles = {
                zIndex: `${myZ}`,
            };
            this.isOpen = !this.isOpen;
            if (this.isOpen) {
                this.filteredItems = [].concat(this.items);
            }
            setTimeout(() => this.calculatePosition(), 0);
        }
    }
    calculatePosition() {
        if (this.triggerButton &&
            this.triggerButton.nativeElement &&
            this.optionsContainer &&
            this.optionsContainer.nativeElement) {
            const rect = this.triggerButton &&
                this.triggerButton.nativeElement.getBoundingClientRect();
            const spaceBelow = window.innerHeight - rect.bottom;
            const spaceAbove = rect.top;
            this.containerPosition = {
                top: spaceBelow > spaceAbove ? '100%' : 'auto',
                bottom: spaceBelow > spaceAbove ? 'auto' : '100%',
                right: '0px',
                visibility: 'visible',
                position: 'absolute',
            };
        }
    }
    selectOption(event, item) {
        if (item.unavailable)
            return;
        if (this.multiple) {
            const current = Array.isArray(this.value) ? this.value : [];
            if (current.includes(item.value)) {
                this.value = current.filter((val) => val !== item.value);
            }
            else {
                this.value = current.concat(item.value);
            }
        }
        else {
            this.value = item.value;
            this.isOpen = false;
            this.searchTerm = '';
            this.filteredItems = [].concat(this.items);
        }
        this._onChange(this.value);
        this._onTouched();
        this.valueChange.emit({ value: this.value, event });
    }
    isSelected(item) {
        if (this.multiple && Array.isArray(this.value)) {
            return this.value.includes(item.value);
        }
        return this.value === item.value;
    }
    get selected() {
        if (this.multiple) {
            if (Array.isArray(this.value)) {
                return this.items
                    .filter((i) => this.value.includes(i.value))
                    .map((i) => ({ label: i.label, value: i.value }));
            }
            return [];
        }
        const found = this.items.find((i) => i.value === this.value);
        return found || { value: '', label: this.placeholder };
    }
    get selectedAsArray() {
        const s = this.selected;
        return Array.isArray(s) ? s : [];
    }
    get selectedItem() {
        const s = this.selected;
        return Array.isArray(s)
            ? { value: '', label: this.placeholder }
            : s;
    }
    onClickOutside(event) {
        const target = event.target;
        const clickedTrigger = this.triggerButton && this.triggerButton.nativeElement.contains(target);
        const clickedOptions = this.optionsContainer &&
            this.optionsContainer.nativeElement.contains(target);
        if (!clickedTrigger && !clickedOptions) {
            if (this.isOpen) {
                this._onTouched();
            }
            this.isOpen = false;
        }
        this.filteredItems = [].concat(this.items);
    }
    onEscClose(event) {
        if (this.isOpen) {
            this._onTouched();
        }
        this.isOpen = false;
        this.filteredItems = [].concat(this.items);
    }
    removeItem(item) {
        if (this.multiple) {
            const current = Array.isArray(this.value) ? this.value : [];
            this.value = current.filter((val) => val !== item.value);
        }
        else {
            this.value = null;
        }
    }
}
DsSelectComponent.zIndexCounter = 10000;
DsSelectComponent.decorators = [
    { type: Component, args: [{
                selector: 'ds-select',
                template: "<div id=\"ds-select\" class=\"relative w-full\" [ngClass]=\"className\">\n  <ng-container *ngIf=\"label\">\n    <div class=\"flex items-center gap-2 mb-2\">\n      <label [ngClass]=\"theme[variant].element.label\">\n        {{ label }}\n        <span *ngIf=\"required\" class=\"text-red-500\">*</span>\n      </label>\n      <ds-tooltip *ngIf=\"tooltip\" [content]=\"tooltip\" position=\"right\">\n        <ds-icon id=\"info-circle\" class=\"size-4\"></ds-icon>\n      </ds-tooltip>\n    </div>\n  </ng-container>\n\n  <div\n    #triggerButton\n    type=\"button\"\n    (click)=\"toggleDropdown()\"\n    [ngClass]=\"[\n      theme[variant].element.button.select,\n      hasError ? theme[variant].element.button.error : '',\n      disabled ? theme[variant].element.button.disabled : '',\n      pill ? 'rounded-full' : ''\n    ]\"\n  >\n    <div [ngClass]=\"[theme[variant].element.button.selected]\">\n      <ds-icon\n        *ngIf=\"buttonIcon && !selectedItem.image\"\n        [id]=\"selectedItem.icon || buttonIcon\"\n        [ngClass]=\"[disabled ? 'text-neutral-500' : 'text-red-500']\"\n      ></ds-icon>\n\n      <img\n        *ngIf=\"selectedItem.image\"\n        [src]=\"selectedItem.image\"\n        [alt]=\"selectedItem.label\"\n        class=\"rounded-full size-5\"\n      />\n      <ng-container\n        *ngIf=\"!autoComplete || (autoComplete && selectedItem.value !== '')\"\n      >\n        <span\n          *ngIf=\"!multiple\"\n          [ngClass]=\"[\n            selectedItem.label !== placeholder\n              ? theme[variant].element.button.label\n              : theme[variant].element.button.placeholder,\n            disabled ? '!text-neutral-500' : ''\n          ]\"\n        >\n          {{ selectedItem.label }}\n        </span>\n        <div\n          *ngIf=\"multiple\"\n          [ngClass]=\"[\n            selectedAsArray.length\n              ? theme[variant].element.button.label\n              : theme[variant].element.button.placeholder,\n            disabled ? '!text-neutral-500' : '',\n            'flex items-center gap-2'\n          ]\"\n        >\n          <span *ngIf=\"!selectedAsArray.length\">{{ placeholder }}</span>\n          <div\n            *ngIf=\"selectedAsArray.length\"\n            class=\"flex items-center gap-2 flex-wrap\"\n          >\n            <div\n              class=\"flex items-center gap-2 bg-neutral-50 rounded-full px-2 py-0.5\"\n              *ngFor=\"let item of selectedAsArray\"\n            >\n              <span class=\"text-xs font-semibold\">\n                {{ item.label }}\n              </span>\n              <ds-icon\n                id=\"close\"\n                class=\"size-4\"\n                (click)=\"removeItem(item)\"\n              ></ds-icon>\n            </div>\n          </div>\n        </div>\n      </ng-container>\n      <ng-container *ngIf=\"autoComplete && selectedItem.value === ''\">\n        <input\n          [(ngModel)]=\"searchTerm\"\n          type=\"text\"\n          class=\"w-full outline-none placeholder:font-semibold placeholder:text-neutral-900 placeholder:text-xs bg-level-3 mr-2\"\n          [placeholder]=\"selectedItem.label\"\n          (input)=\"onSearchInput($event.target.value)\"\n        />\n      </ng-container>\n    </div>\n\n    <ds-icon\n      (click)=\"clearSelection()\"\n      *ngIf=\"\n        (selectedItem.value !== '' && allowClear) ||\n        (selectedItem.value !== '' && autoComplete) ||\n        (autoComplete && searchTerm != '')\n      \"\n      id=\"close\"\n      [class]=\"[\n        theme[variant].element.icone.arrow,\n        'cursor-pointer',\n        disabled ? 'text-neutral-500' : ''\n      ]\"\n    ></ds-icon>\n\n    <ds-icon\n      *ngIf=\"!isLoading && !allowClear && !autoComplete\"\n      [id]=\"isOpen ? 'arrow-up' : 'arrow-down'\"\n      [class]=\"[\n        theme[variant].element.icone.arrow,\n        disabled ? 'text-neutral-500' : ''\n      ]\"\n    ></ds-icon>\n\n    <ds-icon\n      *ngIf=\"\n        !isLoading &&\n        (allowClear || autoComplete) &&\n        selectedItem.value === '' &&\n        searchTerm === ''\n      \"\n      [id]=\"isOpen ? 'arrow-up' : 'arrow-down'\"\n      [class]=\"[\n        theme[variant].element.icone.arrow,\n        disabled ? 'text-neutral-500' : ''\n      ]\"\n    ></ds-icon>\n\n    <ds-icon\n      *ngIf=\"isLoading\"\n      id=\"Loader\"\n      [class]=\"theme[variant].element.icone.arrow + ' animate-spin'\"\n    ></ds-icon>\n  </div>\n\n  <div\n    *ngIf=\"isOpen\"\n    #optionsContainer\n    [ngStyle]=\"mergedStyles\"\n    [ngClass]=\"theme[variant].element.options.container\"\n  >\n    <div *ngIf=\"searchable\" class=\"mb-2\">\n      <ds-input\n        [placeholder]=\"placeholder\"\n        [value]=\"searchTerm\"\n        (input)=\"onSearchInput($event.target.value)\"\n      >\n        <ds-icon\n          id=\"search1\"\n          prefix\n          (click)=\"onSearchInput($event.target.value)\"\n        ></ds-icon>\n      </ds-input>\n    </div>\n    <div class=\"grow overflow-y-auto\">\n      <ng-container *ngIf=\"filteredItems.length > 0; else emptyState\">\n        <div\n          *ngFor=\"let item of filteredItems\"\n          (click)=\"selectOption($event, item)\"\n          class=\"relative after:absolute after:-left-1 after:w-0.5 after:h-1/2 after:top-1/2 after:-translate-y-1/2 after:rounded-r\"\n          [ngClass]=\"[\n            theme[variant].element.options.element,\n            item.unavailable\n              ? theme[variant].element.options.unavailable\n              : theme[variant].element.options.available,\n            isSelected(item) ? 'bg-neutral-50 ' : 'bg-transparent',\n            item.isAccount\n              ? isSelected(item)\n                ? 'after:bg-red-500'\n                : 'after:bg-transparent'\n              : ''\n          ]\"\n          [class.cursor-not-allowed]=\"item.unavailable\"\n        >\n          <div class=\"flex justify-between items-center\">\n            <div\n              *ngIf=\"!item.isAccount; else account\"\n              class=\"flex justify-between items-center gap-2\"\n            >\n              <ds-icon\n                *ngIf=\"item.icon\"\n                [id]=\"item.icon\"\n                [class]=\"item.iconClass\"\n              ></ds-icon>\n              <img\n                *ngIf=\"item.image\"\n                [src]=\"item.image\"\n                [alt]=\"item.label\"\n                class=\"shrink-0 rounded-full size-5\"\n                [ngClass]=\"[item.imageClass || '']\"\n              />\n              <span\n                [ngClass]=\"[\n                  theme[variant].element.options.fontcolor,\n                  isSelected(item)\n                    ? theme[variant].element.options.selectedfont\n                    : '',\n                  'whitespace-nowrap'\n                ]\"\n              >\n                {{ item.label }}\n              </span>\n            </div>\n            <ng-template #account>\n              <div class=\"flex justify-start items-center gap-3\">\n                <div\n                  *ngIf=\"item.icon\"\n                  class=\"size-10 flex justify-center items-center rounded-full\"\n                >\n                  <ds-icon [id]=\"item.icon\" class=\"text-red-500\"></ds-icon>\n                </div>\n\n                <img\n                  *ngIf=\"item.image\"\n                  [src]=\"item.image\"\n                  [alt]=\"item.label\"\n                  class=\"rounded-full size-10\"\n                />\n                <div class=\"flex flex-col gap-1\">\n                  <span\n                    class=\"inline-flex text-neutral-500 font-light text-[0.75rem]/[1rem]\"\n                    >{{ item.label }}</span\n                  >\n                  <span class=\"inline-flex font-semibold text-[0.75rem]/[1rem]\">\n                    {{ item.value }}\n                  </span>\n                </div>\n              </div>\n            </ng-template>\n          </div>\n        </div>\n      </ng-container>\n    </div>\n\n    <ng-template #emptyState>\n      <div class=\"p-2 px-4 text-gray-600\">{{ emptyLabel }}</div>\n    </ng-template>\n  </div>\n\n  <ng-container *ngIf=\"hasError && errorMessage\">\n    <span [ngClass]=\"theme[variant].element.error\">{{ errorMessage }}</span>\n  </ng-container>\n  <ng-container *ngIf=\"description\">\n    <span [ngClass]=\"theme[variant].element.description\">{{\n      description\n    }}</span>\n  </ng-container>\n</div>\n",
                providers: [
                    {
                        provide: NG_VALUE_ACCESSOR,
                        useExisting: forwardRef(() => DsSelectComponent),
                        multi: true,
                    },
                ]
            }] }
];
DsSelectComponent.propDecorators = {
    items: [{ type: Input }],
    label: [{ type: Input }],
    errorMessage: [{ type: Input }],
    placeholder: [{ type: Input }],
    variant: [{ type: Input }],
    disabled: [{ type: Input }],
    hasError: [{ type: Input }],
    pill: [{ type: Input }],
    emptyLabel: [{ type: Input }],
    multiple: [{ type: Input }],
    isLoading: [{ type: Input }],
    className: [{ type: Input }],
    buttonIcon: [{ type: Input }],
    value: [{ type: Input }],
    customOptionsStyles: [{ type: Input }],
    autoComplete: [{ type: Input }],
    debounceTime: [{ type: Input }],
    description: [{ type: Input }],
    tooltip: [{ type: Input }],
    required: [{ type: Input }],
    allowClear: [{ type: Input }],
    onSearch: [{ type: Output }],
    valueChange: [{ type: Output }],
    searchable: [{ type: Input }],
    triggerButton: [{ type: ViewChild, args: ['triggerButton',] }],
    optionsContainer: [{ type: ViewChild, args: ['optionsContainer',] }],
    onClickOutside: [{ type: HostListener, args: ['document:click', ['$event'],] }],
    onEscClose: [{ type: HostListener, args: ['document:keydown.escape', ['$event'],] }]
};

/**
 * Account-grid-cardComponent
 *
 * Live demo:
 * <example-url>/demo/ds-account-grid-card.component.html</example-url>
 */
class DsAccountGridCardComponent {
    constructor() {
        this.isDiscrete = false;
        this.className = '';
        this.showAccordion = false;
    }
    toggleAccordion() {
        this.showAccordion = !this.showAccordion;
    }
}
DsAccountGridCardComponent.decorators = [
    { type: Component, args: [{
                selector: 'ds-account-grid-card',
                template: "<article\n  id=\"ds-account-grid-card\"\n  class=\"bg-level-4 border border-stroke-1 rounded w-full flex flex-col gap-4\"\n  [ngClass]=\"className\"\n>\n  <!-- Header -->\n  <div\n    class=\"flex gap-5 items-center justify-between transition-all duration-300 ease-in\"\n    [ngClass]=\"showAccordion ? 'px-3.5 pt-3.5' : 'px-3.5 py-3'\"\n  >\n    <h3 *ngIf=\"title\" class=\"text-neutral-900 text-[0.875rem]/[1.125rem]\">\n      {{ title }}\n    </h3>\n\n    <div class=\"flex gap-5 items-center\">\n      <!-- Solde Comptable -->\n      <ds-display-value [value]=\"price\">\n        <ds-balance-formatter\n          *ngIf=\"price\"\n          [isDiscrete]=\"isDiscrete\"\n          [balance]=\"price\"\n          [currency]=\"currency\"\n          class=\"text-[1rem]/[1rem] font-bold\"\n          currencyClassName=\"text-[0.75rem]/[0.75rem]\"\n        ></ds-balance-formatter>\n      </ds-display-value>\n\n      <!-- Date -->\n\n      <div class=\"flex flex-col gap-y-1 font-normal\">\n        <span class=\"text-neutral-500 text-[0.75rem]/[0.875rem]\">\n          Date op\u00E9ration\n        </span>\n        <ds-display-value [value]=\"dateOperation\">\n          <p class=\"text-neutral-900 text-[0.875rem]/[1.125rem]\">\n            {{ dateOperation }}\n          </p>\n        </ds-display-value>\n      </div>\n      <div class=\"flex flex-col gap-y-1 font-normal\">\n        <span class=\"text-neutral-500 text-[0.75rem]/[0.875rem]\"> Date valeur </span>\n        <ds-display-value [value]=\"dateValue\">\n          <p class=\"text-neutral-900 text-[0.875rem]/[1.125rem]\">\n            {{ dateValue }}\n          </p>\n        </ds-display-value>\n      </div>\n    </div>\n  </div>\n\n  <!-- Accordion Content -->\n  <div\n    *ngIf=\"showAccordion\"\n    class=\"bg-neutral-25 p-4 border-t border-t-neutral-100 w-full rounded-b-sm\"\n  >\n    <ng-content></ng-content>\n  </div>\n</article>\n"
            }] }
];
DsAccountGridCardComponent.propDecorators = {
    isDiscrete: [{ type: Input }],
    title: [{ type: Input }],
    currency: [{ type: Input }],
    price: [{ type: Input }],
    dateOperation: [{ type: Input }],
    dateValue: [{ type: Input }],
    className: [{ type: Input }]
};

/**
 * Account-grid-holding-cardComponent
 *
 * Live demo:
 * <example-url>/demo/ds-account-grid-holding-card.component.html</example-url>
 */
class DsAccountGridHoldingCardComponent {
    constructor() {
        this.actionsList = [];
        this.className = '';
        this.isDiscrete = false;
        this.showAccordion = false;
    }
    ngOnInit() {
        this.actionsList =
            this.actionsList
                .map((action) => (Object.assign({}, action, { onClick: (event) => action.onClick && action.onClick({ data: this.data, event: event }), dropdownItems: action.dropdownItems
                    ? action.dropdownItems.map((item) => (Object.assign({}, item, { onClick: (event) => item.onClick &&
                            item.onClick({ data: this.data, event: event }) })))
                    : null })))
                .concat({
                icon: 'arrow-down',
                onClick: () => this.toggleAccordion(),
                dropdownItems: null,
            }) || [];
    }
    toggleAccordion() {
        this.showAccordion = !this.showAccordion;
    }
}
DsAccountGridHoldingCardComponent.decorators = [
    { type: Component, args: [{
                selector: 'ds-account-grid-holding-card',
                template: "<article\n  id=\"ds-account-grid-holding-card\"\n  class=\"border border-stroke-1 rounded w-full flex flex-col gap-4 bg-level-4\"\n  [ngClass]=\"className\"\n>\n  <!-- Header -->\n  <div\n    class=\"flex gap-5 items-center justify-between transition-all duration-300 ease-in\"\n    [ngClass]=\"showAccordion ? 'px-3.5 pt-3.5' : 'px-3.5 py-3.5'\"\n  >\n    <div class=\"flex flex-col gap-y-2\">\n      <h3\n        *ngIf=\"title\"\n        class=\"text-neutral-700 inline-flex gap-2 items-center text-[0.875rem]/[1.125rem]\"\n      >\n        {{ title }}\n\n        <span *ngIf=\"editLink\" class=\"text-neutral-900 text-[0.75rem]/normal\">\n          <a\n            [href]=\"editLink\"\n            class=\"hover:opacity-80 transition-all duration-300 ease-in\"\n          >\n            <ds-icon id=\"edit-contained-1\" class=\"size-3\"></ds-icon>\n          </a>\n        </span>\n      </h3>\n      <p\n        *ngIf=\"accountNumber\"\n        class=\"text-neutral-900 font-bold inline-flex gap-2 items-center text-[1rem]/[1.25rem]\"\n      >\n        {{ accountNumber }}\n\n        <button (click)=\"copyToClipboard(accountNumber)\">\n          <ds-icon id=\"copy\" size=\"12\" class=\"text-neutral-900\"></ds-icon>\n        </button>\n      </p>\n    </div>\n    <div class=\"flex gap-5 items-center\">\n      <!-- Solde Comptable -->\n      <div class=\"flex flex-col gap-y-1 font-normal w-40\">\n        <span class=\"text-neutral-500 text-[0.875rem]/[1.125rem]\">\n          Solde comptable\n        </span>\n        <ds-display-value [value]=\"soldeComptable\">\n          <ds-balance-formatter\n            *ngIf=\"soldeComptable\"\n            [isDiscrete]=\"isDiscrete\"\n            [balance]=\"soldeComptable\"\n            [currency]=\"currency\"\n            class=\"text-[1.125rem]/[1.125rem] font-bold\"\n            currencyClassName=\"text-[0.875rem]/[0.875rem]\"\n          ></ds-balance-formatter>\n        </ds-display-value>\n      </div>\n\n      <!-- Solde Reel -->\n      <div class=\"flex flex-col gap-y-1 font-normal w-40\">\n        <span class=\"text-neutral-500 text-[0.875rem]/[1.125rem]\"> Solde r\u00E9el </span>\n        <ds-display-value [value]=\"soldeReel\">\n          <ds-balance-formatter\n            *ngIf=\"soldeReel\"\n            [isDiscrete]=\"isDiscrete\"\n            [balance]=\"soldeReel\"\n            [currency]=\"currency\"\n            class=\"text-[1.125rem]/[1.125rem] font-bold\"\n            currencyClassName=\"text-[0.875rem]/[0.875rem]\"\n          ></ds-balance-formatter>\n        </ds-display-value>\n      </div>\n\n      <!-- Toolbox -->\n      <ds-call-to-action-icons\n        [actions]=\"actionsList\"\n        className=\"w-fit\"\n        variant=\"borderless\"\n      ></ds-call-to-action-icons>\n    </div>\n  </div>\n\n  <!-- Accordion Content -->\n  <div\n    *ngIf=\"showAccordion\"\n    class=\"bg-neutral-25 p-4 border-t border-t-neutral-100 w-full rounded-b-sm\"\n  >\n    <ng-content></ng-content>\n  </div>\n</article>\n"
            }] }
];
DsAccountGridHoldingCardComponent.propDecorators = {
    id: [{ type: Input }],
    title: [{ type: Input }],
    accountNumber: [{ type: Input }],
    currency: [{ type: Input }],
    soldeComptable: [{ type: Input }],
    soldeReel: [{ type: Input }],
    actionsList: [{ type: Input }],
    editLink: [{ type: Input }],
    className: [{ type: Input }],
    isDiscrete: [{ type: Input }],
    data: [{ type: Input }],
    copyToClipboard: [{ type: Input }]
};

/**
 * Account-slider-cardComponent
 *
 * Live demo:
 * <example-url>/demo/ds-account-slider-card.component.html</example-url>
 */
class DsAccountSliderCardComponent {
    constructor() {
        this.isDiscrete = false;
        this.isSelected = false;
        this.actionsList = [];
        this.className = '';
        this.minHeight = 152;
        this.onClick = new EventEmitter();
    }
    ngOnInit() {
        this.actionsList = this.actionsList.map((action) => (Object.assign({}, action, { onClick: (event) => action.onClick &&
                action.onClick({
                    event: event,
                    data: this.data,
                }) })));
    }
    handleClick(event) {
        this.onClick.emit({
            data: this.data,
            event: event,
        });
    }
}
DsAccountSliderCardComponent.decorators = [
    { type: Component, args: [{
                selector: 'ds-account-slider-card',
                template: "<article\n  id=\"ds-account-slider-card\"\n  (click)=\"handleClick($event)\"\n  tabindex=\"0\"\n  role=\"button\"\n  class=\"shrink-0 text-neutral-900 rounded-lg snap-start relative bg-card-level-1 px-4 py-4 pb-2 flex flex-col justify-between\"\n  [ngClass]=\"className\"\n  [style.min-height]=\"minHeight + 'px'\"\n>\n  <!-- Dropdown -->\n  <ds-dropdown\n    [items]=\"actionsList\"\n    class=\"absolute top-4 right-2\"\n    anchor=\"bottom end\"\n  >\n    <ds-icon id=\"dot-vertical\" class=\"size-4\"></ds-icon>\n  </ds-dropdown>\n\n  <!-- Account Info -->\n  <div *ngIf=\"type || account_number\" class=\"space-y-2\">\n    <h3 *ngIf=\"type\" class=\"text-[1rem]/[1.25rem] font-medium\">\n      {{ type }}\n    </h3>\n\n    <p\n      *ngIf=\"account_number\"\n      class=\"text-[0.875rem]/[1.25rem] transition-all duration-300 ease-in-out font-light inline-flex gap-1\"\n    >\n      <sup class=\"inline-flex mt-2.5\">N\u00B0</sup>\n      {{ account_number }}\n    </p>\n  </div>\n\n  <!-- Balance -->\n  <ds-balance-formatter\n    *ngIf=\"balance || currency\"\n    [isDiscrete]=\"isDiscrete\"\n    [balance]=\"balance\"\n    [currency]=\"currency\"\n    className=\"ml-auto\"\n    currencyClassName=\"text-[0.875rem]/[1rem]\"\n  >\n  </ds-balance-formatter>\n</article>\n"
            }] }
];
DsAccountSliderCardComponent.propDecorators = {
    isDiscrete: [{ type: Input }],
    account_number: [{ type: Input }],
    balance: [{ type: Input }],
    currency: [{ type: Input }],
    type: [{ type: Input }],
    id: [{ type: Input }],
    isSelected: [{ type: Input }],
    actionsList: [{ type: Input }],
    className: [{ type: Input }],
    minHeight: [{ type: Input }],
    data: [{ type: Input }],
    onClick: [{ type: Output }]
};

/**
 * Account-selected-cardComponent
 *
 * Live demo:
 * <example-url>/demo/ds-account-selected-card.component.html</example-url>
 */
class DsAccountSelectedCardComponent {
    constructor() {
        this.isDiscrete = false;
        this.actionsList = [];
        this.className = '';
    }
    ngOnInit() {
        this.actionsList = this.actionsList.map((action) => (Object.assign({}, action, { onClick: (event) => action.onClick &&
                action.onClick({
                    event: event,
                    data: this.data,
                }) })));
    }
}
DsAccountSelectedCardComponent.decorators = [
    { type: Component, args: [{
                selector: 'ds-account-selected-card',
                template: "<article\n  id=\"ds-account-selected-card\"\n  class=\"shrink-0 text-neutral-900 rounded-lg relative p-px shadow-content shadow-neutral-50\"\n  [ngClass]=\"[\n    className\n  ]\"\n>\n  <div\n    class=\"rounded-[7px] relative after:rounded-[7px] after:absolute after:inset-0 after:bg-red-10 after:-z-[1] z-[2] bg-green-500 text-white\"\n  >\n    <!-- [ngStyle]=\"{\n      'background-image':\n        solde_comptable > 0\n          ? 'linear-gradient(325deg, hsl(152deg 82% 95%) 0%, rgb(var(--color-neutral-25)) 30%)'\n          : 'linear-gradient(325deg, hsl(357deg 82% 95%) 0%, rgb(var(--color-neutral-25)) 30%)'\n    }\" -->\n    <!-- Top Block -->\n    <div class=\"relative rounded-t-lg p-4\">\n      <ds-dropdown\n        class=\"absolute top-4 right-2\"\n        [items]=\"actionsList\"\n        anchor=\"bottom end\"\n      >\n        <ds-icon id=\"dot-vertical\" size=\"18\"></ds-icon>\n      </ds-dropdown>\n\n      <!-- Account Info -->\n      <div class=\"flex flex-col gap-2.5\" *ngIf=\"type || account_number\">\n        <h3 *ngIf=\"type\" class=\"inline-flex gap-2 items-center\">\n          <ds-icon id=\"bank2\" size=\"14\" class=\"text-white\"></ds-icon>\n          <span class=\"text-[1rem]/[1.25rem] font-medium truncate mr-5\">\n            {{ type }}\n          </span>\n        </h3>\n\n        <p\n          *ngIf=\"account_number\"\n          class=\"text-[0.875rem]/[1.125rem] font-bold inline-flex gap-px\"\n        >\n          <sup class=\"inline-flex mt-2.5 font-light\">N\u00B0</sup>\n          {{ account_number }}\n        </p>\n      </div>\n\n      <div class=\"flex items-center justify-between w-full mt-2.5\">\n        <span class=\"text-[0.75rem]/[1rem] text-white\">\n          Solde en temps r\u00E9el\n        </span>\n\n        <ds-balance-formatter\n          *ngIf=\"solde_temps_reel || currency\"\n          [isDiscrete]=\"isDiscrete\"\n          [balance]=\"solde_temps_reel || 0\"\n          [currency]=\"currency\"\n          [currencyClassName]=\"'text-[0.875rem]/[1rem] text-white'\"\n          [className]=\"'text-white'\"\n        >\n        </ds-balance-formatter>\n      </div>\n    </div>\n\n    <span class=\"mx-4 h-px bg-stroke-3 dark:bg-white block\"></span>\n    <!-- Bottom Block -->\n    <div class=\"px-4 py-3 flex justify-between items-center gap-2\">\n      <span class=\"text-[0.75rem]/[0.75rem] text-white\">\n        Solde comptable\n      </span>\n      <ds-balance-formatter\n        *ngIf=\"solde_comptable\"\n        [isDiscrete]=\"isDiscrete\"\n        [balance]=\"solde_comptable\"\n        [currency]=\"currency\"\n        [currencyClassName]=\"'text-[0.875rem]/[1rem] text-white'\"\n        [className]=\"'text-white'\"\n      >\n      </ds-balance-formatter>\n    </div>\n  </div>\n</article>\n"
            }] }
];
DsAccountSelectedCardComponent.propDecorators = {
    isDiscrete: [{ type: Input }],
    account_number: [{ type: Input }],
    balance: [{ type: Input }],
    currency: [{ type: Input }],
    type: [{ type: Input }],
    id: [{ type: Input }],
    actionsList: [{ type: Input }],
    solde_comptable: [{ type: Input }],
    solde_temps_reel: [{ type: Input }],
    className: [{ type: Input }],
    data: [{ type: Input }]
};

/**
 * Account-holding-cardComponent
 *
 * Live demo:
 * <example-url>/demo/ds-account-holding-card.component.html</example-url>
 */
class AccountHoldingCardComponent {
    constructor() {
        this.className = '';
        this.actionsList = [];
        this.onClick = new EventEmitter();
        this.getFirstTwoLetters = getFirstTwoLetters;
    }
    ngOnInit() {
        this.actionsList = this.actionsList.map((action) => (Object.assign({}, action, { onClick: (event) => action.onClick &&
                action.onClick({
                    event: event,
                    data: this.data,
                }) })));
    }
    handleClick(event) {
        this.onClick.emit({
            data: this.data,
            event: event,
        });
    }
}
AccountHoldingCardComponent.decorators = [
    { type: Component, args: [{
                selector: 'ds-account-holding-card',
                template: "<article\n  id=\"ds-account-holding-card\"\n  [ngClass]=\"[\n    'cursor-pointer group relative flex items-center justify-start min-h-[90px] text-neutral-900 gap-[14px] rounded-lg p-3.5 pr-6 bg-card-level-1 w-full',\n    className\n  ]\"\n  (click)=\"handleClick($event)\"\n>\n  <ds-dropdown\n    class=\"absolute top-3 right-2\"\n    [items]=\"actionsList\"\n    anchor=\"bottom end\"\n  >\n    <ds-icon id=\"dot-vertical\" size=\"18\"></ds-icon>\n  </ds-dropdown>\n\n  <div\n    translate=\"no\"\n    class=\"shrink-0 rounded-md bg-white text-green-500 size-[62px] font-bold text-[1.25rem]/[1.688rem] flex items-center justify-center\"\n  >\n    {{ getFirstTwoLetters(title) | uppercase }}\n  </div>\n  <h3 *ngIf=\"title\" class=\"text-[1rem]/[1.30rem] text-left font-bold\">\n    {{ title }}\n  </h3>\n</article>\n"
            }] }
];
AccountHoldingCardComponent.propDecorators = {
    id: [{ type: Input }],
    image: [{ type: Input }],
    title: [{ type: Input }],
    className: [{ type: Input }],
    actionsList: [{ type: Input }],
    data: [{ type: Input }],
    onClick: [{ type: Output }]
};

/**
 * Account-holding-selected-cardComponent
 *
 * Live demo:
 * <example-url>/demo/ds-account-holding-selected-card.component.html</example-url>
 */
class AccountHoldingSelectedCardComponent {
    constructor() {
        this.className = '';
        this.actionsList = [];
        this.onClick = new EventEmitter();
        this.getFirstTwoLetters = getFirstTwoLetters;
    }
    ngOnInit() {
        this.actionsList = this.actionsList.map((action) => (Object.assign({}, action, { onClick: (event) => action.onClick &&
                action.onClick({
                    event: event,
                    data: this.data,
                }) })));
    }
    handleClick(event) {
        this.onClick.emit({
            data: this.data,
            event: event,
        });
    }
}
AccountHoldingSelectedCardComponent.decorators = [
    { type: Component, args: [{
                selector: 'ds-account-holding-selected-card',
                template: "<article\n  id=\"ds-account-holding-selected-card\"\n  [ngClass]=\"[\n    'cursor-pointer group relative flex border border-stroke-1 bg-green-500 items-center justify-start text-white gap-[14px] rounded-lg p-[14px]',\n    className\n  ]\"\n  (click)=\"handleClick($event)\"\n>\n  <ds-dropdown\n    class=\"absolute top-3 right-2\"\n    [items]=\"actionsList\"\n    anchor=\"bottom end\"\n  >\n    <ds-icon id=\"dot-vertical\" size=\"18\"></ds-icon>\n  </ds-dropdown>\n\n  <div\n    translate=\"no\"\n    class=\"shrink-0 rounded-md bg-green-50 dark:bg-green-900 text-green-500 dark:text-green-50 size-[62px] font-bold text-[1.5rem]/[1.688rem] flex items-center justify-center\"\n  >\n    {{ getFirstTwoLetters(title) | uppercase }}\n  </div>\n  <h3 *ngIf=\"title\" class=\"text-[1.25rem]/[1.688rem] text-left font-bold\">\n    {{ title }}\n  </h3>\n</article>\n"
            }] }
];
AccountHoldingSelectedCardComponent.propDecorators = {
    id: [{ type: Input }],
    image: [{ type: Input }],
    title: [{ type: Input }],
    className: [{ type: Input }],
    data: [{ type: Input }],
    actionsList: [{ type: Input }],
    onClick: [{ type: Output }]
};

/**
 * Account-filial-holding-cardComponent
 *
 * Live demo:
 * <example-url>/demo/ds-account-filial-holding-card.component.html</example-url>
 */
class DsAccountFilialHoldingCardComponent {
    constructor() {
        this.className = '';
        this.actionsList = [];
        this._showAccordion = false;
        this.showAccordionIcon = 'arrow-down';
        this.getFirstTwoLetters = getFirstTwoLetters;
    }
    toggleAccordion() {
        this.showAccordion = !this._showAccordion;
        this.showAccordionIcon = this._showAccordion ? 'arrow-up' : 'arrow-down';
    }
    set showAccordion(value) {
        this._showAccordion = value;
        this.showAccordionIcon = this._showAccordion ? 'arrow-up' : 'arrow-down';
        this.actionsList = this.actionsList.map((action, index) => {
            if (index === this.actionsList.length - 1) {
                return Object.assign({}, action, { icon: this.showAccordionIcon });
            }
            else {
                return action;
            }
        });
    }
    ngOnInit() {
        this.actionsList =
            this.actionsList
                .map((action) => (Object.assign({}, action, { onClick: (event) => action.onClick &&
                    action.onClick({
                        event: event,
                        data: this.data,
                    }) })))
                .concat({
                icon: this.showAccordionIcon,
                onClick: () => this.toggleAccordion(),
            }) || [];
    }
}
DsAccountFilialHoldingCardComponent.decorators = [
    { type: Component, args: [{
                selector: 'ds-account-filial-holding-card',
                template: "<article\n  id=\"ds-account-filial-holding-card\"\n  class=\"border border-stroke-1 rounded w-full flex flex-col gap-4\"\n  [ngClass]=\"className\"\n>\n  <!-- Header -->\n  <div\n    class=\"flex gap-5 items-center justify-between transition-all duration-300 ease-in\"\n    [ngClass]=\"_showAccordion ? 'px-3.5 pt-3' : 'px-3.5 py-3'\"\n  >\n    <div class=\"flex justify-start items-center gap-3.5\">\n      <div\n        translate=\"no\"\n        class=\"shrink-0 rounded-md bg-[#e9f4f3] dark:bg-[#245140] text-green-500 dark:text-green-900 size-[62px] font-bold text-[1.25rem]/[1.688rem] flex items-center justify-center\"\n      >\n        {{ getFirstTwoLetters(title) | uppercase }}\n      </div>\n      <h3\n        *ngIf=\"title\"\n        class=\"text-neutral-900 text-[1rem]/[1.25rem] font-bold\"\n      >\n        {{ title }}\n      </h3>\n    </div>\n\n    <!-- Toolbox -->\n    <ds-call-to-action-icons\n      [actions]=\"actionsList\"\n      className=\"w-fit\"\n      variant=\"borderless\"\n    ></ds-call-to-action-icons>\n  </div>\n\n  <!-- Accordion Content -->\n  <div\n    *ngIf=\"_showAccordion\"\n    class=\"bg-neutral-25 p-4 border-t border-t-neutral-100 w-full rounded-b-sm\"\n  >\n    <ng-content></ng-content>\n  </div>\n</article>\n"
            }] }
];
DsAccountFilialHoldingCardComponent.propDecorators = {
    id: [{ type: Input }],
    title: [{ type: Input }],
    image: [{ type: Input }],
    className: [{ type: Input }],
    data: [{ type: Input }],
    actionsList: [{ type: Input }]
};

/**
 * Sheet-cardComponent
 *
 * Live demo:
 * <example-url>/demo/ds-sheet-card.component.html</example-url>
 */
class SheetCardComponent {
    constructor() {
        this.iconPosition = 'bottom';
        this.className = '';
        this.iconPositionClassName = '';
        this.removeImageRounded = false;
    }
    isTemplate(ref) {
        return ref instanceof TemplateRef;
    }
}
SheetCardComponent.decorators = [
    { type: Component, args: [{
                selector: 'ds-sheet-card',
                template: "<div\n  id=\"ds-sheet-card\"\n  (click)=\"onClick({ event: $event, data: data })\"\n  [ngClass]=\"[\n    className,\n    isDraggable\n      ? 'group hover:pl-10 transition-all ease-in-out duration-300 hover:pr-3.5'\n      : ''\n  ]\"\n  class=\"px-3.5 relative bg-level-3 flex flex-row rounded items-center justify-start py-3 gap-2\"\n>\n  <ng-container *ngIf=\"isTemplate(leftContent)\">\n    <ng-container *ngTemplateOutlet=\"leftContent\"></ng-container>\n  </ng-container>\n  <div\n    *ngIf=\"isDraggable\"\n    class=\"absolute top-1/2 -translate-y-1/2 left-1 opacity-0 invisible group-hover:opacity-100 group-hover:visible transition-all duration-300 cursor-pointer\"\n  >\n    <ds-icon\n      id=\"dragdrop\"\n      size=\"32\"\n      class=\"text-neutral-300 dark:text-white\"\n    ></ds-icon>\n  </div>\n  <img\n    *ngIf=\"image\"\n    [src]=\"image\"\n    [alt]=\"label\"\n    class=\"size-10 shrink-0 object-cover\"\n    [ngClass]=\"!removeImageRounded ? 'rounded-full' : 'rounded-sm'\"\n  />\n  <div\n    *ngIf=\"icon\"\n    class=\"size-10 shrink-0 flex items-center justify-center border border-neutral-100 bg-white rounded-full\"\n  >\n    <ds-icon [id]=\"icon\" size=\"20\" class=\"text-red-500\"></ds-icon>\n  </div>\n  <div\n    class=\"w-full flex justify-between\"\n    [ngClass]=\"\n      iconPosition === 'top'\n        ? 'items-start'\n        : iconPosition === 'center'\n        ? 'items-center'\n        : 'items-end'\n    \"\n  >\n    <div class=\"w-full flex items-start justify-center flex-col gap-1\">\n      <h4\n        class=\"text-[0.875rem]/[1.125rem]\"\n        [ngClass]=\"\n          removeImageRounded\n            ? 'font-bold text-neutral-900'\n            : 'font-normal text-neutral-500'\n        \"\n      >\n        {{ label }}\n      </h4>\n      <ng-content></ng-content>\n    </div>\n    \n    \n    <button\n      (click)=\"\n        startClick && startClick({ event: $event, data: data });\n        $event.stopPropagation()\n      \"\n      click-stop-propagation\n      *ngIf=\"iconRight\"\n      class=\"flex items-center justify-center text-red-500\"\n      [ngClass]=\"iconPositionClassName\"\n    >\n      <ds-icon [id]=\"iconRight\" size=\"16\"></ds-icon>\n    </button>\n  </div>\n</div>\n"
            }] }
];
SheetCardComponent.propDecorators = {
    image: [{ type: Input }],
    icon: [{ type: Input }],
    label: [{ type: Input }],
    isDraggable: [{ type: Input }],
    leftContent: [{ type: Input }],
    data: [{ type: Input }],
    iconRight: [{ type: Input }],
    iconPosition: [{ type: Input }],
    className: [{ type: Input }],
    iconPositionClassName: [{ type: Input }],
    removeImageRounded: [{ type: Input }],
    onClick: [{ type: Input }],
    startClick: [{ type: Input }]
};

/**
 * Actions-layoutComponent
 *
 * Live demo:
 * <example-url>/demo/ds-actions-layout.component.html</example-url>
 */
class DsActionsLayoutComponent {
    constructor() {
        this.items = [];
        this.className = '';
        this.selectedClass = '';
        this.selectedElement = null;
    }
    onClick(item, index) {
        this.selectedElement = this.selectedElement === index ? null : index;
        item.handler();
    }
    isSelected(index) {
        return this.selectedElement === index;
    }
}
DsActionsLayoutComponent.decorators = [
    { type: Component, args: [{
                selector: 'ds-actions-layout',
                template: "<div\n  id=\"ds-actions-layout\"\n  class=\"px-4 py-[11px] rounded bg-card-level-2 border border-stroke-1 flex flex-row gap-3.5 text-neutral-900\"\n  [ngClass]=\"className\"\n>\n  <button\n    [disabled]=\"item.disabled\"\n    *ngFor=\"let item of items; let i = index\"\n    (click)=\"onClick(item, i)\"\n    class=\"relative\"\n\n    [ngClass]=\"[\n      isSelected(i) ? 'text-red-500' : '',\n      item.badge && item.iconId.includes('bell')\n        ? 'after:absolute after:size-2 after:rounded-full after:top-0 after:border after:border-card-level-2 after:right-[3px] after:bg-red-500'\n        : '',\n      selectedClass,\n      item.className || '',\n      item.disabled ? 'opacity-50 cursor-not-allowed' : 'hover:text-red-500'\n    ]\"\n  >\n    <ds-icon\n      [id]=\"isSelected(i) ? item.iconIdFilled : item.iconId\"\n      size=\"24\"\n    ></ds-icon>\n  </button>\n</div>\n"
            }] }
];
DsActionsLayoutComponent.propDecorators = {
    items: [{ type: Input }],
    className: [{ type: Input }],
    selectedClass: [{ type: Input }]
};

const callToActionIconsTheme = {
    default: {
        wrapper: 'flex border border-stroke-1 bg-level-5 rounded py-2 items-center justify-start gap-px text-neutral-900',
        separator: 'shrink-0 h-3 w-px bg-neutral-500',
        button: 'px-2 hover:opacity-50 transition-opacity duration-300',
        icon: 'flex items-center justify-center text-neutral-900',
        iconSize: '16',
    },
    separated: {
        wrapper: 'flex items-center justify-start gap-1 text-neutral-900',
        separator: '',
        button: 'border border-stroke-1 bg-level-5 rounded p-2 hover:opacity-50 transition-opacity duration-300',
        icon: 'flex items-center justify-center',
        iconSize: '16',
    },
    borderless: {
        wrapper: 'flex items-center justify-start gap-3.5 text-neutral-900',
        separator: '',
        button: 'hover:opacity-50 transition-opacity duration-300',
        icon: 'flex items-center justify-center text-neutral-900',
        iconSize: '16',
    },
};

/**
 * Call-to-action-iconsComponent
 *
 * Live demo:
 * <example-url>/demo/ds-call-to-action-icons.component.html</example-url>
 */
class CallToActionIconsComponent {
    constructor() {
        this.variant = 'default';
        this.className = '';
        this.actions = [];
        this.theme = callToActionIconsTheme;
    }
    handleClick(event, action) {
        if (typeof action.onClick === 'function') {
            action.onClick(event);
        }
    }
}
CallToActionIconsComponent.decorators = [
    { type: Component, args: [{
                selector: 'ds-call-to-action-icons',
                template: "<div\n  id=\"ds-call-to-action-icons\"\n  [ngClass]=\"[theme[variant].wrapper, className]\"\n>\n  <ng-container *ngFor=\"let action of actions; let i = index\">\n    <div\n      *ngIf=\"theme[variant] && theme[variant].separator && i > 0\"\n      [ngClass]=\"[theme[variant].separator || '']\"\n    ></div>\n    <ds-dropdown\n      *ngIf=\"action.dropdownItems && action.dropdownItems.length > 0\"\n      [items]=\"action.dropdownItems\"\n      [className]=\"'mt-1.5'\"\n    >\n      <ds-icon\n        [id]=\"action.icon\"\n        [size]=\"theme[variant].iconSize\"\n        [ngClass]=\"theme[variant].icon\"\n      ></ds-icon>\n    </ds-dropdown>\n\n    <button\n      *ngIf=\"!action.dropdownItems\"\n      type=\"button\"\n      (click)=\"handleClick($event, action)\"\n      [ngClass]=\"[theme[variant].button, action.buttonClassName || '']\"\n    >\n      <ds-icon\n        [id]=\"action.icon\"\n        [size]=\"theme[variant].iconSize\"\n        [ngClass]=\"theme[variant].icon\"\n      ></ds-icon>\n    </button>\n  </ng-container>\n</div>\n"
            }] }
];
CallToActionIconsComponent.propDecorators = {
    variant: [{ type: Input }],
    className: [{ type: Input }],
    actions: [{ type: Input }]
};

const Theme$2 = {
    shortcutCard: {
        container: 'cursor-pointer relative group py-2.5 rounded px-3 gap-1 flex items-center flex-col bg-card-level-1 text-center',
        iconWrapper: 'size-8 p-2 rounded-lg bg-level-5 dark:text-white text-primary',
        text: 'leading-4 max-w-20 mx-auto text-2xs font-medium block',
    },
};

/**
 * ShortcutsComponent
 *
 * Live demo:
 * <example-url>/demo/ds-shortcuts.component.html</example-url>
 */
class DsShortcutsCardComponent {
    constructor(host) {
        this.host = host;
        this.className = '';
        this.click = new EventEmitter();
        this.removed = new EventEmitter();
        this.openIdx = null;
        this.isOpen = false;
        this.theme = Theme$2;
    }
    // Toggle open/close and prevent this click from bubbling up
    onClick(data, event) {
        event.stopPropagation();
        if (data.item.isShortcut) {
            this.isOpen = !this.isOpen;
            this.click.emit(Object.assign({}, data.item, { idx: data.idx }));
        }
    }
    removeShortcut(data, event) {
        event.stopPropagation();
        this.items.splice(data.idx, 1);
        this.removed.emit(data);
    }
    onItemClick(item, idx, event) {
        event.stopPropagation();
        if (!item.isShortcut) {
            this.isOpen = !this.isOpen;
            this.openIdx = idx;
        }
        else {
            this.click.emit({ action: 'navigate', item, idx });
        }
    }
    remove(item, idx, event) {
        event.stopPropagation();
        this.click.emit({ action: 'remove', item, idx });
    }
    selectShortcut(shortcut, idx, event) {
        event.stopPropagation();
        if (this.openIdx === null) {
            return;
        }
        this.click.emit({
            action: 'add',
            shortcut,
            placeholderIdx: this.openIdx,
            idx,
        });
        shortcut.onClick ? shortcut.onClick({ shortcut, idx }) : null;
        this.isOpen = false;
        this.openIdx = null;
    }
    // Listen for clicks anywhere in the document
    onDocumentClick(event) {
        // If the click target is outside this component, close the list
        if (this.isOpen && !this.host.nativeElement.contains(event.target)) {
            this.isOpen = false;
            this.openIdx = null;
        }
    }
}
DsShortcutsCardComponent.decorators = [
    { type: Component, args: [{
                selector: 'ds-shortcuts',
                template: "<div id=\"ds-shortcuts\" class=\"relative flex flex-col gap-2\">\n  <div class=\"grid gap-2 grid-cols-2\" [ngClass]=\"className\">\n    <div\n      *ngFor=\"let item of items; let idx = index\"\n      (click)=\"onItemClick(item, idx, $event)\"\n      class=\"group w-full relative group justify-start py-3 px-2.5 rounded gap-2 flex items-center text-center transition-all ease-in-out duration-500\"\n      [ngClass]=\"item.isShortcut ? 'cursor-pointer bg-level-5 dark:bg-[#171717]' : 'cursor-pointer bg-crame-100'\"\n    >\n      <div\n        class=\"shrink-0 size-[28px] flex transition-all ease-in-out duration-300 justify-center items-center rounded dark:bg-level-6\"\n        [ngClass]=\"[\n          item.isShortcut ? 'bg-card-level-1 text-green-500' : 'bg-card-level-2 text-green-500'\n        ]\"\n      >\n        <ds-icon [id]=\"item.icon\" [size]=\"12\"></ds-icon>\n      </div>\n      <a\n        *ngIf=\"item.isShortcut && item.href; else noLink\"\n        class=\"text-neutral-900 text-left inline-flex text-[0.75rem]/[1rem] font-semibold after:absolute after:inset-0\"\n        [href]=\"item.href\"\n      >\n        {{ item.title }}\n      </a>\n      <ng-template #noLink>\n        <span class=\"text-left inline-flex text-[0.75rem]/[1rem] font-semibold\">\n          {{ item.title }}\n        </span>\n      </ng-template>\n\n      <!-- delete icon -->\n      <button\n        *ngIf=\"item.isShortcut\"\n        (click)=\"remove(item, idx, $event)\"\n        class=\"absolute -top-2 right-2 text-white size-[16px] rounded-full flex justify-center items-center bg-red-500 opacity-0 duration-300 transition-all translate-y-1 group-hover:translate-y-0 ease-in-out group-hover:opacity-100\"\n        aria-label=\"Remove shortcut\"\n      >\n        <ds-icon id=\"minus\" size=\"12\"></ds-icon>\n      </button>\n    </div>\n  </div>\n  <ul\n    *ngIf=\"isOpen && shortcuts\"\n    class=\"absolute z-[1000] top-[calc(100%+8px)] left-0 w-full bg-card-level-5 rounded shadow-dropdown\"\n  >\n    <li\n      tabindex=\"0\"\n      role=\"button\"\n      *ngFor=\"let shortcut of shortcuts; let index = index\"\n      (click)=\"selectShortcut(shortcut, index, $event)\"\n      class=\"flex justify-between items-center gap-2 p-4\"\n      [ngClass]=\"\n        shortcut.isSelected\n          ? 'cursor-not-allowed opacity-50'\n          : 'hover:bg-gray-50 dark:hover:bg-gray-700'\n      \"\n    >\n      <span class=\"text-neutral-900 text-[0.875rem]/[1.125rem] font-bold\">\n        {{ shortcut.title }}\n      </span>\n      <ds-icon\n        [id]=\"shortcut.isSelected ? 'minus' : 'add'\"\n        [size]=\"24\"\n        [className]=\"shortcut.isSelected ? 'text-red-500' : ''\"\n      ></ds-icon>\n    </li>\n  </ul>\n</div>\n"
            }] }
];
/** @nocollapse */
DsShortcutsCardComponent.ctorParameters = () => [
    { type: ElementRef }
];
DsShortcutsCardComponent.propDecorators = {
    items: [{ type: Input }],
    shortcuts: [{ type: Input }],
    className: [{ type: Input }],
    click: [{ type: Output }],
    removed: [{ type: Output }],
    onDocumentClick: [{ type: HostListener, args: ['document:click', ['$event'],] }]
};

/**
 * Filial-cardComponent
 *
 * Live demo:
 * <example-url>/demo/ds-filial-card.component.html</example-url>
 */
class FilialCardComponent {
    constructor() {
        this.className = '';
        this.useImageBorder = false;
        this.setSelected = new EventEmitter();
        this.getFirstTwoLetters = getFirstTwoLetters;
    }
    onClick(event) {
        this.setSelected.emit({ event: event, data: this.data });
    }
}
FilialCardComponent.decorators = [
    { type: Component, args: [{
                selector: 'ds-filial-card',
                template: "<article\n  id=\"ds-filial-card\"\n  (click)=\"onClick($event)\"\n  tabindex=\"0\"\n  role=\"button\"\n  [ngClass]=\"[\n    'group relative border flex items-center justify-start text-custom-black bg-level-3 gap-[14px] border-neutral-50 rounded-lg p-[14px] transition-[shadow_background] duration-300 ease-in-out hover:border-transparent hover:shadow-filial-card hover:bg-level-4',\n    className\n  ]\"\n>\n  <div\n    translate=\"no\"\n    class=\"shrink-0 rounded-md bg-[#e9f4f3] dark:bg-[#245140] text-green-500 dark:text-green-900 size-[82px] font-bold text-[1.75rem]/[1.688rem] flex items-center justify-center\"\n  >\n    {{ getFirstTwoLetters(name) | uppercase }}\n  </div>\n  <h3\n    *ngIf=\"name\"\n    class=\"text-[1.125rem]/[1.688rem] text-neutral-900 font-bold text-left\"\n  >\n    {{ name }}\n  </h3>\n</article>\n"
            }] }
];
FilialCardComponent.propDecorators = {
    icon: [{ type: Input }],
    id: [{ type: Input }],
    sector: [{ type: Input }],
    name: [{ type: Input }],
    className: [{ type: Input }],
    useImageBorder: [{ type: Input }],
    setSelected: [{ type: Output }],
    data: [{ type: Input }]
};

/**
 * Holding-cardComponent
 *
 * Live demo:
 * <example-url>/demo/ds-holding-card.component.html</example-url>
 */
class DsHoldingCardComponent {
    constructor() {
        this.title = '';
        this.href = '';
        this.className = '';
    }
}
DsHoldingCardComponent.decorators = [
    { type: Component, args: [{
                selector: 'ds-holding-card',
                template: "<a\n  id=\"ds-holding-card\"\n  *ngIf=\"href\"\n  [href]=\"href\"\n  class=\"inline-flex items-center gap-x-5 py-[22px] px-[38px] text-center bg-card-level-2 border border-stroke-1 rounded-md cursor-pointer hover:shadow-lg transition-all duration-300 ease-in-out\"\n  [ngClass]=\"[className]\"\n>\n  <div class=\"rounded-full bg-level-4 border border-stroke-1 flex items-center justify-center p-3\">\n    <ds-icon id=\"bank2\" size=\"26\" class=\"text-red-500\"></ds-icon>\n  </div>\n  <h3 *ngIf=\"title\" class=\"text-[1.25rem]/[1.688rem] font-bold\">\n    {{ title }}\n  </h3>\n  <div>\n    <ds-icon id=\"arrow-right-1\" size=\"20\" class=\"text-red-500\"></ds-icon>\n  </div>\n</a>\n\n<div\n  *ngIf=\"!href\"\n  id=\"ds-holding-card\"\n  class=\"inline-flex items-center gap-x-5 py-[22px] px-[38px] text-center bg-card-level-2 border border-stroke-1 rounded-md cursor-pointer hover:shadow-lg transition-all duration-300 ease-in-out\"\n  [ngClass]=\"[className]\"\n>\n  <div class=\"rounded-full bg-level-4 border border-stroke-1 flex items-center justify-center p-3\">\n    <ds-icon id=\"bank2\" size=\"26\" class=\"text-red-500\"></ds-icon>\n  </div>\n  <h3 *ngIf=\"title\" class=\"text-[1.25rem]/[1.688rem] font-bold\">\n    {{ title }}\n  </h3>\n  <div>\n    <ds-icon id=\"arrow-right-1\" size=\"20\" class=\"text-red-500\"></ds-icon>\n  </div>\n</div>\n"
            }] }
];
DsHoldingCardComponent.propDecorators = {
    title: [{ type: Input }],
    href: [{ type: Input }],
    className: [{ type: Input }]
};

/**
 * Inbox-cardComponent
 *
 * Live demo:
 * <example-url>/demo/ds-inbox-card.component.html</example-url>
 */
class InboxCardComponent {
    constructor() {
        this.isRead = false;
        this.onClick = new EventEmitter();
    }
    handleClick(event) {
        this.onClick.emit({ event: event, data: this.data });
    }
}
InboxCardComponent.decorators = [
    { type: Component, args: [{
                selector: 'ds-inbox-card',
                template: "<div\n  id=\"ds-inbox-card\"\n  (click)=\"handleClick($event)\"\n  [ngClass]=\"[\n    'relative flex gap-2 border-l-2 p-3.5 cursor-pointer',\n    !isRead\n      ? 'bg-neutral-50 border-l-red-500'\n      : 'bg-level-4 border-l-transparent'\n  ]\"\n>\n  <a *ngIf=\"link\" [href]=\"link\" class=\"absolute top-0 left-0 w-full h-full\">\n    <span class=\"sr-only\">{{ title }}</span>\n  </a>\n\n  <div\n    class=\"size-[30px] border border-stroke-1 bg-white rounded-full flex items-center justify-center text-primary\"\n  >\n    <ds-icon id=\"Mail\" [size]=\"16\" style=\"width: 16px; height: 16px\"></ds-icon>\n  </div>\n\n  <div class=\"space-y-1.5\">\n    <span\n      *ngIf=\"title\"\n      class=\"text-neutral-900 text-[0.875rem]/[1.125rem] font-semibold\"\n    >\n      {{ title }}\n    </span>\n\n    <p\n      *ngIf=\"content\"\n      class=\"text-neutral-700 text-[0.75rem]/[1rem] font-medium\"\n    >\n      {{ content }}\n    </p>\n\n    <div\n      *ngIf=\"date\"\n      class=\"text-neutral-700 text-[0.625rem]/[0.875rem] font-medium flex items-center gap-2\"\n    >\n      <ds-icon\n        id=\"clock2\"\n        [size]=\"14\"\n        style=\"width: 14px; height: 14px\"\n      ></ds-icon>\n      <span>{{ date }}</span>\n    </div>\n  </div>\n</div>\n"
            }] }
];
InboxCardComponent.propDecorators = {
    id: [{ type: Input }],
    title: [{ type: Input }],
    content: [{ type: Input }],
    date: [{ type: Input }],
    isRead: [{ type: Input }],
    link: [{ type: Input }],
    data: [{ type: Input }],
    onClick: [{ type: Output }]
};

/**
 * Notification-cardComponent
 *
 * Live demo:
 * <example-url>/demo/ds-notification-card.component.html</example-url>
 */
class NotificationCardComponent {
    constructor() {
        this.isRead = false;
        this.onClick = new EventEmitter();
    }
    handleClick(event) {
        this.onClick.emit({ data: this.data, event: event });
    }
}
NotificationCardComponent.decorators = [
    { type: Component, args: [{
                selector: 'ds-notification-card',
                template: "<div\n  id=\"ds-notification-card\"\n  (click)=\"handleClick($event)\"\n  [ngClass]=\"[\n    'relative flex items-start justify-start gap-2 border-l-2 p-3.5 cursor-pointer',\n    !isRead\n      ? 'bg-neutral-25 border-l-red-500'\n      : 'bg-transparent border-l-transparent'\n  ]\"\n>\n  <a *ngIf=\"link\" [href]=\"link\" class=\"absolute top-0 left-0 w-full h-full\">\n    <span class=\"sr-only\">{{ title }}</span>\n  </a>\n  <div *ngIf=\"title || content\" class=\"space-y-1\">\n    <span\n      *ngIf=\"title\"\n      class=\"text-neutral-900 text-[0.875rem] leading-[14px] font-bold\"\n    >\n      {{ title }}\n    </span>\n\n    <p\n      *ngIf=\"content\"\n      class=\"text-neutral-700 text-[0.75rem] leading-[1rem] font-medium line-clamp-2\"\n    >\n      {{ content }}\n    </p>\n  </div>\n\n  <span\n    *ngIf=\"time\"\n    class=\"text-neutral-900 text-[0.625rem] leading-[12px] font-normal absolute top-5 right-3.5\"\n  >\n    {{ time }}\n  </span>\n</div>\n"
            }] }
];
NotificationCardComponent.propDecorators = {
    id: [{ type: Input }],
    title: [{ type: Input }],
    content: [{ type: Input }],
    isRead: [{ type: Input }],
    link: [{ type: Input }],
    time: [{ type: Input }],
    data: [{ type: Input }],
    onClick: [{ type: Output }]
};

/**
 * Ticker-cardComponent
 *
 * Live demo:
 * <example-url>/demo/ds-ticker-card.component.html</example-url>
 */
class TickerCardComponent {
}
TickerCardComponent.decorators = [
    { type: Component, args: [{
                selector: 'ds-ticker-card',
                template: "<div\n  id=\"ds-ticker-card\"\n  class=\"flex items-center justify-center gap-2\"\n  [ngClass]=\"[className]\"\n>\n  <img\n    *ngIf=\"image\"\n    [src]=\"image\"\n    [alt]=\"title\"\n    class=\"size-6 object-cover rounded-full\"\n  />\n  <div class=\"flex flex-col text-[0.75rem]/[1rem]\">\n    <h3 *ngIf=\"title\" class=\"font-bold\">{{ title }}</h3>\n    <span *ngIf=\"price\" class=\"text-neutral-700 inline-block\">{{ price }}</span>\n  </div>\n</div>\n"
            }] }
];
TickerCardComponent.propDecorators = {
    title: [{ type: Input }],
    image: [{ type: Input }],
    price: [{ type: Input }],
    className: [{ type: Input }]
};

/**
 * Currency-converterComponent
 *
 * Live demo:
 * <example-url>/demo/ds-currency-converter.component.html</example-url>
 */
class CurrencyConverterComponent {
    constructor() {
        this.currencies = [];
        /** emits when the number input changes */
        this.valueChange = new EventEmitter();
        /** emits when the currency select changes */
        this.currencyChange = new EventEmitter();
    }
    onInput(e) {
        const num = +e.target.value;
        this.value = num;
        this.valueChange.emit(num);
    }
    onCurrencyChange(newCur) {
        this.currency = newCur.value;
        this.currencyChange.emit(newCur);
    }
}
CurrencyConverterComponent.decorators = [
    { type: Component, args: [{
                selector: 'ds-currency-converter',
                template: "<div\n  id=\"ds-currency-converter\"\n  class=\"w-full flex items-center justify-between bg-stroke-1 py-1.5 rounded-md pl-3.5 pr-2\"\n>\n  <input\n    id=\"currency-converter\"\n    type=\"number\"\n    [value]=\"value\"\n    (input)=\"onInput($event)\"\n    class=\"text-[0.875rem]/[1rem] w-3/5 appearance-none font-bold bg-transparent border-none outline-none\"\n  />\n  <ds-select\n    variant=\"currency\"\n    [items]=\"currencies\"\n    [value]=\"currency\"\n    (valueChange)=\"onCurrencyChange($event)\"\n    [className]=\"' w-2/5 !min-w-fit'\"\n  ></ds-select>\n</div>\n"
            }] }
];
CurrencyConverterComponent.propDecorators = {
    value: [{ type: Input }],
    currency: [{ type: Input }],
    currencies: [{ type: Input }],
    valueChange: [{ type: Output }],
    currencyChange: [{ type: Output }]
};

const positions = {
    topRight: 'top-0 right-10',
    topLeft: 'top-0 left-10',
    bottomRight: 'bottom-0 right-10',
    bottomLeft: 'bottom-0 left-10',
};

/**
 * Profile-dropdownComponent
 *
 * Live demo:
 * <example-url>/demo/ds-profile-dropdown.component.html</example-url>
 */
class ProfileDropdownComponent {
    constructor() {
        this.isOpen = false;
        this.handleOpen = () => (this.isOpen = true);
        this.handleClose = () => (this.isOpen = false);
        //Positions
        this.positions = positions;
    }
}
ProfileDropdownComponent.decorators = [
    { type: Component, args: [{
                selector: 'ds-profile-dropdown',
                template: "<div\n  id=\"ds-profile-dropdown\"\n  [ngClass]=\"['relative overflow-visible z-[10000]', className || '']\"\n>\n  <div tabIndex=\"0\" role=\"button\" (click)=\"handleOpen()\">\n    <ng-content></ng-content>\n  </div>\n\n  <div\n    *ngIf=\"isOpen\"\n    (click)=\"handleClose()\"\n    tabIndex=\"0\"\n    role=\"button\"\n    class=\"fixed inset-0 z-[10001] isolate bg-black/30\"\n  ></div>\n  <ul\n    *ngIf=\"isOpen\"\n    [ngClass]=\"[\n      'absolute flex z-[10002] p-1 border border-neutral-200 flex-col text-custom-black overflow-hidden shadow-dropdown bg-level-4 rounded-lg w-max',\n      positions[position] || '',\n      ulClassName || ''\n    ]\"\n  >\n    <ng-content select=\"[prefix]\"></ng-content>\n    <ng-container class=\"mb-1\" *ngFor=\"let item of list\">\n      <div\n        *ngIf=\"!item?.href\"\n        tabIndex=\"{0}\"\n        role=\"button\"\n        (click)=\"item?.onClick()\"\n        class=\"rounded hover:bg-neutral-50 transition-all duration-300 ease-in-out\"\n      >\n        <li\n          [ngClass]=\"[\n            'inline-flex justify-start items-center gap-3 px-4 py-2.5',\n            item.className || ''\n          ]\"\n        >\n          <ds-icon\n            *ngIf=\"item?.icon\"\n            [id]=\"item?.icon\"\n            class=\"size-4\"\n          ></ds-icon>\n          <span class=\"inline-block text-[0.875rem]/[1rem] font-[400]\">\n            {{ item?.label }}\n          </span>\n        </li>\n      </div>\n\n      <a\n        *ngIf=\"item?.href\"\n        [href]=\"item?.href\"\n        class=\"rounded hover:bg-neutral-50 transition-all duration-300 ease-in-out\"\n      >\n        <li\n          [ngClass]=\"[\n            'inline-flex justify-start items-center gap-3 px-4 py-2.5',\n            item.className || ''\n          ]\"\n        >\n          <ds-icon\n            *ngIf=\"item?.icon\"\n            [id]=\"item?.icon\"\n            class=\"size-4\"\n          ></ds-icon>\n          <span class=\"inline-block text-[0.875rem]/[1rem] font-[400]\">\n            {{ item?.label }}\n          </span>\n        </li>\n      </a>\n    </ng-container>\n    <div class=\"mt-1\">\n      <ng-content select=\"[suffix]\"></ng-content>\n    </div>\n    \n  </ul>\n</div>\n"
            }] }
];
ProfileDropdownComponent.propDecorators = {
    className: [{ type: Input }],
    ulClassName: [{ type: Input }],
    list: [{ type: Input }],
    children: [{ type: Input }],
    position: [{ type: Input }],
    suffix: [{ type: Input }],
    prefix: [{ type: Input }]
};

/**
 * Portfolio-item-cardComponent
 *
 * Live demo:
 * <example-url>/demo/ds-portfolio-item-card.component.html</example-url>
 */
class PortfolioItemCardComponent {
    constructor() {
        this.title = '';
        this.image = '';
        this.isSelected = false;
        this.className = '';
        this.clicked = new EventEmitter();
        this.getFirstTwoLetters = getFirstTwoLetters;
    }
    handleClick() {
        this.clicked.emit();
    }
}
PortfolioItemCardComponent.decorators = [
    { type: Component, args: [{
                selector: 'ds-portfolio-item-card',
                template: "<div\n  id=\"ds-portfolio-item-card\"\n  class=\"group relative border flex justify-start items-center gap-2 p-3 rounded cursor-pointer bg-card-level-2 transition-all duration-200 ease-in-out\"\n  [ngClass]=\"isSelected ? 'border-red-300' : 'border-stroke-1'\"\n  (click)=\"handleClick()\"\n>\n  <div\n    class=\"absolute right-2 top-2 border flex justify-center items-center rounded-full overflow-hidden size-2.5 shrink-0 transition-opacity ease-in-out duration-300\"\n    [ngClass]=\"isSelected ? 'border-red-300' : 'border-level-6'\"\n  >\n    <span\n      [ngClass]=\"isSelected ? 'bg-red-500' : 'bg-transparent'\"\n      class=\"inline-block rounded-full size-1\"\n    ></span>\n  </div>\n\n  <div\n    translate=\"no\"\n    class=\"shrink-0 rounded-md bg-[#e9f4f3] dark:bg-[#245140] text-green-500 dark:text-green-900 size-[40px] font-bold text-[1rem]/[1.688rem] flex items-center justify-center\"\n  >\n    {{ getFirstTwoLetters(title) | uppercase }}\n  </div>\n\n  <h3 *ngIf=\"title\" class=\"text-[0.875rem]/[1rem] text-left font-bold\">\n    {{ title }}\n  </h3>\n</div>\n"
            }] }
];
PortfolioItemCardComponent.propDecorators = {
    title: [{ type: Input }],
    image: [{ type: Input }],
    isSelected: [{ type: Input }],
    className: [{ type: Input }],
    clicked: [{ type: Output }]
};

/**
 * Portfolio-select-cardComponent
 *
 * Live demo:
 * <example-url>/demo/ds-portfolio-select-card.component.html</example-url>
 */
class PortfolioSelectCardComponent {
    constructor() {
        this.title = '';
        this.reference = '';
        this.image = '';
        this.isOpen = false;
        this.className = '';
        this.clicked = new EventEmitter();
        this.getFirstTwoLetters = getFirstTwoLetters;
    }
    handleClick() {
        this.clicked.emit();
    }
}
PortfolioSelectCardComponent.decorators = [
    { type: Component, args: [{
                selector: 'ds-portfolio-select-card',
                template: "<div\n  id=\"ds-portfolio-select-card\"\n  class=\"flex justify-start items-center gap-4 p-2 rounded cursor-pointer bg-card-level-2\"\n  (click)=\"handleClick(); $event.stopPropagation()\"\n  [ngClass]=\"[className]\"\n>\n  <div\n    translate=\"no\"\n    class=\"shrink-0 rounded-md bg-[#e9f4f3] dark:bg-[#245140] text-green-500 dark:text-green-900 size-[40px] font-bold text-[1rem]/[1.688rem] flex items-center justify-center\"\n  >\n    {{ getFirstTwoLetters(title) | uppercase }}\n  </div>\n  <div\n    class=\"w-full text-neutral-900 space-y-1\"\n    [ngClass]=\"[!reference ? 'flex justify-between items-center' : '']\"\n  >\n    <h3 *ngIf=\"title\" class=\"text-[0.875rem]/[1rem] font-bold mr-5\">\n      {{ title }}\n    </h3>\n    <ds-icon\n      *ngIf=\"!reference\"\n      id=\"arrow-up\"\n      [class]=\"[\n        'transition-all duration-300 ease-in-out ',\n        !isOpen ? 'rotate-180' : ''\n      ]\"\n      size=\"12px\"\n    ></ds-icon>\n\n    <div\n      *ngIf=\"reference\"\n      class=\"w-full flex justify-between items-center gap-x-2\"\n    >\n      <p class=\"text-[0.75rem]/[0.875rem]\">\n        {{ reference }}\n      </p>\n      <!-- <ds-icon [id]=\"isOpen ? 'arrow-down' : 'arrow-up'\" size=\"12px\"></ds-icon> -->\n      <ds-icon\n        id=\"arrow-up\"\n        [class]=\"[\n          'transition-all duration-300 ease-in-out ',\n          !isOpen ? 'rotate-180' : ''\n        ]\"\n        size=\"12px\"\n      ></ds-icon>\n    </div>\n  </div>\n</div>\n"
            }] }
];
PortfolioSelectCardComponent.propDecorators = {
    title: [{ type: Input }],
    reference: [{ type: Input }],
    image: [{ type: Input }],
    isOpen: [{ type: Input }],
    className: [{ type: Input }],
    clicked: [{ type: Output }]
};

/**
 * Portfolio-vision-cardComponent
 *
 * Live demo:
 * <example-url>/demo/ds-portfolio-vision-card.component.html</example-url>
 */
class PortfolioVisionCardComponent {
    constructor() {
        this.title = '';
        this.image = '';
        this.isSelected = false;
        this.className = '';
        this.clicked = new EventEmitter();
        this.getFirstTwoLetters = getFirstTwoLetters;
    }
    handleClick() {
        this.clicked.emit();
    }
}
PortfolioVisionCardComponent.decorators = [
    { type: Component, args: [{
                selector: 'ds-portfolio-vision-card',
                template: "<div\n  id=\"ds-portfolio-vision-card\"\n  class=\"group relative border border-stroke-1 flex justify-start items-center gap-2.5 p-3 rounded-[4px] cursor-pointer bg-card-level-2 transition-all duration-200 ease-in-out\"\n  (click)=\"handleClick()\"\n  [ngClass]=\"className\"\n>\n  <div\n    class=\"group-hover:opacity-100 opacity-0 absolute right-2 top-2 border !border-primary dark:!border-primary-600 flex justify-center items-center rounded-full overflow-hidden size-2.5 shrink-0 transition-opacity ease-in-out duration-300\"\n    [ngClass]=\"isSelected ? 'opacity-100' : ''\"\n  >\n    <span\n      class=\"inline-block !bg-primary dark:!border-primary-600 rounded-full size-1\"\n    ></span>\n  </div>\n\n  <div\n    translate=\"no\"\n    class=\"shrink-0 rounded-md bg-[#e9f4f3] dark:bg-[#245140] text-green-500 dark:text-green-900 size-[90px] font-bold text-[1.5rem]/[1.688rem] flex items-center justify-center\"\n  >\n    {{ getFirstTwoLetters(title) | uppercase }}\n  </div>\n\n  <h3 *ngIf=\"title\" class=\"text-[0.875rem]/[1rem] text-left font-bold\">\n    {{ title }}\n  </h3>\n</div>\n"
            }] }
];
PortfolioVisionCardComponent.propDecorators = {
    title: [{ type: Input }],
    image: [{ type: Input }],
    isSelected: [{ type: Input }],
    className: [{ type: Input }],
    clicked: [{ type: Output }]
};

/**
 * Sheet-latest-opsComponent
 *
 * Live demo:
 * <example-url>/demo/ds-sheet-latest-ops.component.html</example-url>
 */
class SheetLatestOpsComponent {
    constructor() {
        this.isDiscrete = false;
        this.title = '';
        this.className = '';
    }
}
SheetLatestOpsComponent.decorators = [
    { type: Component, args: [{
                selector: 'ds-sheet-latest-ops',
                template: "<div\n  id=\"ds-sheet-latest-ops\"\n  class=\"bg-level-3 flex flex-col gap-2 py-3 px-3.5 rounded\"\n  [ngClass]=\"className\"\n>\n  <div class=\"flex items-center justify-between gap-2\">\n    <h3 class=\"text-[0.875rem]/[1rem] font-bold text-neutral-900\">\n      {{ title }}\n    </h3>\n\n    <ds-display-value [value]=\"price\">\n      <ds-balance-formatter\n        *ngIf=\"price\"\n        [isDiscrete]=\"isDiscrete\"\n        [balance]=\"price\"\n        [currency]=\"currency\"\n        class=\"text-[0.875rem]/[1rem] font-bold\"\n        currencyClassName=\"text-[0.875rem]/[1rem]\"\n      ></ds-balance-formatter>\n    </ds-display-value>\n  </div>\n  <div class=\"flex items-center justify-between gap-2\">\n    <div class=\"flex flex-col gap-y-0.5 font-normal\">\n      <span class=\"text-neutral-500 text-[0.875rem]/[1rem]\"> Date valeur </span>\n      <ds-display-value [value]=\"dateOperation\">\n        <p class=\"text-neutral-900 font-bold text-[0.875rem]/[1rem]\">\n          {{ dateValue }}\n        </p>\n      </ds-display-value>\n    </div>\n\n    <div class=\"flex flex-col gap-y-0.5 font-normal\">\n      <span class=\"text-neutral-500 text-[0.875rem]/[1rem]\"> Date op\u00E9ration </span>\n      <ds-display-value [value]=\"dateOperation\">\n        <p class=\"text-neutral-900 font-bold text-[0.875rem]/[1rem]\">\n          {{ dateOperation }}\n        </p>\n      </ds-display-value>\n    </div>\n  </div>\n</div>\n"
            }] }
];
SheetLatestOpsComponent.propDecorators = {
    isDiscrete: [{ type: Input }],
    title: [{ type: Input }],
    currency: [{ type: Input }],
    price: [{ type: Input }],
    dateOperation: [{ type: Input }],
    dateValue: [{ type: Input }],
    className: [{ type: Input }]
};

const TableThemes = {
    default: {
        table: 'w-full text-left border-spacing-y-1 border-separate',
        header: 'bg-level-5 sticky top-0 z-10',
        headerCell: 'px-4 py-1.5 font-normal',
        headerTh: 'inline-flex items-center my-auto gap-1',
        headerText: 'inline-flex text-[0.875rem]/[1.25rem]',
        headerIcons: 'inline-flex items-center text-gray-500',
        headerCellButton: 'w-fit',
        headerCellSortable: ' select-none',
        body: '',
        row: () => 'bg-level-5',
        cell: 'px-4 text-[1rem]/normal font-medium py-2',
    },
    secondary: {
        table: 'w-full text-left rounded-lg border-separate border-spacing-0',
        header: 'bg-neutral-25 rounded-t-lg sticky top-0 z-10',
        headerIcons: 'inline-flex items-center text-gray-500',
        headerText: 'inline-flex text-[0.875rem]/[1.125rem]',
        headerCell: 'px-4 py-1.5 text-sm font-normal',
        headerTh: 'inline-flex items-center gap-1 text-[0.875rem]/[1.125rem]',
        headerCellButton: 'w-fit',
        headerCellSortable: ' select-none',
        body: '',
        row: () => 'bg-level-3',
        cell: 'px-4 text-sm py-2.5 whitespace-nowrap',
    },
    bordered: {
        table: 'w-full text-left border-collapse border',
        header: 'bg-gray-100 border-b sticky top-0 z-10',
        headerCell: 'px-4 py-2 border-r',
        headerTh: 'inline-flex items-center gap-1 text-[0.875rem]/[1.25rem]',
        headerIcons: 'inline-flex items-center text-gray-500',
        headerText: 'inline-flex text-[0.875rem]/[1.25rem]',
        headerCellButton: 'w-fit',
        headerCellSortable: ' select-none',
        body: '',
        row: () => '',
        cell: 'px-4 py-2 border-r border-b',
    },
};

/**
 * TableComponent
 *
 * Live demo:
 * <example-url>/demo/ds-table.component.html</example-url>
 */
class TableComponent {
    constructor() {
        this.data = [];
        this.columns = [];
        this.variant = 'default';
        this.remoteSort = false;
        this.selectionEnabled = false;
        this.selectionMode = 'multi';
        this.expandableRows = false;
        this.sortChange = new EventEmitter();
        this.isOverflowing = false;
        this.isOnLeft = true;
        this.isOnRight = false;
        this.selectionChange = new EventEmitter();
        this.selectedRows = new Set();
        this.selectedRowId = null; // For single selection mode
        this.expandedRows = new Set();
        this.displayData = [];
        this.originalData = [];
        this.sortColumn = null;
        this.sortDirection = 'asc';
        this.theme = TableThemes;
        this.headerCheckboxChange = () => {
            const isChecked = this.isSomeSelected || this.isAllSelected;
            this.toggleSelectAll(!isChecked);
        };
    }
    ngOnInit() {
        this.columns = this.columns.map((col) => (Object.assign({}, col, { truncate: col.expandable ? true : false })));
        this.selectedRows.clear();
        const preselectedData = this.data.filter((row) => row.isSelected === true);
        if (preselectedData.length > 0) {
            preselectedData.forEach((row) => this.selectedRows.add(row));
        }
    }
    ngOnChanges(changes) {
        if (changes.data && changes.data.currentValue) {
            this.originalData = this.data.concat();
            this.displayData = this.data.concat();
            this.sortColumn = null;
            this.selectedRows.clear();
        }
    }
    onSelect(row) {
        this.selectedRowId = row.id;
        this.selectionChange.emit(row);
    }
    ngAfterViewInit() {
        this.checkTableOverflow();
        this.resizeListener = () => this.checkTableOverflow();
        window.addEventListener('resize', this.resizeListener);
        // Add scroll event listener to the container
        if (this.tableContainer) {
            this.scrollListener = () => this.checkTableOverflow();
            this.tableContainer.nativeElement.addEventListener('scroll', this.scrollListener);
        }
    }
    ngOnDestroy() {
        if (this.resizeListener) {
            window.removeEventListener('resize', this.resizeListener);
        }
        if (this.scrollListener && this.tableContainer) {
            this.tableContainer.nativeElement.removeEventListener('scroll', this.scrollListener);
        }
    }
    toggleTruncateData(col) {
        if (!col.expandable) {
            return;
        }
        col.truncate = !col.truncate;
    }
    onSort(col) {
        if (this.sortColumn === col.accessor) {
            if (this.sortDirection === 'asc') {
                this.sortDirection = 'desc';
            }
            else {
                this.sortColumn = null;
                this.sortDirection = undefined;
            }
        }
        else {
            this.sortColumn = col.accessor;
            this.sortDirection = 'asc';
        }
        const payload = {
            accessor: this.sortColumn,
            direction: this.sortDirection,
        };
        if (this.remoteSort) {
            this.sortChange.emit(payload);
            return;
        }
        if (!this.sortColumn) {
            this.displayData = this.originalData.concat();
            this.sortChange.emit(payload);
            return;
        }
        this.displayData.sort((a, b) => {
            const aVal = a[this.sortColumn];
            const bVal = b[this.sortColumn];
            if (aVal == null)
                return 1;
            if (bVal == null)
                return -1;
            if (typeof aVal === 'number' && typeof bVal === 'number') {
                return this.sortDirection === 'asc' ? aVal - bVal : bVal - aVal;
            }
            const aStr = String(aVal).toLowerCase();
            const bStr = String(bVal).toLowerCase();
            if (aStr > bStr)
                return this.sortDirection === 'asc' ? 1 : -1;
            if (aStr < bStr)
                return this.sortDirection === 'asc' ? -1 : 1;
            return 0;
        });
        this.sortChange.emit(payload);
    }
    get isAllSelected() {
        return (this.displayData.length > 0 &&
            this.displayData.every((row) => this.selectedRows.has(row)));
    }
    get isSomeSelected() {
        return (this.selectedRows.size > 0 &&
            this.selectedRows.size < this.displayData.length);
    }
    get isIndeterminate() {
        const n = this.selectedRows.size;
        return n > 0 && n < this.displayData.length;
    }
    isAllUnselectable() {
        return this.displayData.every((row) => row.isSelectable === false);
    }
    toggleSelectAll(checked) {
        if (checked) {
            this.displayData.forEach((row) => {
                if (row.isSelectable !== false) {
                    this.selectedRows.add(row);
                }
            });
        }
        else {
            this.selectedRows.clear();
        }
        this.emitSelection();
    }
    toggleRow(row, checked) {
        if (checked) {
            this.selectedRows.add(row);
        }
        else {
            this.selectedRows.delete(row);
        }
        this.emitSelection();
    }
    isSelected(row) {
        return this.selectedRows.has(row);
    }
    emitSelection() {
        this.selectionChange.emit(Array.from(this.selectedRows));
    }
    getRowCheckboxChange(row) {
        return () => this.toggleRow(row, !this.isSelected(row));
    }
    toggleRowExpand(row) {
        if (!this.expandableRows)
            return;
        if (this.expandedRows.has(row)) {
            this.expandedRows.delete(row);
        }
        else {
            this.expandedRows.add(row);
        }
        this.expandedRows = new Set(this.expandedRows);
    }
    isRowExpanded(row) {
        return this.expandedRows.has(row);
    }
    get expandableColspan() {
        return (this.expandableRows ? 1 : 0) + (this.selectionEnabled ? 1 : 0) + this.columns.length;
    }
    getAllLines(text, col) {
        if (text == null)
            return [''];
        const textStr = String(text);
        if (col.truncate) {
            return textStr.split('\n').slice(0, 1);
        }
        return textStr.split('\n');
    }
    checkTableOverflow() {
        if (!this.tableContainer || !this.tableElement) {
            return;
        }
        const container = this.tableContainer.nativeElement;
        const table = this.tableElement.nativeElement;
        const isOverflowing = table.getBoundingClientRect().width >
            container.getBoundingClientRect().width;
        if (isOverflowing) {
            this.isOverflowing = true;
        }
        else {
            this.isOverflowing = false;
        }
        const scrollLeft = container.scrollLeft;
        const maxScrollLeft = container.scrollWidth - container.clientWidth;
        if (scrollLeft === 0) {
            this.isOnLeft = true;
            this.isOnRight = false;
        }
        else if (Math.ceil(scrollLeft) >= maxScrollLeft) {
            this.isOnRight = true;
            this.isOnLeft = false;
        }
        else {
            this.isOnRight = true;
            this.isOnLeft = true;
        }
    }
}
TableComponent.decorators = [
    { type: Component, args: [{
                selector: 'ds-table',
                template: "<div\n  class=\"relative w-full h-full overflow-hidden\"\n  [ngClass]=\"\n    variant === 'secondary' ? 'border border-neutral-50 rounded-lg' : ''\n  \"\n>\n  <div\n    #tableContainer\n    [ngClass]=\"[className || 'h-full', 'overflow-x-auto w-full']\"\n  >\n    <div id=\"isOverflowing\" *ngIf=\"isOverflowing\" class=\"pointer-events-none\">\n      <div\n        *ngIf=\"isOnRight\"\n        class=\"absolute top-0 left-0 w-20 h-full bg-gradient-to-r from-white to-transparent z-[100]\"\n      ></div>\n      <div\n        *ngIf=\"isOnLeft\"\n        class=\"absolute top-0 right-0 w-20 h-full bg-gradient-to-l from-white to-transparent z-[100]\"\n      ></div>\n    </div>\n    <table #tableElement id=\"ds-table\" [ngClass]=\"theme[variant].table\">\n      <thead [ngClass]=\"theme[variant].header\">\n        <tr class=\"overflow-hidden\">\n          <!-- 1) HEADER ds-checkbox -->\n          <th\n            *ngIf=\"selectionEnabled\"\n            [ngClass]=\"[\n              theme[variant].headerCell,\n              'w-[30px]',\n              variant === 'default' ? 'rounded-l-md' : '',\n              variant === 'secondary' ? 'rounded-tl-lg' : ''\n            ]\"\n          >\n            <ds-checkbox\n              *ngIf=\"selectionMode === 'multi'\"\n              [checked]=\"isAllSelected || isSomeSelected\"\n              [isIndeterminate]=\"isSomeSelected && !isAllSelected\"\n              [disabled]=\"displayData.length === 0 || isAllUnselectable()\"\n              [change]=\"headerCheckboxChange\"\n            ></ds-checkbox>\n          </th>\n\n          <th\n            *ngFor=\"let col of columns; let idx = index\"\n            [ngClass]=\"[\n              theme[variant].headerCell,\n              !col.sortable ? 'pb-2.5 pt-1.5' : 'py-2.5',\n              idx === 0 && variant === 'default' && !selectionEnabled\n                ? 'rounded-l-md'\n                : '',\n              columns.length - 1 === idx && variant === 'default'\n                ? 'rounded-r-md'\n                : ''\n            ]\"\n            [ngStyle]=\"col.style\"\n          >\n            <span\n              *ngIf=\"!col.sortable\"\n              [ngClass]=\"[\n                theme[variant].headerTh,\n                col.expandable ? 'flex justify-between items-center w-full' : ''\n              ]\"\n            >\n              <span [ngClass]=\"[theme[variant].headerText]\">\n                {{ col.header }}\n              </span>\n              <button\n                (click)=\"toggleTruncateData(col)\"\n                [ngClass]=\"[col.truncate ? 'text-green-500' : 'text-red-500']\"\n                *ngIf=\"col.expandable\"\n              >\n                <ds-icon\n                  [id]=\"col.truncate ? 'plus' : 'minus'\"\n                  size=\"16\"\n                ></ds-icon>\n              </button>\n            </span>\n            <button\n              *ngIf=\"col.sortable\"\n              [ngClass]=\"[\n                theme[variant].headerCellButton,\n                col.expandable ? 'flex justify-between items-center w-full' : ''\n              ]\"\n            >\n              <span\n                (click)=\"col.sortable && onSort(col)\"\n                [ngClass]=\"[theme[variant].headerTh]\"\n              >\n                <span [ngClass]=\"[theme[variant].headerIcons]\">\n                  <!-- default \u201Cno sort\u201D icon -->\n                  <ds-icon\n                    *ngIf=\"col.sortable && sortColumn !== col.accessor\"\n                    id=\"filter-up-down\"\n                    size=\"12\"\n                  ></ds-icon>\n\n                  <!-- asc / desc icons -->\n                  <ng-container *ngIf=\"sortColumn === col.accessor\">\n                    <ds-icon\n                      *ngIf=\"sortDirection === 'asc'\"\n                      id=\"filter-up\"\n                      size=\"12\"\n                    ></ds-icon>\n                    <ds-icon\n                      *ngIf=\"sortDirection === 'desc'\"\n                      id=\"filter-down\"\n                      size=\"12\"\n                    ></ds-icon>\n                  </ng-container>\n                </span>\n                <span [ngClass]=\"[theme[variant].headerText]\">\n                  {{ col.header }}\n                </span>\n              </span>\n              <button\n                (click)=\"toggleTruncateData(col)\"\n                [ngClass]=\"[col.truncate ? 'text-green-500' : 'text-red-500']\"\n                *ngIf=\"col.expandable\"\n              >\n                <ds-icon\n                  [id]=\"col.truncate ? 'plus' : 'minus'\"\n                  size=\"16\"\n                ></ds-icon>\n              </button>\n            </button>\n          </th>\n        </tr>\n      </thead>\n      <tbody [ngClass]=\"theme[variant].body\">\n        <ng-container *ngFor=\"let row of displayData; let i = index\">\n          <tr [ngClass]=\"theme[variant].row(i)\">\n            <!-- ROW ds-checkbox -->\n            <td\n              *ngIf=\"selectionEnabled && selectionMode === 'multi'\"\n              [ngClass]=\"[\n                theme[variant].headerCell,\n                'w-[30px]',\n                variant === 'default' ? 'rounded-l-md' : '',\n                variant === 'secondary' ? 'rounded-tl-lg' : ''\n              ]\"\n            >\n              <ds-checkbox\n                [checked]=\"isSelected(row)\"\n                [change]=\"getRowCheckboxChange(row)\"\n                [disabled]=\"row.isSelectable === false\"\n              ></ds-checkbox>\n            </td>\n            <td\n              *ngIf=\"selectionEnabled && selectionMode === 'single'\"\n              [ngClass]=\"[\n                theme[variant].headerCell,\n                'w-[30px]',\n                variant === 'default' ? 'rounded-l-md' : '',\n                variant === 'secondary' ? 'rounded-tl-lg' : ''\n              ]\"\n            >\n              <ds-radio\n                name=\"selection\"\n                [value]=\"row.id\"\n                [(modelValue)]=\"selectedRowId\"\n                (change)=\"onSelect(row)\"\n              ></ds-radio>\n            </td>\n            <td\n              *ngFor=\"let col of columns; let colIdx = index\"\n              [ngClass]=\"[\n                theme[variant].cell,\n                col.expandable && col.truncate\n                  ? 'whitespace-nowrap'\n                  : 'whitespace-nowrap',\n                colIdx === 0 && variant === 'default' && !selectionEnabled\n                  ? 'rounded-l-md'\n                  : '',\n                columns.length - 1 === colIdx && variant === 'default'\n                  ? 'rounded-r-md'\n                  : ''\n              ]\"\n              [style]=\"col.style\"\n            >\n              <div\n                [ngClass]=\"[\n                  colIdx === columns.length - 1 && expandableRows\n                    ? 'flex items-center justify-end'\n                    : ''\n                ]\"\n              >\n                <ng-container\n                  *ngIf=\"col.cellTemplate; else defaultCell\"\n                  [ngTemplateOutlet]=\"col.cellTemplate\"\n                  [ngTemplateOutletContext]=\"{\n                    $implicit: row[col.accessor],\n                    row: row\n                  }\"\n                ></ng-container>\n                <ng-template #defaultCell>\n                  <div class=\"flex flex-col\">\n                    <span\n                      *ngFor=\"let line of getAllLines(row[col.accessor], col)\"\n                      class=\"whitespace-nowrap\"\n                    >\n                      {{ line }}\n                    </span>\n                  </div>\n                </ng-template>\n                <button\n                  *ngIf=\"colIdx === columns.length - 1 && expandableRows\"\n                  type=\"button\"\n                  (click)=\"toggleRowExpand(row)\"\n                  class=\"ml-3.5 p-0.5 inline-flex items-center justify-center\"\n                  [attr.aria-expanded]=\"isRowExpanded(row)\"\n                >\n                  <ds-icon\n                    [id]=\"isRowExpanded(row) ? 'arrow-up' : 'arrow-down'\"\n                    size=\"16\"\n                  ></ds-icon>\n                </button>\n              </div>\n            </td>\n          </tr>\n          <!-- Expanded row detail -->\n          <tr\n            *ngIf=\"expandableRows && isRowExpanded(row)\"\n            [ngClass]=\"\"\n            class=\"bg-[#F9FAFB]\"\n          >\n            <td\n              [attr.colspan]=\"expandableColspan\"\n              [ngClass]=\"[theme[variant].cell, 'align-top']\"\n              class=\"!py-3\"\n            >\n              <ng-container\n                *ngIf=\"expandedRowTemplate\"\n                [ngTemplateOutlet]=\"expandedRowTemplate\"\n                [ngTemplateOutletContext]=\"{ $implicit: row, row: row }\"\n              ></ng-container>\n              <ng-container *ngIf=\"!expandedRowTemplate\">\n                <pre\n                  class=\"text-sm text-neutral-70 m-0 p-2 bg-level-5 rounded-md overflow-auto\"\n                  >{{ row | json }}</pre\n                >\n              </ng-container>\n            </td>\n          </tr>\n        </ng-container>\n      </tbody>\n    </table>\n  </div>\n</div>\n"
            }] }
];
TableComponent.propDecorators = {
    data: [{ type: Input }],
    columns: [{ type: Input }],
    variant: [{ type: Input }],
    remoteSort: [{ type: Input }],
    selectionEnabled: [{ type: Input }],
    selectionMode: [{ type: Input }],
    expandableRows: [{ type: Input }],
    expandedRowTemplate: [{ type: Input }],
    className: [{ type: Input }],
    sortChange: [{ type: Output }],
    selectionChange: [{ type: Output }],
    tableContainer: [{ type: ViewChild, args: ['tableContainer',] }],
    tableElement: [{ type: ViewChild, args: ['tableElement',] }]
};

/**
 * Invoice-cardComponent
 *
 * Live demo:
 * <example-url>/demo/ds-invoice-card.component.html</example-url>
 */
class InvoiceCardComponent {
    constructor(elementRef, cdr) {
        this.elementRef = elementRef;
        this.cdr = cdr;
        this.items = [];
        this.actions = [];
        this.id = '';
        this.href = '';
        this.title = '';
        this.image = '';
        this.className = '';
        this.onClick = new EventEmitter();
        this.isDropdownOpen = false;
        this.dropdownOpenUp = false;
        this.searchInput = "";
    }
    getFiltredValues() {
        if (this.searchInput === "")
            return this.items;
        const filteredItems = this.items.filter((item) => {
            return item.label.toLowerCase().includes(this.searchInput.toLowerCase());
        });
        console.log(filteredItems);
        return filteredItems;
    }
    onDocumentClick(event) {
        if (this.isDropdownOpen &&
            this.elementRef.nativeElement &&
            !this.elementRef.nativeElement.contains(event.target)) {
            this.closeDropdown();
        }
    }
    toggleDropdown(event) {
        event.stopPropagation();
        this.isDropdownOpen = !this.isDropdownOpen;
        if (this.isDropdownOpen) {
            this.dropdownOpenUp = false;
            this.cdr.detectChanges();
            setTimeout(() => this.updateDropdownPosition(), 0);
        }
    }
    updateDropdownPosition() {
        if (!this.dropdownTrigger.nativeElement || !this.dropdownMenu.nativeElement) {
            return;
        }
        const triggerRect = this.dropdownTrigger.nativeElement.getBoundingClientRect();
        const menuRect = this.dropdownMenu.nativeElement.getBoundingClientRect();
        const viewportHeight = window.innerHeight;
        const spaceBelow = viewportHeight - triggerRect.bottom;
        if (spaceBelow < menuRect.height && triggerRect.top >= menuRect.height) {
            this.dropdownOpenUp = true;
            this.cdr.detectChanges();
        }
    }
    closeDropdown() {
        this.isDropdownOpen = false;
    }
    onDropdownItemClick(event, item) {
        event.stopPropagation();
        if (item.onClick) {
            item.onClick({ event, data: this.data });
        }
        this.closeDropdown();
    }
    onClickHandler(event) {
        this.onClick.emit({
            event,
            data: this.data,
        });
    }
    ngOnInit() {
        this.actions = this.actions.map((action) => (Object.assign({}, action, { onClick: (event) => action.onClick &&
                action.onClick({
                    event,
                    data: this.data,
                }) })));
        this.items = this.items.map((item) => (Object.assign({}, item, { onClick: (event) => item.onClick &&
                item.onClick({
                    event,
                    data: this.data,
                }) })));
    }
}
InvoiceCardComponent.decorators = [
    { type: Component, args: [{
                selector: 'ds-invoice-card',
                template: "<a\n  *ngIf=\"href\"\n  [href]=\"href\"\n  (click)=\"onClickHandler($event)\"\n  id=\"ds-invoice-card\"\n  [ngClass]=\"className\"\n  class=\"bg-level-4 rounded-lg text-neutral-900 flex flex-row gap-3 p-3\"\n>\n  <ng-container *ngTemplateOutlet=\"cardTemplate\"></ng-container>\n</a>\n<div\n  *ngIf=\"!href\"\n  id=\"ds-invoice-card\"\n  [ngClass]=\"className\"\n  class=\"bg-level-4 rounded-lg text-neutral-900 flex flex-row gap-3 p-3 cursor-pointer\"\n  (click)=\"onClickHandler($event)\"\n>\n  <ng-container *ngTemplateOutlet=\"cardTemplate\"></ng-container>\n</div>\n\n<ng-template #cardTemplate>\n  <div\n    class=\"relative shrink-0 w-[104px] h-[64px] object-contain py-2 px-4 border border-stroke-1 rounded\"\n  >\n    <img\n      [src]=\"image\"\n      [alt]=\"title\"\n      class=\"top-0 left-0 shrink-0 w-full h-full rounded object-contain\"\n    />\n  </div>\n  <div class=\"w-full flex justify-between flex-col gap-x-2 gap-y-3\">\n    <h3 class=\"text-[0.75rem]/[1.25rem] font-bold mr-4\">\n      {{ title }}\n    </h3>\n    <div\n      *ngIf=\"(items && items.length <= 0) || (actions && actions.length <= 0)\"\n      class=\"flex gap-x-2 items-center w-fit ml-auto\"\n    >\n      <ds-call-to-action-icons\n        *ngIf=\"actions && actions.length > 0\"\n        [actions]=\"actions\"\n        className=\"w-fit\"\n        variant=\"borderless\"\n      ></ds-call-to-action-icons>\n      <span\n        *ngIf=\"actions && actions.length > 0\"\n        class=\"inline-block h-1/2 w-px bg-neutral-200\"\n      ></span>\n\n      <ds-icon\n        *ngIf=\"!items || items.length <= 0\"\n        id=\"arrow-right-1\"\n        class=\"self-end justify-self-end text-red-500\"\n      ></ds-icon>\n      <div\n        *ngIf=\"!href && items && items.length > 0\"\n        class=\"self-end justify-self-end relative\"\n        (click)=\"$event.stopPropagation()\"\n      >\n        <button\n          #dropdownTrigger\n          type=\"button\"\n          (click)=\"toggleDropdown($event)\"\n          class=\"flex items-center justify-center size-[16px] focus:outline-none focus:border-none text-red-500\"\n          [attr.aria-expanded]=\"isDropdownOpen\"\n          [attr.aria-haspopup]=\"true\"\n        >\n          <ds-icon id=\"arrow-down\" class=\"text-red-500\"></ds-icon>\n        </button>\n        <div\n          #dropdownMenu\n          *ngIf=\"isDropdownOpen\"\n          class=\"absolute right-0 min-w-[280px] max-h-[280px] flex flex-col overflow-hidden p-1 rounded-md border border-neutral-100 bg-level-4 text-neutral-900 shadow-dropdown focus:outline-none z-[10000]\"\n          [ngClass]=\"dropdownOpenUp ? 'bottom-full mb-1' : 'top-full mt-1'\"\n          role=\"menu\"\n          [style.visibility]=\"isDropdownOpen ? 'visible' : 'hidden'\"\n        >\n          <ds-input\n            [placeholder]=\"'Rechercher'\"\n            [(ngModel)]=\"searchInput\"\n            autoComplete=\"off\"\n            class=\"shrink-0\"\n          >\n            <ds-icon prefix id=\"search1\" class=\"text-black\"></ds-icon>\n          </ds-input>\n          <div class=\"mt-2 flex-1 min-h-0 overflow-y-auto\">\n            <button\n              *ngFor=\"let item of getFiltredValues()\"\n              role=\"menuitem\"\n              (click)=\"onDropdownItemClick($event, item)\"\n              class=\"group whitespace-nowrap flex justify-between gap-2 w-full items-center rounded-md p-3 hover:bg-neutral-50 text-[0.875rem]/normal font-[400]\"\n            >\n              <div class=\"flex items-center gap-2\">\n                <ds-icon\n                  *ngIf=\"item.icon\"\n                  [id]=\"item.icon\"\n                  class=\"text-heading shrink-0 h-5 w-5 font-semibold\"\n                ></ds-icon>\n                <span class=\"font-semibold\">{{ item.label }}</span>\n              </div>\n              <ds-icon\n                id=\"arrow-right-1\"\n                class=\"invisible group-hover:visible cursor-pointer ml-auto text-red-500\"\n              ></ds-icon>\n            </button>\n          </div>\n        </div>\n      </div>\n    </div>\n  </div>\n</ng-template>\n"
            }] }
];
/** @nocollapse */
InvoiceCardComponent.ctorParameters = () => [
    { type: ElementRef },
    { type: ChangeDetectorRef }
];
InvoiceCardComponent.propDecorators = {
    items: [{ type: Input }],
    actions: [{ type: Input }],
    id: [{ type: Input }],
    href: [{ type: Input }],
    title: [{ type: Input }],
    image: [{ type: Input }],
    className: [{ type: Input }],
    data: [{ type: Input }],
    onClick: [{ type: Output }],
    dropdownTrigger: [{ type: ViewChild, args: ['dropdownTrigger',] }],
    dropdownMenu: [{ type: ViewChild, args: ['dropdownMenu',] }],
    onDocumentClick: [{ type: HostListener, args: ['document:click', ['$event'],] }]
};

/**
 * Payment-cardComponent
 *
 * Live demo:
 * <example-url>/demo/ds-payment-card.component.html</example-url>
 */
class PaymentCardComponent {
    constructor() {
        this.title = '';
        this.image = '';
        this.price = 0;
        this.currency = '';
        this.deleteText = 'Supprimer';
        this.isSelected = false;
        this.className = '';
        this.onDelete = new EventEmitter();
        this.onSelect = new EventEmitter();
    }
    get formattedPrice() {
        return formatMoney(this.price, false, false, false);
    }
    onSelectChange(event) {
        this.onSelect.emit({ event: event, data: this.data });
    }
    handleDelete(event) {
        this.onDelete.emit({ event: event, data: this.data });
    }
}
PaymentCardComponent.decorators = [
    { type: Component, args: [{
                selector: 'ds-payment-card',
                template: "<div\n  id=\"ds-payment-card\"\n  [ngClass]=\"className\"\n  class=\"border border-neutral-50 bg-level-4 justify-between rounded-lg py-2 px-3 flex items-center gap-3\"\n>\n  <div class=\"flex items-center gap-3\">\n    <ds-checkbox\n      [checked]=\"isSelected\"\n      (change)=\"onSelectChange($event)\"\n    ></ds-checkbox>\n    <div class=\"py-1 px-2 border border-neutral-100 rounded-[1px] w-[60px]\">\n      <img\n        [src]=\"image\"\n        [alt]=\"title\"\n        class=\"shrink-0 w-full h-full rounded-[2px] object-contain\"\n      />\n    </div>\n\n    <h3\n      *ngIf=\"title\"\n      class=\"text-[1rem]/[1.25rem] font-semibold text-neutral-900\"\n    >\n      {{ title }}\n    </h3>\n\n    <div class=\"flex flex-col gap-1 bg-neutral-25 py-1 px-2\">\n      <span class=\"inline-flex text-[0.75rem]/[0.875rem]\">Montant</span>\n      <span class=\"inline-flex text-[0.875rem]/[1rem] font-bold\">\n        {{ formattedPrice }} {{ currency }}\n      </span>\n    </div>\n  </div>\n\n  <button\n    class=\"inline-flex text-[0.875rem]/[1rem] text-neutral-700 font-bold items-center gap-2\"\n    (click)=\"handleDelete($event)\"\n  >\n    {{ deleteText }}\n\n    <ds-icon id=\"trash\" class=\"text-red-500\"></ds-icon>\n  </button>\n</div>\n"
            }] }
];
PaymentCardComponent.propDecorators = {
    title: [{ type: Input }],
    image: [{ type: Input }],
    price: [{ type: Input }],
    currency: [{ type: Input }],
    deleteText: [{ type: Input }],
    isSelected: [{ type: Input }],
    className: [{ type: Input }],
    data: [{ type: Input }],
    onDelete: [{ type: Output }],
    onSelect: [{ type: Output }]
};

// src/lib/step.component.ts
/**
 * @ignore
 */
class StepComponent {
    constructor() {
        this.title = '';
        this.shouldGoNext = true;
        this.shouldGoPrev = true;
        this.leftButtons = [
            {
                variant: 'gray',
                content: 'Prev',
                onClick: (btn) => {
                    console.log('this is prev ', btn);
                },
            },
        ];
        this.rightButtons = [
            {
                variant: 'primary',
                content: 'Next',
                pill: true,
                onClick: (btn) => {
                    console.log('this is next ', btn);
                },
            },
        ];
        /** Emitted when advancing to a new step */
        this.nextStep = new EventEmitter();
        /** Emitted when going back to a previous step */
        this.prevStep = new EventEmitter();
    }
}
StepComponent.decorators = [
    { type: Component, args: [{
                selector: 'ds-step',
                template: `<ng-template><ng-content></ng-content></ng-template>`
            }] }
];
StepComponent.propDecorators = {
    title: [{ type: Input }],
    shouldGoNext: [{ type: Input }],
    shouldGoPrev: [{ type: Input }],
    data: [{ type: Input }],
    leftButtons: [{ type: Input }],
    rightButtons: [{ type: Input }],
    nextStep: [{ type: Output }],
    prevStep: [{ type: Output }],
    contentTemplate: [{ type: ContentChild, args: [TemplateRef,] }]
};

// src/lib/steps-theme.ts
const STEPS_THEME = {
    default: {
        wrapper: 'h-full flex flex-col gap-6',
        headerWrapper: 'relative flex justify-between items-center overflow-hidden',
        step: 'relative flex-1 flex flex-col gap-y-2 before:transition-all before:duration-300 transition-all duration-300 items-center before:absolute before:top-4 before:-z-[1] before:-left-1/2 before:h-0 before:border-t',
        activeStep: 'font-semibold text-gray-900',
        contentWrapper: 'grow',
        navigationWrapper: 'flex justify-between items-center gap-x-3',
        button: 'px-4 py-2 rounded shadow-sm transition ease-in-out duration-150 ' +
            'bg-gray-200 hover:bg-gray-300 disabled:opacity-50',
    },
    vertical: {
        wrapper: 'grow flex items-start gap-x-8 mb-6',
        headerWrapper: 'min-w-[250px] relative flex flex-col justify-between items-start overflow-hidden isolate',
        step: 'relative pb-10 last:pb-0 flex-1 flex gap-x-2 before:transition-all before:duration-300 transition-all duration-300 items-center before:absolute before:left-4 before:top-8 before:-z-[1] before:h-full before:border-l',
        activeStep: 'font-semibold text-gray-900',
        contentWrapper: 'grow h-full',
        navigationWrapper: 'flex justify-between items-center gap-x-3',
        button: 'px-4 py-2 rounded shadow-sm transition ease-in-out duration-150 ' +
            'bg-gray-200 hover:bg-gray-300 disabled:opacity-50',
    },
};

// src/lib/steps.component.ts
/**
 * StepsComponent
 *
 * Live demo:
 * <example-url>/demo/ds-steps.component.html</example-url>
 */
class StepsComponent {
    constructor() {
        /** Index of the currently visible step */
        this.currentStepIndex = 0;
        /** Theme variant key (e.g. 'default' | 'primary' | 'success') */
        this.variant = 'default';
        this.title = '';
        this.showNavigation = true;
        this.showHeader = true;
        /** Resolved theme for the selected variant */
        this.theme = STEPS_THEME[this.variant] || STEPS_THEME.default;
        /** Move to next step if allowed */
        this.goNext = (event, button) => {
            if (button.disableHandleStep) {
                button.onClick({ button, event, currentIndex: this.currentStepIndex });
                return;
            }
            const step = this.steps.toArray()[this.currentStepIndex];
            if (step.shouldGoNext && this.currentStepIndex < this.steps.length - 1) {
                this.currentStepIndex++;
                step.nextStep.emit({
                    button,
                    event,
                    data: step.data,
                    currentIndex: this.currentStepIndex,
                });
                button.onClick({
                    button,
                    event,
                    data: step.data,
                    currentIndex: this.currentStepIndex,
                });
            }
        };
        /** Move to previous step if allowed */
        this.goPrev = (event, button) => {
            if (button.disableHandleStep) {
                button.onClick({ button, event, currentIndex: this.currentStepIndex });
                return;
            }
            const step = this.steps.toArray()[this.currentStepIndex];
            if (step.shouldGoPrev && this.currentStepIndex > 0) {
                this.currentStepIndex--;
                step.prevStep.emit({
                    button,
                    data: step.data,
                    event,
                    currentIndex: this.currentStepIndex,
                });
            }
            button.onClick({
                button,
                event,
                data: step.data,
                currentIndex: this.currentStepIndex,
            });
        };
    }
    ngAfterContentInit() {
        // resolve theme variant once steps are loaded
        this.theme = STEPS_THEME[this.variant] || STEPS_THEME.default;
    }
}
StepsComponent.decorators = [
    { type: Component, args: [{
                selector: 'ds-steps',
                template: "<!-- src/lib/steps.component.html -->\n<section id=\"ds-steps\" class=\"h-full flex flex-col\">\n  <div class=\"{{ theme.wrapper }}\">\n    <div\n      *ngIf=\"showHeader\"\n      [ngClass]=\"variant === 'vertical' ? 'sticky top-6' : ''\"\n    >\n      <h2 *ngIf=\"title\" class=\"text-[1.25rem]/[1.75rem] font-bold mb-6\">\n        {{ title }}\n      </h2>\n      <ul class=\"{{ theme.headerWrapper }}\">\n        <li\n          *ngFor=\"let step of steps.toArray(); let i = index; let isLast = last\"\n          class=\"{{ theme.step }}\"\n          [ngClass]=\"[\n            (i < currentStepIndex || (isLast && i === currentStepIndex)) &&\n            variant === 'default'\n              ? 'before:border-success-500 before:border-solid'\n              : i === currentStepIndex && variant === 'default'\n              ? 'before:border-amber-500 before:border-dashed'\n              : i < currentStepIndex - 1 && variant === 'vertical'\n              ? 'before:border-success-500 before:border-solid'\n              : i < currentStepIndex &&\n                i === steps.toArray().length - 2 &&\n                variant === 'vertical'\n              ? 'before:border-success-500 before:border-solid'\n              : i === currentStepIndex - 1 && variant === 'vertical'\n              ? 'before:border-amber-500 before:border-dashed'\n              : 'before:border-neutral-200 before:border-dashed',\n            isLast && variant === 'default'\n              ? 'before:w-[150%]'\n              : 'before:w-full'\n          ]\"\n        >\n          <div\n            class=\"bg-white rounded-full\"\n            [ngClass]=\"variant === 'vertical' ? 'py-2' : 'px-2'\"\n          >\n            <div\n              [ngClass]=\"[\n                'shrink-0 w-8 h-8 flex items-center transition-all duration-300 justify-center rounded-full relative z-[1] border-[1.5px]',\n                i < currentStepIndex || (isLast && i === currentStepIndex)\n                  ? 'bg-success-500 border-success-500 text-white'\n                  : i === currentStepIndex\n                  ? 'bg-level-4 border-amber-500 text-amber-500'\n                  : 'bg-level-4 border-neutral-200 text-neutral-400'\n              ]\"\n            >\n              <!-- COMPLETED: all steps before current, + the very last when active -->\n              <ng-container\n                *ngIf=\"\n                  i < currentStepIndex || (isLast && i === currentStepIndex)\n                \"\n              >\n                <ds-icon id=\"check\" class=\"text-white\" size=\"24\"></ds-icon>\n              </ng-container>\n\n              <!-- ACTIVE (only if it's current AND not the last) -->\n              <ng-container *ngIf=\"i === currentStepIndex && !isLast\">\n                <span\n                  class=\"inline-flex w-2.5 h-2.5 rounded-full bg-amber-500\"\n                ></span>\n              </ng-container>\n\n              <!-- UPCOMING -->\n              <ng-container *ngIf=\"i > currentStepIndex\">\n                <span\n                  class=\"inline-flex w-2.5 h-2.5 rounded-full bg-neutral-200\"\n                ></span>\n              </ng-container>\n            </div>\n          </div>\n\n          <span\n            class=\"text-[1rem]/[1.25rem] text-center\"\n            [ngClass]=\"\n              i < currentStepIndex || (isLast && i === currentStepIndex)\n                ? 'font-normal text-neutral-700'\n                : i === currentStepIndex\n                ? 'font-bold text-amber-500'\n                : 'font-normal text-neutral-700'\n            \"\n          >\n            {{ step.title }}\n          </span>\n        </li>\n      </ul>\n    </div>\n    <div class=\"{{ theme.contentWrapper }}\">\n      <!-- Step content -->\n      <ng-container\n        *ngTemplateOutlet=\"steps.toArray()[currentStepIndex].contentTemplate\"\n      ></ng-container>\n    </div>\n  </div>\n  <div *ngIf=\"showNavigation\" class=\"{{ theme.navigationWrapper }}\">\n    <!-- Navigation buttons -->\n    <div class=\"flex justify-end gap-2\">\n      <ds-button\n        *ngFor=\"let button of steps.toArray()[currentStepIndex].leftButtons\"\n        [variant]=\"button.variant\"\n        [icon]=\"button.icon\"\n        [iconRight]=\"button.iconRight\"\n        [iconLeft]=\"button.iconLeft\"\n        [pill]=\"button.pill\"\n        [outline]=\"button.outline\"\n        [type]=\"button.type || 'button'\"\n        [className]=\"button.className\"\n        [size]=\"button.size || 'normal'\"\n        (onClick)=\"goPrev($event, button)\"\n        [disabled]=\"\n          button.disabled === undefined\n            ? !steps.toArray()[currentStepIndex].shouldGoPrev\n            : button.disabled\n        \"\n      >\n        {{ button.content }}\n      </ds-button>\n    </div>\n    <div class=\"flex justify-end gap-2\">\n      <ds-button\n        *ngFor=\"let button of steps.toArray()[currentStepIndex].rightButtons\"\n        [variant]=\"button.variant\"\n        [icon]=\"button.icon\"\n        [iconRight]=\"button.iconRight\"\n        [iconLeft]=\"button.iconLeft\"\n        [pill]=\"button.pill\"\n        [outline]=\"button.outline\"\n        [type]=\"button.type || 'button'\"\n        [className]=\"button.className\"\n        [size]=\"button.size || 'normal'\"\n        (onClick)=\"goNext($event, button)\"\n        [disabled]=\"\n          button.disabled === undefined\n            ? !steps.toArray()[currentStepIndex].shouldGoNext\n            : button.disabled\n        \"\n      >\n        {{ button.content }}\n      </ds-button>\n    </div>\n  </div>\n</section>\n",
                host: { class: 'grow' }
            }] }
];
StepsComponent.propDecorators = {
    currentStepIndex: [{ type: Input }],
    steps: [{ type: ContentChildren, args: [StepComponent,] }],
    variant: [{ type: Input }],
    title: [{ type: Input }],
    showNavigation: [{ type: Input }],
    showHeader: [{ type: Input }]
};

registerLocaleData(localeFr, 'fr-FR');
class DesignSystemModule {
}
DesignSystemModule.decorators = [
    { type: NgModule, args: [{
                declarations: [
                    ButtonComponent,
                    BadgeComponent,
                    IconComponent,
                    AccordionComponent,
                    AvatarComponent,
                    DsTabsComponent,
                    DsTextComponent,
                    DsActionsLayoutComponent,
                    DsBreadcrumbComponent,
                    CallToActionIconsComponent,
                    EmptyCardComponent,
                    DsToggleComponent,
                    DsShortcutsCardComponent,
                    FilialCardComponent,
                    InboxCardComponent,
                    NotificationCardComponent,
                    ProgressComponent,
                    CurrencyConverterComponent,
                    ProfileDropdownComponent,
                    DsDropdownComponent,
                    DsPopupComponent,
                    DsCheckboxComponent,
                    DsInputComponent,
                    DsRadioComponent,
                    DsRangeComponent,
                    DsTextareaComponent,
                    DsSelectComponent,
                    DsBalanceFormatterComponent,
                    DsDisplayValueComponent,
                    DsAccountGridCardComponent,
                    DsAccountSliderCardComponent,
                    DsAccountSelectedCardComponent,
                    DsThemeToggleComponent,
                    DsBottomMenusComponent,
                    DsMenuItemComponent,
                    DsMenuListComponent,
                    DsSidebarComponent,
                    DsPaginationComponent,
                    DsHoldingCardComponent,
                    PortfolioItemCardComponent,
                    PortfolioSelectCardComponent,
                    PortfolioVisionCardComponent,
                    TickerCardComponent,
                    AccountHoldingCardComponent,
                    AccountHoldingSelectedCardComponent,
                    DsAccountGridHoldingCardComponent,
                    DsAccountFilialHoldingCardComponent,
                    SheetCardComponent,
                    SheetLatestOpsComponent,
                    TableComponent,
                    InvoiceCardComponent,
                    PaymentCardComponent,
                    StepsComponent,
                    StepComponent,
                    PaymentDetailsCardComponent,
                    AccountsSelectComponent,
                    UploadFileComponent,
                    DatePickerComponent,
                    TodoTabComponent,
                    TodoCardComponent,
                    SliderDotsComponent,
                    AccountCardComponent,
                    PortfolioComponent,
                    PinInputComponent,
                    CodeInputComponent,
                    AccordionCardComponent,
                    FooterComponent,
                    DisplayPriceCardComponent,
                    LabelComponent,
                    ErrorCardComponent,
                    BadgeGroupComponent,
                    SkeletonComponent,
                    AutocompleteComponent,
                    FloatedButtonsComponent,
                    CarouselComponent,
                    DropdownHolderComponent,
                    MessageComponent,
                    ImportCardComponent,
                    FileUploaderComponent,
                    FileListComponent,
                    TotalListComponent,
                    TooltipComponent,
                    BoxCheckboxComponent,
                    LayerComponent,
                    SignataireListComponent,
                    LoaderComponent,
                    PriceFilterComponent,
                    IllustrationComponent,
                    InputPhoneComponent,
                    ModalComponent,
                    VirementCardComponent,
                    VirementCardRecapComponent,
                ],
                imports: [
                    CommonModule,
                    FormsModule,
                    RouterModule,
                    PortalModule,
                    CarouselModule,
                    CodeInputModule,
                    // NgxDaterangepickerMd.forRoot(),
                    OverlayModule,
                    ReactiveFormsModule,
                    BsDatepickerModule.forRoot(),
                ],
                providers: [{ provide: LOCALE_ID, useValue: 'fr-FR' }],
                exports: [
                    ButtonComponent,
                    BadgeComponent,
                    IconComponent,
                    AccordionComponent,
                    AvatarComponent,
                    DsTabsComponent,
                    DsTextComponent,
                    DsActionsLayoutComponent,
                    DsBreadcrumbComponent,
                    CallToActionIconsComponent,
                    EmptyCardComponent,
                    DsToggleComponent,
                    DsShortcutsCardComponent,
                    FilialCardComponent,
                    InboxCardComponent,
                    NotificationCardComponent,
                    ProgressComponent,
                    CurrencyConverterComponent,
                    ProfileDropdownComponent,
                    DsDropdownComponent,
                    DsPopupComponent,
                    DsCheckboxComponent,
                    DsInputComponent,
                    DsRadioComponent,
                    DsRangeComponent,
                    DsTextareaComponent,
                    DsSelectComponent,
                    DsBalanceFormatterComponent,
                    DsDisplayValueComponent,
                    DsAccountGridCardComponent,
                    DsAccountSliderCardComponent,
                    DsAccountSelectedCardComponent,
                    DsThemeToggleComponent,
                    DsBottomMenusComponent,
                    DsMenuItemComponent,
                    DsMenuListComponent,
                    DsSidebarComponent,
                    DsPaginationComponent,
                    DsHoldingCardComponent,
                    PortfolioItemCardComponent,
                    PortfolioSelectCardComponent,
                    PortfolioVisionCardComponent,
                    TickerCardComponent,
                    AccountHoldingCardComponent,
                    AccountHoldingSelectedCardComponent,
                    DsAccountGridHoldingCardComponent,
                    DsAccountFilialHoldingCardComponent,
                    SheetCardComponent,
                    SheetLatestOpsComponent,
                    TableComponent,
                    InvoiceCardComponent,
                    PaymentCardComponent,
                    StepsComponent,
                    StepComponent,
                    PaymentDetailsCardComponent,
                    AccountsSelectComponent,
                    UploadFileComponent,
                    DatePickerComponent,
                    TodoTabComponent,
                    TodoCardComponent,
                    SliderDotsComponent,
                    AccountCardComponent,
                    PortfolioComponent,
                    CarouselModule,
                    PinInputComponent,
                    CodeInputComponent,
                    CodeInputModule,
                    AccordionCardComponent,
                    FooterComponent,
                    DisplayPriceCardComponent,
                    LabelComponent,
                    ErrorCardComponent,
                    BadgeGroupComponent,
                    SkeletonComponent,
                    AutocompleteComponent,
                    FloatedButtonsComponent,
                    CarouselComponent,
                    DropdownHolderComponent,
                    MessageComponent,
                    ImportCardComponent,
                    FileUploaderComponent,
                    FileListComponent,
                    TotalListComponent,
                    TooltipComponent,
                    BoxCheckboxComponent,
                    LayerComponent,
                    SignataireListComponent,
                    LoaderComponent,
                    PriceFilterComponent,
                    IllustrationComponent,
                    InputPhoneComponent,
                    ModalComponent,
                    VirementCardComponent,
                    VirementCardRecapComponent,
                ],
            },] }
];

class DesignSystemService {
    constructor() { }
}
DesignSystemService.decorators = [
    { type: Injectable, args: [{
                providedIn: 'root'
            },] }
];
/** @nocollapse */
DesignSystemService.ctorParameters = () => [];
DesignSystemService.ngInjectableDef = defineInjectable({ factory: function DesignSystemService_Factory() { return new DesignSystemService(); }, token: DesignSystemService, providedIn: "root" });

/*
 * Public API Surface of design-system
 */

/**
 * Generated bundle index. Do not edit.
 */

export { AccordionComponent as ɵd, AccountCardComponent as ɵcj, DsAccountFilialHoldingCardComponent as ɵbu, DsAccountGridCardComponent as ɵbd, DsAccountGridHoldingCardComponent as ɵbt, AccountHoldingCardComponent as ɵbr, AccountHoldingSelectedCardComponent as ɵbs, DsAccountSelectedCardComponent as ɵbf, DsAccountSliderCardComponent as ɵbe, AccountsSelectComponent as ɵcd, DsActionsLayoutComponent as ɵh, AvatarComponent as ɵe, BadgeGroupComponent as ɵcs, BadgeComponent as ɵb, DsBalanceFormatterComponent as ɵbb, BoxCheckboxComponent as ɵde, DsBreadcrumbComponent as ɵi, ButtonComponent as ɵa, CallToActionIconsComponent as ɵj, AccordionCardComponent as ɵcn, DisplayPriceCardComponent as ɵcp, EmptyCardComponent as ɵk, ErrorCardComponent as ɵcr, FilialCardComponent as ɵn, DsHoldingCardComponent as ɵbm, InboxCardComponent as ɵo, InvoiceCardComponent as ɵby, NotificationCardComponent as ɵp, PaymentCardComponent as ɵbz, PaymentDetailsCardComponent as ɵcc, TickerCardComponent as ɵbq, CarouselComponent as ɵcw, CurrencyConverterComponent as ɵr, DsDisplayValueComponent as ɵbc, DropdownHolderComponent as ɵcx, DsDropdownComponent as ɵt, FileListComponent as ɵdb, FileUploaderComponent as ɵda, FloatedButtonsComponent as ɵcv, FooterComponent as ɵco, AutocompleteComponent as ɵcu, DsCheckboxComponent as ɵv, CodeInputComponent as ɵcm, DatePickerComponent as ɵcf, DsInputComponent as ɵw, LabelComponent as ɵcq, PinInputComponent as ɵcl, DsRadioComponent as ɵx, DsRangeComponent as ɵy, DsSelectComponent as ɵba, DsTextareaComponent as ɵz, UploadFileComponent as ɵce, IconComponent as ɵc, IllustrationComponent as ɵdj, ImportCardComponent as ɵcz, InputPhoneComponent as ɵdk, LayerComponent as ɵdf, LoaderComponent as ɵdh, MessageComponent as ɵcy, ModalComponent as ɵdl, DsPaginationComponent as ɵbl, DsPopupComponent as ɵu, PortfolioItemCardComponent as ɵbn, PortfolioSelectCardComponent as ɵbo, PortfolioVisionCardComponent as ɵbp, PortfolioComponent as ɵck, PriceFilterComponent as ɵdi, ProfileDropdownComponent as ɵs, ProgressComponent as ɵq, SheetCardComponent as ɵbv, SheetLatestOpsComponent as ɵbw, DsShortcutsCardComponent as ɵm, DsBottomMenusComponent as ɵbh, DsMenuItemComponent as ɵbi, DsMenuListComponent as ɵbj, DsSidebarComponent as ɵbk, SignataireListComponent as ɵdg, SkeletonComponent as ɵct, SliderDotsComponent as ɵci, StepComponent as ɵcb, StepsComponent as ɵca, TableComponent as ɵbx, DsTabsComponent as ɵf, DsTextComponent as ɵg, DsThemeToggleComponent as ɵbg, TodoCardComponent as ɵch, TodoTabComponent as ɵcg, DsToggleComponent as ɵl, TooltipComponent as ɵdd, TotalListComponent as ɵdc, VirementCardRecapComponent as ɵdn, VirementCardComponent as ɵdm, DesignSystemModule, DesignSystemService };

//# sourceMappingURL=mybusiness-design-system.js.map