export declare class DesignSystemService {
    constructor();
}
