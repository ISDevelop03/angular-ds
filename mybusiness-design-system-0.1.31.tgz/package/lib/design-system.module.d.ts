export declare class DesignSystemModule {
}
