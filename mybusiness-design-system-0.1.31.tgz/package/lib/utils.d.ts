export interface ControlConfig {
    name: string;
    label: string;
    type: 'text' | 'number' | 'boolean' | 'select' | 'json';
    value: any;
    options?: any[];
}
export declare const formatMoney: (value: number, withCurrency?: boolean, noDecimals?: boolean, isDiscrete?: boolean) => string;
export declare const checkItemsMenu: <T>(items?: T[]) => boolean;
export declare const getFirstTwoLetters: (title: string) => string;
