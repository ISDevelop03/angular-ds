import { ElementRef, Renderer2, OnInit, OnDestroy, AfterViewChecked, ChangeDetectorRef, TemplateRef } from '@angular/core';
/**
 * TooltipComponent
 *
 * Live demo:
 * <example-url>/demo/ds-tooltip.component.html</example-url>
 */
export declare class TooltipComponent implements OnInit, OnDestroy, AfterViewChecked {
    private el;
    private renderer;
    private cdr;
    content: TemplateRef<any> | string;
    position: 'top' | 'topRight' | 'topLeft' | 'bottom' | 'bottomRight' | 'bottomLeft' | 'left' | 'right';
    className?: string;
    disabled: boolean;
    delay: number;
    theme: any;
    style: Record<string, string>;
    isVisible: boolean;
    defaultTheme: {
        base: string;
        positions: {
            top: string;
            topRight: string;
            topLeft: string;
            bottom: string;
            bottomRight: string;
            bottomLeft: string;
            left: string;
            right: string;
        };
        arrow: {
            base: string;
            positions: {
                top: string;
                topRight: string;
                topLeft: string;
                bottom: string;
                bottomRight: string;
                bottomLeft: string;
                left: string;
                right: string;
            };
        };
    };
    private timeoutId;
    constructor(el: ElementRef, renderer: Renderer2, cdr: ChangeDetectorRef);
    ngOnInit(): void;
    ngAfterViewChecked(): void;
    private applyStylesToTooltip;
    ngOnDestroy(): void;
    readonly appliedTheme: any;
    readonly computedClass: string;
    readonly animationState: string;
    readonly arrowClass: string;
    readonly isStringContent: boolean;
    onMouseEnter(event: MouseEvent): void;
    onMouseLeave(event: MouseEvent): void;
    onFocusIn(event: FocusEvent): void;
    onFocusOut(event: FocusEvent): void;
    private showTooltip;
    private hideTooltip;
    private clearTimeout;
}
