export declare const defaultTheme: {
    base: string;
    positions: {
        top: string;
        topRight: string;
        topLeft: string;
        bottom: string;
        bottomRight: string;
        bottomLeft: string;
        left: string;
        right: string;
    };
    arrow: {
        base: string;
        positions: {
            top: string;
            topRight: string;
            topLeft: string;
            bottom: string;
            bottomRight: string;
            bottomLeft: string;
            left: string;
            right: string;
        };
    };
};
export declare const theme: {
    default: {
        base: string;
        positions: {
            top: string;
            topRight: string;
            topLeft: string;
            bottom: string;
            bottomRight: string;
            bottomLeft: string;
            left: string;
            right: string;
        };
        arrow: {
            base: string;
            positions: {
                top: string;
                topRight: string;
                topLeft: string;
                bottom: string;
                bottomRight: string;
                bottomLeft: string;
                left: string;
                right: string;
            };
        };
    };
};
