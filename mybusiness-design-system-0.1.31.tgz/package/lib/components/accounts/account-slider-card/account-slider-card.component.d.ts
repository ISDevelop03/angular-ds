import { EventEmitter, OnInit } from '@angular/core';
import { ICallToActionIcon } from '../../call-to-action-icons/types';
/**
 * Account-slider-cardComponent
 *
 * Live demo:
 * <example-url>/demo/ds-account-slider-card.component.html</example-url>
 */
export declare class DsAccountSliderCardComponent implements OnInit {
    isDiscrete: boolean;
    account_number: string;
    balance: number;
    currency: string;
    type: string;
    id?: string;
    isSelected: boolean;
    actionsList: ICallToActionIcon[];
    className?: string;
    minHeight: number;
    data?: any;
    onClick: EventEmitter<any>;
    ngOnInit(): void;
    handleClick(event: any): void;
}
