import { OnInit } from '@angular/core';
import { ICallToActionIcon } from '../../call-to-action-icons/types';
/**
 * AccountCardComponent
 *
 * Live demo:
 * <example-url>/demo/ds-account-card.component.html</example-url>
 */
export declare class AccountCardComponent implements OnInit {
    isDiscrete: boolean;
    isFavorite: boolean;
    account_number: string;
    balance: number;
    currency: string;
    type: string;
    id?: string;
    actionsList: ICallToActionIcon[];
    solde_comptable?: number;
    solde_temps_reel?: number;
    className?: string;
    data?: any;
    ngOnInit(): void;
}
