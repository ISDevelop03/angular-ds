import { EventEmitter, ElementRef, SimpleChanges, OnChanges } from '@angular/core';
import { theme } from './theme';
export interface Solde {
    value: number;
    currency: string;
    currency_flag: string;
}
export interface SelectItem {
    unavailable?: boolean;
    icon: string;
    value: string;
    accountName: string;
    accountNumber: string;
    soldeComptable?: Solde;
    soldeTempsReel?: Solde;
}
export interface OmittedSelectItem {
    value: string;
    icon?: string;
    unavailable?: boolean;
}
/**
 * Accounts-selectComponent
 *
 * Live demo:
 * <example-url>/demo/ds-accounts-select.component.html</example-url>
 */
export declare class AccountsSelectComponent implements OnChanges {
    items: SelectItem[];
    label?: string;
    errorMessage?: string;
    placeholder: string;
    variant: keyof typeof theme;
    disabled: boolean;
    hasError: boolean;
    emptyLabel: string;
    multiple: boolean;
    isLoading: boolean;
    className?: string;
    buttonIcon?: string;
    value: string | null;
    customOptionsStyles?: {
        [key: string]: any;
    };
    autoComplete: boolean;
    showCurrencyFlag: boolean;
    valueChange: EventEmitter<string | string[]>;
    private static zIndexCounter;
    autoCompleteInput?: ElementRef;
    isOpen: boolean;
    searchTerm: string;
    filteredItems: SelectItem[];
    selectedValue: SelectItem | null;
    containerPosition: {
        [key: string]: any;
    };
    containerStyles: {};
    triggerButton?: ElementRef;
    optionsContainer?: ElementRef;
    theme: {
        default: {
            element: {
                label: string;
                button: {
                    select: string;
                    selected: string;
                    error: string;
                    iconeError: string;
                    disabled: string;
                    label: string;
                    placeholder: string;
                };
                field: {
                    activated: string;
                };
                icone: {
                    arrow: string;
                    checked: string;
                };
                options: {
                    selectedfont: string;
                    container: string;
                    element: string;
                    fontcolor: string;
                    available: string;
                    unavailable: string;
                };
                error: string;
            };
        };
        currency: {
            element: {
                label: string;
                button: {
                    select: string;
                    selected: string;
                    error: string;
                    iconeError: string;
                    disabled: string;
                    label: string;
                    placeholder: string;
                };
                field: {
                    activated: string;
                };
                icone: {
                    arrow: string;
                    checked: string;
                };
                options: {
                    selectedfont: string;
                    container: string;
                    element: string;
                    fontcolor: string;
                    available: string;
                    unavailable: string;
                };
                error: string;
            };
        };
    };
    ngOnChanges(changes: SimpleChanges): void;
    readonly mergedStyles: {
        [key: string]: any;
    } & {
        [key: string]: any;
    };
    toggleDropdown(): void;
    shouldAppear(): boolean;
    calculatePosition(): void;
    selectOption(item: SelectItem): void;
    isSelected(item: SelectItem): boolean;
    readonly selected: SelectItem;
    onClickOutside(event: MouseEvent): void;
    onEscClose(event: KeyboardEvent): void;
    onAutoCompleteInput(event: Event): void;
    clearSearch(): void;
}
