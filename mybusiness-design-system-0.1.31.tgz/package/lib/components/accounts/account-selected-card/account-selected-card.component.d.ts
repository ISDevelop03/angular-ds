import { OnInit } from '@angular/core';
import { ICallToActionIcon } from '../../call-to-action-icons/types';
/**
 * Account-selected-cardComponent
 *
 * Live demo:
 * <example-url>/demo/ds-account-selected-card.component.html</example-url>
 */
export declare class DsAccountSelectedCardComponent implements OnInit {
    isDiscrete: boolean;
    account_number: string;
    balance: number;
    currency: string;
    type: string;
    id?: string;
    actionsList: ICallToActionIcon[];
    solde_comptable?: number;
    solde_temps_reel?: number;
    className?: string;
    data?: any;
    ngOnInit(): void;
}
