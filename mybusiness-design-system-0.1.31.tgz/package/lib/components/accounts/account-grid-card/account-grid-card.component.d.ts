/**
 * Account-grid-cardComponent
 *
 * Live demo:
 * <example-url>/demo/ds-account-grid-card.component.html</example-url>
 */
export declare class DsAccountGridCardComponent {
    isDiscrete: boolean;
    title: string;
    currency: string;
    price: number;
    dateOperation: string;
    dateValue: string;
    className?: string;
    showAccordion: boolean;
    toggleAccordion(): void;
}
