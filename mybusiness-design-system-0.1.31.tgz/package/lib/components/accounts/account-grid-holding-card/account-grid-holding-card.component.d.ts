import { OnInit } from '@angular/core';
import { ICallToActionIcon } from '../../call-to-action-icons/types';
/**
 * Account-grid-holding-cardComponent
 *
 * Live demo:
 * <example-url>/demo/ds-account-grid-holding-card.component.html</example-url>
 */
export declare class DsAccountGridHoldingCardComponent implements OnInit {
    id: any;
    title: string;
    accountNumber: number;
    currency: string;
    soldeComptable: number;
    soldeReel: number;
    actionsList?: ICallToActionIcon[];
    editLink?: string;
    className?: string;
    isDiscrete: boolean;
    data?: any;
    copyToClipboard?: (accountNumber: number) => void;
    ngOnInit(): void;
    showAccordion: boolean;
    toggleAccordion(): void;
}
