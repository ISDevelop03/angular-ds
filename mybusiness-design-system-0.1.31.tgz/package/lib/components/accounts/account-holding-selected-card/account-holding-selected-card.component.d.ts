import { EventEmitter, OnInit } from '@angular/core';
import { ICallToActionIcon } from '../../call-to-action-icons/types';
/**
 * Account-holding-selected-cardComponent
 *
 * Live demo:
 * <example-url>/demo/ds-account-holding-selected-card.component.html</example-url>
 */
export declare class AccountHoldingSelectedCardComponent implements OnInit {
    id: any;
    image: string;
    title: string;
    className?: string;
    data?: any;
    actionsList: ICallToActionIcon[];
    onClick: EventEmitter<any>;
    ngOnInit(): void;
    handleClick(event: any): void;
    getFirstTwoLetters: (title: string) => string;
}
