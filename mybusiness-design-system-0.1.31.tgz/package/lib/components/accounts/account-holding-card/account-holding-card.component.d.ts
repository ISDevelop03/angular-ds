import { EventEmitter } from '@angular/core';
import { ICallToActionIcon } from '../../call-to-action-icons/types';
/**
 * Account-holding-cardComponent
 *
 * Live demo:
 * <example-url>/demo/ds-account-holding-card.component.html</example-url>
 */
export declare class AccountHoldingCardComponent {
    id: any;
    image: string;
    title: string;
    className?: string;
    actionsList: ICallToActionIcon[];
    data?: any;
    onClick: EventEmitter<any>;
    ngOnInit(): void;
    handleClick(event: any): void;
    getFirstTwoLetters: (title: string) => string;
}
