import { ICallToActionIcon } from '../../call-to-action-icons/types';
/**
 * Account-filial-holding-cardComponent
 *
 * Live demo:
 * <example-url>/demo/ds-account-filial-holding-card.component.html</example-url>
 */
export declare class DsAccountFilialHoldingCardComponent {
    id: any;
    title: string;
    image: string;
    className?: string;
    data?: any;
    actionsList?: ICallToActionIcon[];
    _showAccordion: boolean;
    showAccordionIcon: 'arrow-down' | 'arrow-up';
    toggleAccordion(): void;
    showAccordion: boolean;
    ngOnInit(): void;
    getFirstTwoLetters: (title: string) => string;
}
