import { EventEmitter, OnInit } from '@angular/core';
declare type Theme = 'light' | 'dark';
/**
 * Theme-toggleComponent
 *
 * Live demo:
 * <example-url>/demo/ds-theme-toggle.component.html</example-url>
 */
export declare class DsThemeToggleComponent implements OnInit {
    theme: Theme;
    onThemeChange: EventEmitter<Theme>;
    ngOnInit(): void;
    private initTheme;
    private applyThemeClass;
    toggleTheme(): void;
}
export {};
