export declare const avatar: {
    default: {
        base: string;
    };
    placeholder: {
        base: string;
        svg: string;
    };
    initials: {
        base: string;
        text: string;
        textSizes: {
            small: string;
            normal: string;
            large: string;
            xlarge: string;
            xxlarge: string;
        };
    };
    size: {
        small: string;
        normal: string;
        large: string;
        xlarge: string;
        xxlarge: string;
    };
};
