/**
 * AvatarComponent
 *
 * Live demo:
 * <example-url>/demo/ds-avatar.component.html</example-url>
 */
export declare class AvatarComponent {
    variant: 'default' | 'placeholder' | 'initials';
    size: 'normal' | 'small' | 'large';
    alt: string;
    src: string;
    className: string;
    children?: string;
    avatar: {
        default: {
            base: string;
        };
        placeholder: {
            base: string;
            svg: string;
        };
        initials: {
            base: string;
            text: string;
            textSizes: {
                small: string;
                normal: string;
                large: string;
                xlarge: string;
                xxlarge: string;
            };
        };
        size: {
            small: string;
            normal: string;
            large: string;
            xlarge: string;
            xxlarge: string;
        };
    };
    readonly classes: string;
    readonly textSize: string;
}
