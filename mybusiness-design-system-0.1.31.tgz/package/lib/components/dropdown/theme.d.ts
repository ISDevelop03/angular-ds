export declare const dropdown: {
    base: string;
    button: {
        base: string;
        active: string;
    };
    container: string;
    item: {
        base: string;
    };
    variants: {
        base: string;
        select: string;
    };
    icon: string;
};
