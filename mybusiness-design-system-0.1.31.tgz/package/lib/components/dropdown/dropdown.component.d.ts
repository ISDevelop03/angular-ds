import { ElementRef, OnDestroy, OnInit, TemplateRef, ViewContainerRef, ChangeDetectorRef, ApplicationRef, ComponentFactoryResolver, Injector } from '@angular/core';
import { dropdown } from './theme';
import { DropdownItem } from './types';
/**
 * DropdownComponent
 *
 * Live demo:
 * <example-url>/demo/ds-dropdown.component.html</example-url>
 */
export declare class DsDropdownComponent implements OnInit, OnDestroy {
    private cd;
    private vcr;
    private cfr;
    private appRef;
    private injector;
    private document;
    items: DropdownItem[];
    variant: keyof typeof dropdown.variants;
    className: string;
    trigger: ElementRef;
    menuTpl: TemplateRef<any>;
    menu: ElementRef;
    isOpen: boolean;
    menuStyles: {
        [key: string]: string;
    };
    private portalHost;
    private menuPortal;
    constructor(cd: ChangeDetectorRef, vcr: ViewContainerRef, cfr: ComponentFactoryResolver, appRef: ApplicationRef, injector: Injector, document: any);
    ngOnInit(): void;
    ngOnDestroy(): void;
    toggleMenu(): void;
    private setMenuPosition;
    closeMenu(): void;
    onItemClick(event: any, cb?: (event: any) => void): void;
    handleOutsideClick: (e: MouseEvent) => void;
    stopEvent(event: MouseEvent): void;
    private static zIndexCounter;
    dropdown: {
        base: string;
        button: {
            base: string;
            active: string;
        };
        container: string;
        item: {
            base: string;
        };
        variants: {
            base: string;
            select: string;
        };
        icon: string;
    };
}
