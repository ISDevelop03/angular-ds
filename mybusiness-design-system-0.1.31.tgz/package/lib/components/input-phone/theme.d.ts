export declare const theme: {
    default: {
        container: string;
        wrapper: {
            base: string;
            enabled: string;
            disabled: string;
        };
        label: string;
        input: string;
        prefix: string;
        sufix: string;
        errorMessage: string;
        hasError: string;
        description: string;
    };
};
