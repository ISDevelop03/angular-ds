import { EventEmitter } from '@angular/core';
/**
 * InputPhoneComponent
 *
 * Live demo:
 * <example-url>/demo/ds-input-phone.component.html</example-url>
 */
export declare class InputPhoneComponent {
    className?: string;
    label?: string;
    tooltip?: string;
    required?: boolean;
    hasError?: boolean;
    errorMessage?: string;
    description?: string;
    countriesPrefixes: Record<string, string>[];
    placeholder: string;
    selectedCountryPrefix: string;
    value: string | null;
    onChange: EventEmitter<string>;
    theme: {
        container: string;
        wrapper: {
            base: string;
            enabled: string;
            disabled: string;
        };
        label: string;
        input: string;
        prefix: string;
        sufix: string;
        errorMessage: string;
        hasError: string;
        description: string;
    };
    phoneNumber: string | null;
    onCountryChange(event: string): void;
    onPhoneNumberChange(event: Event): void;
}
