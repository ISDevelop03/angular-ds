export declare const theme: {
    warning: {
        wrapper: string;
        icon: string;
        content: string;
    };
    success: {
        wrapper: string;
        icon: string;
        content: string;
    };
    error: {
        wrapper: string;
        icon: string;
        content: string;
    };
};
