declare type TVariant = "success" | "error" | "warning";
/**
 * MessageComponent
 *
 * Live demo:
 * <example-url>/demo/ds-message.component.html</example-url>
 */
export declare class MessageComponent {
    className?: string;
    content?: string;
    variant?: TVariant;
    theme: {
        warning: {
            wrapper: string;
            icon: string;
            content: string;
        };
        success: {
            wrapper: string;
            icon: string;
            content: string;
        };
        error: {
            wrapper: string;
            icon: string;
            content: string;
        };
    };
}
export {};
