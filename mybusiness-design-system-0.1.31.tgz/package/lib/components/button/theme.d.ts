export declare const defaultTheme: {
    base: string;
    contentWrapper: string;
    disabled: {
        primary: string;
        secondary: string;
        outline: string;
        text: string;
        link: string;
    };
    size: {
        small: {
            text: string;
            icon: string;
        };
        normal: {
            text: string;
            icon: string;
        };
        medium: {
            text: string;
            icon: string;
        };
        large: {
            text: string;
            icon: string;
        };
    };
    variants: {
        primary: string;
        secondary: string;
        outline: string;
        text: string;
        link: string;
    };
};
