import { EventEmitter, OnInit } from '@angular/core';
import { defaultTheme } from './theme';
/**
 * ButtonComponent
 *
 * Live demo:
 * <example-url>/demo/ds-button.component.html</example-url>
 */
export declare class ButtonComponent implements OnInit {
    icon: string;
    iconRight: string;
    iconLeft: string;
    type: string;
    className: string;
    variant: keyof typeof defaultTheme.variants;
    size: keyof typeof defaultTheme.size;
    disabled: boolean;
    outline: boolean;
    pill: boolean;
    href: string;
    target: string;
    isLoading: boolean;
    theme: any;
    style: string;
    onClick: EventEmitter<any>;
    defaultTheme: {
        base: string;
        contentWrapper: string;
        disabled: {
            primary: string;
            secondary: string;
            outline: string;
            text: string;
            link: string;
        };
        size: {
            small: {
                text: string;
                icon: string;
            };
            normal: {
                text: string;
                icon: string;
            };
            medium: {
                text: string;
                icon: string;
            };
            large: {
                text: string;
                icon: string;
            };
        };
        variants: {
            primary: string;
            secondary: string;
            outline: string;
            text: string;
            link: string;
        };
    };
    readonly appliedTheme: any;
    readonly computedClass: string;
    ngOnInit(): void;
}
