import { PaginationVariants } from './types';
export declare const paginationVariants: PaginationVariants;
