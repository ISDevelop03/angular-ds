import { ChangeDetectorRef, ElementRef } from '@angular/core';
/**
 * CarouselComponent
 *
 * Live demo:
 * <example-url>/demo/ds-carousel.component.html</example-url>
 */
export declare class CarouselComponent {
    private cd;
    className: string;
    wrapperClass: string;
    itemCount: number;
    itemClass: string;
    carouselRef: ElementRef<HTMLDivElement>;
    activeIndex: number;
    visibleSlides: number[];
    private visibleCount;
    private items;
    constructor(cd: ChangeDetectorRef);
    ngAfterViewInit(): void;
    private updateVisibleSlides;
    private scrollToIndex;
    scrollNext(): void;
    scrollPrev(): void;
    onSelect(index: number): void;
}
