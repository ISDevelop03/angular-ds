import { TemplateRef } from '@angular/core';
/**
 * Sheet-cardComponent
 *
 * Live demo:
 * <example-url>/demo/ds-sheet-card.component.html</example-url>
 */
export declare class SheetCardComponent {
    image?: string;
    icon?: string;
    label?: string;
    isDraggable?: string;
    leftContent?: string | TemplateRef<any>;
    data?: any;
    iconRight?: string;
    iconPosition?: 'bottom' | 'center' | 'top';
    className?: string;
    iconPositionClassName?: string;
    removeImageRounded?: boolean;
    onClick?: (item: any) => void;
    startClick?: (item: any) => void;
    isTemplate(ref: any): ref is TemplateRef<any>;
}
