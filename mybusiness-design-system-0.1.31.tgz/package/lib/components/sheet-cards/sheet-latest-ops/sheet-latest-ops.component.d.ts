/**
 * Sheet-latest-opsComponent
 *
 * Live demo:
 * <example-url>/demo/ds-sheet-latest-ops.component.html</example-url>
 */
export declare class SheetLatestOpsComponent {
    isDiscrete: boolean;
    title: string;
    currency: string;
    price: number;
    dateOperation: string;
    dateValue: string;
    className?: string;
}
