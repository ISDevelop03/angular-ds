import { ElementRef, OnDestroy, Renderer2 } from '@angular/core';
import { theme } from './theme';
/**
 * PopupComponent
 *
 * Live demo:
 * <example-url>/demo/ds-popup.component.html</example-url>
 */
export declare class DsPopupComponent implements OnDestroy {
    private _elementRef;
    private _renderer;
    isShown: boolean;
    icon?: string;
    type?: 'success' | 'warning' | 'error' | 'info';
    heading?: string;
    variant: keyof typeof theme.variants;
    className?: string;
    panelClassName?: string;
    isFullScreen?: boolean;
    close: () => void;
    theme: {
        base: string;
        overlay: string;
        rounded: string; /**
         * PopupComponent
         *
         * Live demo:
         * <example-url>/demo/ds-popup.component.html</example-url>
         */
        panel: string;
        variants: {
            modal: {
                base: string;
                panel: string;
            };
            slideLeft: {
                base: string;
                panel: string;
            };
            slideRight: {
                base: string;
                panel: string;
            };
        };
    };
    constructor(_elementRef: ElementRef, _renderer: Renderer2);
    onEscPressed(event: KeyboardEvent): void;
    onClose(): void;
    ngOnDestroy(): void;
    removeListeners(): void;
    onBackdropClick(event: MouseEvent): void;
    getAnimationClass(): string;
}
