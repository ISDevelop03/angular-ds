export declare const theme: {
    base: string;
    overlay: string;
    rounded: string;
    panel: string;
    variants: {
        modal: {
            base: string;
            panel: string;
        };
        slideLeft: {
            base: string;
            panel: string;
        };
        slideRight: {
            base: string;
            panel: string;
        };
    };
};
