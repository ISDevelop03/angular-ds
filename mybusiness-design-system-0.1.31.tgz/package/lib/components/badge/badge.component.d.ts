import { EventEmitter } from '@angular/core';
/**
 * BadgeComponent
 *
 * Live demo:
 * <example-url>/demo/ds-badge.component.html</example-url>
 */
export declare class BadgeComponent {
    icon?: string;
    label: string;
    href?: string;
    pill: boolean;
    variant: string;
    size: string;
    withDot: boolean;
    iconRight: boolean;
    className: string;
    onClick: EventEmitter<Event>;
    badge: {
        base: string;
        sizes: {
            sm: string;
            md: string;
            lg: string;
        };
        variants: {
            default: string;
            amber: string;
            blue: string;
            green: string;
            red: string;
            orange: string;
            crame: string;
            neutral: string;
        };
        icon: string;
    };
    textVariants: {
        sm: string;
        md: string;
        lg: string;
    };
    getBadgeClasses(): string;
    getTextClasses(): string;
    handleClick(event: Event): void;
}
