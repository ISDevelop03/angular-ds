export declare const badge: {
    base: string;
    sizes: {
        sm: string;
        md: string;
        lg: string;
    };
    variants: {
        default: string;
        amber: string;
        blue: string;
        green: string;
        red: string;
        orange: string;
        crame: string;
        neutral: string;
    };
    icon: string;
};
export declare const textVariants: {
    sm: string;
    md: string;
    lg: string;
};
