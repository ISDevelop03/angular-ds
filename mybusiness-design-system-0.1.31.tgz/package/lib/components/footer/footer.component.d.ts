export interface FooterMenu {
    title: string;
    href: string;
    image: string;
    isDisabled?: boolean;
}
/**
 * FooterComponent
 *
 * Live demo:
 * <example-url>/demo/ds-footer.component.html</example-url>
 */
export declare class FooterComponent {
    leftMenus: FooterMenu[];
    rightMenus: FooterMenu[];
    className?: string;
}
