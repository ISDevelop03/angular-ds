import { theme } from './theme';
/**
 * Balance-formatterComponent
 *
 * Live demo:
 * <example-url>/demo/ds-balance-formatter.component.html</example-url>
 */
export declare class DsBalanceFormatterComponent {
    isDiscrete: boolean;
    variant: keyof typeof theme;
    balance: number;
    currency?: string;
    className?: string;
    currencyClassName?: string;
    noIcon: boolean;
    theme: {
        default: {
            wrapper: string;
            currency: string;
        };
    };
    readonly num: number;
    readonly wrapperClass: string;
    readonly iconClass: "text-green-500" | "text-red-500";
    readonly showIcon: boolean;
    readonly iconId: "plus2" | "minus";
}
