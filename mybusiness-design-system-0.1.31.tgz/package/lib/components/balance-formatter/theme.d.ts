export declare const theme: {
    default: {
        wrapper: string;
        currency: string;
    };
};
