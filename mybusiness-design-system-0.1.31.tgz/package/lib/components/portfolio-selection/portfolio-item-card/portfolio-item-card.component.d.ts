import { EventEmitter } from '@angular/core';
/**
 * Portfolio-item-cardComponent
 *
 * Live demo:
 * <example-url>/demo/ds-portfolio-item-card.component.html</example-url>
 */
export declare class PortfolioItemCardComponent {
    title: string;
    image: string;
    isSelected: boolean;
    className: string;
    clicked: EventEmitter<void>;
    handleClick(): void;
    getFirstTwoLetters: (title: string) => string;
}
