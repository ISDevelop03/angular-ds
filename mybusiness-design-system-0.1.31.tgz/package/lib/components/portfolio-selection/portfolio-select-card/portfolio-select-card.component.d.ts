import { EventEmitter } from '@angular/core';
/**
 * Portfolio-select-cardComponent
 *
 * Live demo:
 * <example-url>/demo/ds-portfolio-select-card.component.html</example-url>
 */
export declare class PortfolioSelectCardComponent {
    title: string;
    reference: string;
    image: string;
    isOpen: boolean;
    className: string;
    clicked: EventEmitter<void>;
    handleClick(): void;
    getFirstTwoLetters: (title: string) => string;
}
