import { EventEmitter } from '@angular/core';
/**
 * Portfolio-vision-cardComponent
 *
 * Live demo:
 * <example-url>/demo/ds-portfolio-vision-card.component.html</example-url>
 */
export declare class PortfolioVisionCardComponent {
    title: string;
    image: string;
    isSelected: boolean;
    className: string;
    clicked: EventEmitter<void>;
    handleClick(): void;
    getFirstTwoLetters: (title: string) => string;
}
