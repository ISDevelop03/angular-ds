import { EventEmitter, OnInit, Renderer2, OnChanges, SimpleChanges } from '@angular/core';
interface Portfolio {
    id: any;
    title: string;
    image: string;
    reference?: string;
}
/**
 * PortfolioComponent
 *
 * Live demo:
 * <example-url>/demo/ds-portfolio.component.html</example-url>
 */
export declare class PortfolioComponent implements OnInit, OnChanges {
    private renderer;
    portfolios: Portfolio[];
    selected: Portfolio | null;
    holding: Portfolio | null;
    show: boolean;
    showDots: boolean;
    perPage: number;
    totalItems: number;
    className: string;
    currentPage: number;
    totalPages: number;
    /** fire whenever user wants a different page */
    pageChange: EventEmitter<number>;
    clicked: EventEmitter<Portfolio>;
    displayPortfolio: boolean;
    selectedPortfolio: Portfolio;
    holdingPortfolio: Portfolio;
    constructor(renderer: Renderer2);
    readonly pages: number[];
    /** Get paginated portfolios for current page */
    getPaginatedPortfolios(): Portfolio[];
    /** Get start index for display */
    getStartIndex(): number;
    /** Get end index for display */
    getEndIndex(): number;
    ngOnInit(): void;
    /** Calculate total pages based on portfolios length and perPage */
    private calculateTotalPages;
    /** Handle input changes */
    ngOnChanges(changes: SimpleChanges): void;
    /** Go to next page if available */
    onNextPage(e: Event): void;
    /** Go to previous page if available */
    onPrevPage(event: Event): void;
    /** Go to specific page */
    onGoToPage(page: number): void;
    private resetState;
    togglePortfolio(): void;
    onSelect(portfolio: Portfolio): void;
    private setBodyScroll;
}
export {};
