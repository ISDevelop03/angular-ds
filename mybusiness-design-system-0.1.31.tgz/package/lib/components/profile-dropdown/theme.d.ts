export declare const positions: {
    topRight: string;
    topLeft: string;
    bottomRight: string;
    bottomLeft: string;
};
