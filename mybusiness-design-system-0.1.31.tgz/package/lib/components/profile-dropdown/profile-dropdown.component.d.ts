import { positions } from './theme';
import { ISelectItem } from './types';
/**
 * Profile-dropdownComponent
 *
 * Live demo:
 * <example-url>/demo/ds-profile-dropdown.component.html</example-url>
 */
export declare class ProfileDropdownComponent {
    className?: string;
    ulClassName?: string;
    list: ISelectItem[];
    children: string;
    position?: keyof typeof positions;
    suffix?: string;
    prefix?: string;
    isOpen: boolean;
    handleOpen: () => boolean;
    handleClose: () => boolean;
    positions: {
        topRight: string;
        topLeft: string;
        bottomRight: string;
        bottomLeft: string;
    };
}
