import { EventEmitter, OnChanges, SimpleChanges } from '@angular/core';
import { ToggleTheme } from './theme';
/**
 * ToggleComponent
 *
 * Live demo:
 * <example-url>/demo/ds-toggle.component.html</example-url>
 */
export declare class DsToggleComponent implements OnChanges {
    variant: keyof typeof ToggleTheme;
    className: string;
    disabled: boolean;
    checked: boolean;
    onChange: EventEmitter<boolean>;
    enabled: boolean;
    theme: {
        toggle: {
            default: {
                switch: {
                    className: string;
                    enabled: string;
                    disabled: string;
                    span: {
                        enabled: string;
                        disabled: string;
                        className: string;
                    };
                };
            };
        };
    };
    ngOnChanges(changes: SimpleChanges): void;
    toggleChecked(): void;
}
