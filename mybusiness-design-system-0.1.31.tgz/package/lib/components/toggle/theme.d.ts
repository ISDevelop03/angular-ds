export declare const ToggleTheme: {
    default: {
        switch: {
            className: string;
            enabled: string;
            disabled: string;
            span: {
                enabled: string;
                disabled: string;
                className: string;
            };
        };
    };
};
export declare const Theme: {
    toggle: {
        default: {
            switch: {
                className: string;
                enabled: string;
                disabled: string;
                span: {
                    enabled: string;
                    disabled: string;
                    className: string;
                };
            };
        };
    };
};
