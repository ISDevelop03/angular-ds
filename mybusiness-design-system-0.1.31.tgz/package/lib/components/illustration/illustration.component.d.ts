/**
 * IllustrationComponent
 *
 * Live demo:
 * <example-url>/demo/ds-illustration.component.html</example-url>
 */
export declare class IllustrationComponent {
    className?: string;
    src: string;
    size: 'lg' | 'md' | 'sm' | 'xs';
    readonly dimensions: {
        width: number;
        height: number;
    };
}
