/**
 * TotalListComponent
 *
 * Live demo:
 * <example-url>/demo/ds-total-list.component.html</example-url>
 */
export declare class TotalListComponent {
    className?: string;
    label: string;
    value: string;
    icon: string;
}
