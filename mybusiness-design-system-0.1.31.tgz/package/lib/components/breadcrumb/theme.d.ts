export declare const breadcrumb: {
    default: {
        wrapper: string;
        list: string;
        listElement: string;
        link: string;
        linkActive: string;
        separator: string;
    };
};
