import { breadcrumb } from './theme';
export interface Page {
    id: string;
    name: string;
    href?: string;
    current?: boolean;
}
/**
 * BreadcrumbComponent
 *
 * Live demo:
 * <example-url>/demo/ds-breadcrumb.component.html</example-url>
 */
export declare class DsBreadcrumbComponent {
    nextUrl?: string;
    nextClassName?: string;
    prevUrl?: string;
    prevClassName?: string;
    homeUrl?: string;
    className: string;
    variant: keyof typeof breadcrumb;
    pages: Page[];
    showLimit: boolean;
    readonly list: Page[];
    readonly lastPage: Page;
    readonly theme: {
        wrapper: string;
        list: string;
        listElement: string;
        link: string;
        linkActive: string;
        separator: string;
    };
}
