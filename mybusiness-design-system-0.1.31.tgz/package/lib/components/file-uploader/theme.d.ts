export interface FileUploaderTheme {
    wrapper: string;
    icon: string;
    text: string;
}
export declare const theme: {
    [key: string]: FileUploaderTheme;
};
