export declare const theme: {
    default: {
        wrapper: string;
        list: {
            container: string;
            tab: {
                base: string;
                selected: string;
                unselected: string;
            };
        };
        panels: {
            container: string;
            panel: {
                base: string;
            };
        };
    };
    noBackground: {
        wrapper: string;
        list: {
            container: string;
            tab: {
                base: string;
                selected: string;
                unselected: string;
            };
        };
        panels: {
            container: string;
            panel: {
                base: string;
            };
        };
    };
    withBorder: {
        wrapper: string;
        list: {
            container: string;
            tab: {
                base: string;
                selected: string;
                unselected: string;
            };
        };
        panels: {
            container: string;
            panel: {
                base: string;
            };
        };
    };
};
