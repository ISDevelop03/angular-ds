import { EventEmitter, TemplateRef } from '@angular/core';
import { theme } from './theme';
export interface ITab {
    title: string;
    panel: string | TemplateRef<any>;
    href?: string;
    link?: string;
    disabled?: boolean;
}
/**
 * TabsComponent
 *
 * Live demo:
 * <example-url>/demo/ds-tabs.component.html</example-url>
 */
export declare class DsTabsComponent {
    items: ITab[];
    className: string;
    variant: keyof typeof theme;
    rightContent?: TemplateRef<any>;
    onSelect: EventEmitter<any>;
    selectedIndex: number;
    theme: {
        default: {
            wrapper: string;
            list: {
                container: string;
                tab: {
                    base: string;
                    selected: string;
                    unselected: string;
                };
            };
            panels: {
                container: string;
                panel: {
                    base: string;
                };
            };
        };
        noBackground: {
            wrapper: string;
            list: {
                container: string;
                tab: {
                    base: string;
                    selected: string;
                    unselected: string;
                };
            };
            panels: {
                container: string;
                panel: {
                    base: string;
                };
            };
        };
        withBorder: {
            wrapper: string;
            list: {
                container: string;
                tab: {
                    base: string;
                    selected: string;
                    unselected: string;
                };
            };
            panels: {
                container: string;
                panel: {
                    base: string;
                };
            };
        };
    };
    selectTab(event: Event, tab: ITab, index: number): void;
    isSelected(index: number): boolean;
    isTemplate(ref: any): ref is TemplateRef<any>;
}
