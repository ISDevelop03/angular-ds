/**
 * LoaderComponent
 *
 * Live demo:
 * <example-url>/demo/ds-loader.component.html</example-url>
 */
export declare class LoaderComponent {
    className?: string;
    showLoader: boolean;
    showOverlay: boolean;
    type: 'fill' | 'contained';
}
