export interface SignataireItem {
    label: string;
    value: string;
    dateLabel: string;
    dateValue: string;
}
/**
 * SignataireListComponent
 *
 * Live demo:
 * <example-url>/demo/ds-signataire-list.component.html</example-url>
 */
export declare class SignataireListComponent {
    items: any[];
    className?: string;
}
