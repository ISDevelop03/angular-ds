import { theme } from './theme';
/**
 * LabelComponent
 *
 * Live demo:
 * <example-url>/demo/ds-label.component.html</example-url>
 */
export declare class LabelComponent {
    variant: keyof typeof theme;
    for: string;
    required?: boolean;
    disabled: boolean;
    className?: string;
    theme: {
        default: {
            base: string;
        };
    };
}
