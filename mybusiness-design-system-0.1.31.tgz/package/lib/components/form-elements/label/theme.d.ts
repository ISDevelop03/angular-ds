export declare const theme: {
    default: {
        base: string;
    };
};
