import { EventEmitter, ElementRef, Renderer2, AfterViewInit } from '@angular/core';
/**
 * CodeInputComponent
 *
 * Live demo:
 * <example-url>/demo/ds-code-input.component.html</example-url>
 */
export declare class CodeInputComponent implements AfterViewInit {
    private host;
    private renderer;
    id: string;
    name: string;
    label?: string;
    placeholder?: string;
    disabled: boolean;
    value: any;
    className?: string;
    copied: EventEmitter<any>;
    inner: ElementRef;
    hasProjectedPrefix: boolean;
    hasProjectedSuffix: boolean;
    isCopied: boolean;
    constructor(host: ElementRef, renderer: Renderer2);
    ngAfterViewInit(): void;
    copyToClipboard(): void;
}
