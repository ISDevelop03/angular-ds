import { EventEmitter, OnInit, ElementRef, SimpleChanges } from '@angular/core';
import { UploadFileTheme } from './theme';
/**
 * Upload-fileComponent
 *
 * Live demo:
 * <example-url>/demo/ds-upload-file.component.html</example-url>
 */
export declare class UploadFileComponent implements OnInit {
    variant: string;
    maxFileSizeMB: number;
    allowedExtensions: string[];
    className: string;
    isMultiple: boolean;
    errors: string[];
    hasError: boolean;
    progress: number;
    loading: boolean;
    ngOnChanges(changes: SimpleChanges): void;
    /** If true, we'll fake the upload progress (instead of immediately reading). */
    simulateSlowUpload: boolean;
    fileSelected: EventEmitter<File>;
    fileInput: ElementRef<HTMLInputElement>;
    theme: {
        [key: string]: UploadFileTheme;
    };
    currentTheme: UploadFileTheme;
    /** for preview */
    selectedFile: File | null;
    selectedFiles: (File & {
        uniqueId: string;
    })[];
    previewRows: string[][];
    /** for errors accordion */
    showErrors: boolean;
    ngOnInit(): void;
    openFileInput(): void;
    private generateUniqueId;
    private addUniqueIdToFile;
    onFileChange(evt: Event): void;
    onDrop(evt: DragEvent): void;
    onDragOver(evt: DragEvent): void;
    private handleMultipleFiles;
    removeFile(uniqueId: string): void;
    toggleErrors(): void;
    private handleFile;
    getErrorsContent(): string;
}
