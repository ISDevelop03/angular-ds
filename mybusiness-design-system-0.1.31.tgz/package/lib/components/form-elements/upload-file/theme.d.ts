export interface UploadFileTheme {
    wrapper: string;
    icon: string;
    text: string;
}
export declare const uploadFileThemes: {
    [key: string]: UploadFileTheme;
};
