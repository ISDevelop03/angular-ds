import { EventEmitter, ElementRef } from '@angular/core';
import { RangeVariant } from './theme';
export declare class DsRangeComponent {
    rangeType: 'single' | 'range';
    min: number;
    unit: string;
    max: number;
    step: number;
    value: number;
    valueChange: EventEmitter<number>;
    values: [number, number];
    valuesChange: EventEmitter<[number, number]>;
    variant: RangeVariant;
    theme: {
        default: {
            container: string;
            track: string;
            range: string;
            thumb: string;
        };
    };
    trackEl: ElementRef<HTMLDivElement>;
    private dragging;
    singleTrackEl: ElementRef<HTMLDivElement>;
    private singleDragging;
    readonly percentRange: {
        min: number;
        max: number;
    };
    onRangePointerDown(e: PointerEvent): void;
    private onPointerMove;
    private onPointerUp;
    private setThumbValue;
    ngOnDestroy(): void;
    /** percent position for single thumb */
    readonly percent: number;
    onSingleChange(e: Event): void;
    onMinChange(e: Event): void;
    onMaxChange(e: Event): void;
    onSinglePointerDown(e: PointerEvent): void;
    private onSinglePointerMove;
    private onSinglePointerUp;
    private setSingleValueFromX;
    private clamp;
}
