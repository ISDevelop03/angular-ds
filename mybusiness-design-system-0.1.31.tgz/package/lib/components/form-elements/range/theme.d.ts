export declare const range: {
    input: {
        defaultThumb: string;
    };
};
export declare const RangeSelectorTheme: {
    default: {
        container: string;
        track: string;
        range: string;
        thumb: string;
    };
};
export declare type RangeVariant = keyof typeof RangeSelectorTheme;
