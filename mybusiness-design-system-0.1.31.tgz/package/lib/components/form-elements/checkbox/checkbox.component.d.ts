import { checkbox } from './theme';
/**
 * CheckboxComponent
 *
 * Live demo:
 * <example-url>/demo/ds-checkbox.component.html</example-url>
 */
export declare class DsCheckboxComponent {
    variant: keyof typeof checkbox;
    name?: string;
    checked: boolean;
    disabled: boolean;
    hasError: boolean;
    value?: string;
    label?: string;
    errorMessage?: string;
    className?: string;
    isIndeterminate?: boolean;
    change: () => void;
    checkbox: {
        default: {
            wrapper: string;
            checkbox: {
                base: string;
                enabled: {
                    checked: string;
                    unchecked: string;
                };
                disabled: {
                    checked: string;
                    unchecked: string;
                };
                error: string;
                label: {
                    base: string;
                    checked: string;
                    disabled: string;
                };
            };
            errorMessage: string;
        };
        autocomplete: {
            wrapper: string;
            checkbox: {
                base: string;
                enabled: {
                    checked: string;
                    unchecked: string;
                };
                disabled: {
                    checked: string;
                    unchecked: string;
                };
                error: string;
                label: {
                    base: string;
                    checked: string;
                    disabled: string;
                };
            };
            errorMessage: string;
        };
    };
    readonly wrapperClass: string;
    readonly checkboxClass: string;
    readonly labelClass: string;
}
