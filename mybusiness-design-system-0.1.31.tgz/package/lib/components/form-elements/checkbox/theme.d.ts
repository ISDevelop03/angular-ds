export declare const checkbox: {
    default: {
        wrapper: string;
        checkbox: {
            base: string;
            enabled: {
                checked: string;
                unchecked: string;
            };
            disabled: {
                checked: string;
                unchecked: string;
            };
            error: string;
            label: {
                base: string;
                checked: string;
                disabled: string;
            };
        };
        errorMessage: string;
    };
    autocomplete: {
        wrapper: string;
        checkbox: {
            base: string;
            enabled: {
                checked: string;
                unchecked: string;
            };
            disabled: {
                checked: string;
                unchecked: string;
            };
            error: string;
            label: {
                base: string;
                checked: string;
                disabled: string;
            };
        };
        errorMessage: string;
    };
};
