export declare const textarea: {
    default: {
        base: string;
        label: string;
        counter: string;
        resize: string;
        description: string;
        errorMessage: string;
        hasError: string;
        disabled: string;
    };
};
