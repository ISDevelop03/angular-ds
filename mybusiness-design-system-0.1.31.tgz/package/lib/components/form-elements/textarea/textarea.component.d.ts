import { EventEmitter, OnChanges, SimpleChanges, TemplateRef } from '@angular/core';
import { textarea } from './theme';
/**
 * TextareaComponent
 *
 * Live demo:
 * <example-url>/demo/ds-textarea.component.html</example-url>
 */
export declare class DsTextareaComponent implements OnChanges {
    variant: keyof typeof textarea;
    placeholder?: string;
    name?: string;
    disabled: boolean;
    hasError: boolean;
    errorMessage?: string;
    description?: string;
    rows: number;
    maxLength?: number;
    resize: boolean;
    label?: string;
    required: boolean;
    tooltip?: string | TemplateRef<any>;
    value: string;
    valueChange: EventEmitter<string>;
    textarea: {
        default: {
            base: string;
            label: string;
            counter: string;
            resize: string;
            description: string;
            errorMessage: string;
            hasError: string;
            disabled: string;
        };
    };
    ngOnChanges(changes: SimpleChanges): void;
    onTextareaChange(event: Event): void;
    readonly classes: string;
}
