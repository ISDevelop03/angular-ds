import { EventEmitter } from '@angular/core';
import { radio } from './theme';
/**
 * RadioComponent
 *
 * Live demo:
 * <example-url>/demo/ds-radio.component.html</example-url>
 */
export declare class DsRadioComponent {
    variant: keyof typeof radio;
    name?: string;
    value?: string;
    disabled: boolean;
    hasError: boolean;
    label?: string;
    errorMessage?: string;
    className?: string;
    modelValue?: string;
    modelValueChange: EventEmitter<string>;
    radio: {
        default: {
            wrapper: string;
            base: string;
            enabled: {
                checked: string;
                unchecked: string;
            };
            disabled: {
                checked: string;
                unchecked: string;
            };
            icon: {
                base: string;
                enabled: string;
                disabled: string;
            };
            error: string;
            label: {
                base: string;
                disabled: string;
                unchecked: string;
                checked: string;
                error: string;
            };
        };
    };
    readonly checked: boolean;
    readonly wrapperClass: string;
    readonly radioClass: string;
    readonly labelClass: string;
    onInputChange(): void;
}
