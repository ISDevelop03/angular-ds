import { EventEmitter, ElementRef, Renderer2, AfterViewInit, TemplateRef } from '@angular/core';
import { input } from './theme';
import { ControlValueAccessor } from '@angular/forms';
/**
 * InputComponent
 *
 * Live demo:
 * <example-url>/demo/ds-input.component.html</example-url>
 */
export declare class DsInputComponent implements AfterViewInit, ControlValueAccessor {
    private host;
    private renderer;
    id: string;
    name: string;
    label?: string;
    variant: keyof typeof input;
    display?: 'inline' | 'block';
    placeholder?: string;
    prefix?: string;
    suffix?: string;
    type: string;
    hasError: boolean;
    errorMessage?: string;
    description?: string;
    disabled: boolean;
    required: boolean;
    value: any;
    className?: string;
    inputClassName?: string;
    tooltip?: string | TemplateRef<any>;
    password: boolean;
    autoComplete: 'on' | 'off';
    passwordVisible: boolean;
    onClick: EventEmitter<Event>;
    onInput: EventEmitter<Event>;
    onChange: EventEmitter<Event>;
    onFocus: EventEmitter<FocusEvent>;
    onBlur: EventEmitter<FocusEvent>;
    onKeydown: EventEmitter<KeyboardEvent>;
    onKeyup: EventEmitter<KeyboardEvent>;
    onEnter: EventEmitter<KeyboardEvent>;
    onEscape: EventEmitter<KeyboardEvent>;
    onPaste: EventEmitter<ClipboardEvent>;
    onSelect: EventEmitter<UIEvent>;
    inner: ElementRef;
    input: {
        default: {
            container: string;
            wrapper: {
                base: string;
                enabled: string;
                disabled: string;
            };
            label: string;
            input: string;
            prefix: string;
            sufix: string;
            errorMessage: string;
            hasError: string;
            description: string;
        };
        search: {
            container: string;
            wrapper: {
                base: string;
                enabled: string;
                disabled: string;
            };
            label: string;
            input: string;
            prefix: string;
            sufix: string;
            errorMessage: string;
            hasError: string;
            description: string;
        };
    };
    hasProjectedPrefix: boolean;
    hasProjectedSuffix: boolean;
    constructor(host: ElementRef, renderer: Renderer2);
    private _onChange;
    private _onTouched;
    writeValue(value: any): void;
    registerOnChange(fn: any): void;
    registerOnTouched(fn: any): void;
    setDisabledState?(isDisabled: boolean): void;
    onNativeInput(event: Event): void;
    onNativeBlur(event: FocusEvent): void;
    togglePassword(): void;
    ngAfterViewInit(): void;
}
