export declare const input: {
    default: {
        container: string;
        wrapper: {
            base: string;
            enabled: string;
            disabled: string;
        };
        label: string;
        input: string;
        prefix: string;
        sufix: string;
        errorMessage: string;
        hasError: string;
        description: string;
    };
    search: {
        container: string;
        wrapper: {
            base: string;
            enabled: string;
            disabled: string;
        };
        label: string;
        input: string;
        prefix: string;
        sufix: string;
        errorMessage: string;
        hasError: string;
        description: string;
    };
};
