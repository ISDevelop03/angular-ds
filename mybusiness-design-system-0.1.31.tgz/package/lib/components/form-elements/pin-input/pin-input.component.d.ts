import { EventEmitter } from '@angular/core';
export declare class PinInputComponent {
    isCodeHidden: boolean;
    codeLength: number;
    isCharsCode: boolean;
    inputType: 'text' | 'tel' | 'password';
    isPrevFocusableAfterClearing: boolean;
    isFocusingOnLastByClickIfFilled: boolean;
    initialFocusField: number;
    code: number | string;
    disabled: boolean;
    autocapitalize: string;
    className: string;
    onCodeChanged: EventEmitter<{}>;
    onCodeCompleted: EventEmitter<{}>;
}
