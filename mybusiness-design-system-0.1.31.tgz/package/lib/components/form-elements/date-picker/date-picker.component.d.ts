import { EventEmitter } from '@angular/core';
export declare class DatePickerComponent {
    type: 'single' | 'range';
    autoApply: boolean;
    linkedCalendars: boolean;
    showDropdowns: boolean;
    alwaysShowCalendars: boolean;
    keepCalendarOpeningWithRange: boolean;
    showRangeLabelOnInput: boolean;
    customRangeDirection: boolean;
    lockStartDate: boolean;
    minDate: any;
    maxDate: any;
    dateLimit: any;
    selected: any;
    choosedDate: EventEmitter<any>;
    isCustomDate: EventEmitter<any>;
    rangeClicked: EventEmitter<any>;
    datesUpdated: EventEmitter<any>;
    choosedDateHandler(event: any): void;
    isCustomDateHandler(value: any): void;
}
