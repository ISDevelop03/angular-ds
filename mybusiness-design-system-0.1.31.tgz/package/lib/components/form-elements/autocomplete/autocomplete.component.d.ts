import { ElementRef, EventEmitter, OnInit, SimpleChanges } from '@angular/core';
import { ControlValueAccessor } from '@angular/forms';
interface IField {
    label: string;
    value: string;
    checked?: boolean;
}
interface IEventEmitter<T> {
    event: Event;
    values: T[];
    field: T;
}
/**
 * AutocompleteComponent
 *
 * Live demo:
 * <example-url>/demo/ds-autocomplete.component.html</example-url>
 */
export declare class AutocompleteComponent implements ControlValueAccessor, OnInit {
    private host;
    className: string;
    placeholder: string;
    items: IField[];
    values: IField[];
    valuesChange: EventEmitter<IField[]>;
    onSelect: EventEmitter<IEventEmitter<IField>>;
    inputRef: ElementRef<HTMLInputElement>;
    private onChange;
    private onTouched;
    constructor(host: ElementRef);
    value: string;
    showDropdown: boolean;
    filteredItems: IField[];
    ngOnInit(): void;
    ngOnChanges(changes: SimpleChanges): void;
    writeValue(vals: IField[]): void;
    registerOnChange(fn: any): void;
    registerOnTouched(fn: any): void;
    private emitValues;
    onInput(event: Event): void;
    onSelectItem(event: Event, field: IField): void;
    onDeleteBadge(event: Event, field: IField): void;
    /** When user hits backspace on empty input, remove last badge */
    onBackspace(): void;
    private _setChecked;
    private _syncCheckedFlags;
    private _notifyChange;
    private _closeAndRefocus;
    getCheckedItems(item: IField): boolean;
    onClickOutside(target: HTMLElement): void;
}
export {};
