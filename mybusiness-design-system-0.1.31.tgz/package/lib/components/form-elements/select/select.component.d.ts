import { EventEmitter, ElementRef, OnDestroy, OnChanges, SimpleChanges, TemplateRef } from '@angular/core';
import { theme } from './theme';
import { ControlValueAccessor } from '@angular/forms';
export interface SelectItem {
    value: string;
    label: string;
    unavailable?: boolean;
    icon?: string;
    image?: string;
    isAccount?: boolean;
    iconClass?: string;
    imageClass?: string;
}
/**
 * SelectComponent
 *
 * Live demo:
 * <example-url>/demo/ds-select.component.html</example-url>
 */
export declare class DsSelectComponent implements ControlValueAccessor, OnDestroy, OnChanges {
    items: SelectItem[];
    label?: string;
    errorMessage?: string;
    placeholder: string;
    variant: keyof typeof theme;
    disabled: boolean;
    hasError: boolean;
    pill: boolean;
    emptyLabel: string;
    multiple: boolean;
    isLoading: boolean;
    className?: string;
    buttonIcon?: string;
    value: string | string[] | null;
    customOptionsStyles?: {
        [key: string]: any;
    };
    autoComplete?: boolean;
    debounceTime: number;
    description?: string;
    tooltip?: string | TemplateRef<any>;
    required: boolean;
    allowClear: boolean;
    onSearch: EventEmitter<string>;
    valueChange: EventEmitter<any>;
    searchable: boolean;
    filteredItems: SelectItem[];
    searchTerm: string;
    clearSelection(): void;
    ngOnInit(): void;
    ngOnChanges(changes: SimpleChanges): void;
    private static zIndexCounter;
    private destroy$;
    isOpen: boolean;
    containerPosition: {
        [key: string]: any;
    };
    containerStyles: {};
    triggerButton?: ElementRef;
    optionsContainer?: ElementRef;
    theme: {
        default: {
            element: {
                label: string;
                button: {
                    select: string;
                    selected: string;
                    error: string;
                    iconeError: string;
                    disabled: string;
                    label: string;
                    placeholder: string;
                };
                field: {
                    activated: string;
                };
                icone: {
                    arrow: string;
                    checked: string;
                };
                options: {
                    selectedfont: string;
                    container: string;
                    element: string;
                    fontcolor: string;
                    available: string;
                    unavailable: string;
                };
                error: string;
                description: string;
            };
        };
        currency: {
            element: {
                label: string;
                button: {
                    select: string;
                    selected: string;
                    error: string;
                    iconeError: string;
                    disabled: string;
                    label: string;
                    placeholder: string;
                };
                field: {
                    activated: string;
                };
                icone: {
                    arrow: string;
                    checked: string;
                };
                options: {
                    selectedfont: string;
                    container: string;
                    element: string;
                    fontcolor: string;
                    available: string;
                    unavailable: string;
                };
                error: string;
                description: string;
            };
        };
    };
    private _onChange;
    private _onTouched;
    ngOnDestroy(): void;
    onSearchInput(searchTerm: string): void;
    writeValue(obj: any): void;
    registerOnChange(fn: any): void;
    registerOnTouched(fn: any): void;
    setDisabledState(isDisabled: boolean): void;
    readonly mergedStyles: {
        [key: string]: any;
    } & {
        [key: string]: any;
    };
    toggleDropdown(): void;
    calculatePosition(): void;
    selectOption(event: any, item: SelectItem): void;
    isSelected(item: SelectItem): boolean;
    readonly selected: SelectItem | SelectItem[];
    readonly selectedAsArray: SelectItem[];
    readonly selectedItem: SelectItem;
    onClickOutside(event: MouseEvent): void;
    onEscClose(event: KeyboardEvent): void;
    removeItem(item: SelectItem): void;
}
