import { ActionItem } from './theme';
/**
 * Actions-layoutComponent
 *
 * Live demo:
 * <example-url>/demo/ds-actions-layout.component.html</example-url>
 */
export declare class DsActionsLayoutComponent {
    items: ActionItem[];
    className: string;
    selectedClass: string;
    selectedElement: number | null;
    onClick(item: ActionItem, index: number): void;
    isSelected(index: number): boolean;
}
