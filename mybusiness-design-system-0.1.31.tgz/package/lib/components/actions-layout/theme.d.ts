export declare type ActionItem = {
    iconId: string;
    iconIdFilled: string;
    handler: () => void;
    className?: string;
    badge?: boolean;
    disabled?: boolean;
};
export declare const MOCKDATA: ActionItem[];
