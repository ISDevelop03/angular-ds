import { TTransferAmount } from '../virement-card/virement-card.component';
export declare type TRecapItems = {
    beneficiaryName: string;
    beneficiaryAccountNumber: string;
    motif: string;
    amount: TTransferAmount;
};
/**
 * VirementCardRecapComponent
 *
 * Live demo:
 * <example-url>/demo/ds-virement-card-recap.component.html</example-url>
 */
export declare class VirementCardRecapComponent {
    className?: string;
    items: TRecapItems[];
}
