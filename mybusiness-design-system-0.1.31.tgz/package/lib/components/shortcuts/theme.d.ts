export declare const Theme: {
    shortcutCard: {
        container: string;
        iconWrapper: string;
        text: string;
    };
};
