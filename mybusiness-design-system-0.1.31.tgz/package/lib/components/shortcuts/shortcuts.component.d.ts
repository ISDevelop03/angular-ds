import { ElementRef, EventEmitter } from '@angular/core';
export interface ShortcutItem {
    icon: string;
    title: string;
    href?: string;
    isShortcut?: boolean;
}
export interface DropdownShortcut {
    title: string;
    href?: string;
    isSelected?: boolean;
    onClick: (data: any) => void;
}
/**
 * ShortcutsComponent
 *
 * Live demo:
 * <example-url>/demo/ds-shortcuts.component.html</example-url>
 */
export declare class DsShortcutsCardComponent {
    private host;
    items: ShortcutItem[];
    shortcuts: DropdownShortcut[];
    className?: string;
    click: EventEmitter<any>;
    removed: EventEmitter<{
        item: DropdownShortcut;
        idx: number;
    }>;
    private openIdx;
    isOpen: boolean;
    theme: {
        shortcutCard: {
            container: string;
            iconWrapper: string;
            text: string;
        };
    };
    constructor(host: ElementRef);
    onClick(data: {
        item: ShortcutItem;
        idx: number;
    }, event: MouseEvent): void;
    removeShortcut(data: {
        item: DropdownShortcut;
        idx: number;
    }, event: MouseEvent): void;
    onItemClick(item: ShortcutItem, idx: number, event: MouseEvent): void;
    remove(item: ShortcutItem, idx: number, event: MouseEvent): void;
    selectShortcut(shortcut: DropdownShortcut, idx: number, event: MouseEvent): void;
    onDocumentClick(event: MouseEvent): void;
}
