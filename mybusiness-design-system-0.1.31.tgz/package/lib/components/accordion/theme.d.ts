export declare const theme: {
    default: {
        container: string;
        disclosure: string;
        button: {
            base: string;
            title: string;
            active: string;
            titleWrapper: string;
            icon: {
                base: string;
                classActive: string;
                classInactive: string;
                inactiveId: string;
                activeId: string;
                size: string;
            };
        };
        panel: {
            base: string;
        };
    };
    borderless: {
        container: string;
        disclosure: string;
        button: {
            base: string;
            active: string;
            title: string;
            titleWrapper: string;
            icon: {
                base: string;
                classActive: string;
                classInactive: string;
                inactiveId: string;
                activeId: string;
                size: string;
            };
        };
        panel: {
            base: string;
        };
    };
    'borderless-reversed': {
        container: string;
        disclosure: string;
        button: {
            base: string;
            active: string;
            title: string;
            titleWrapper: string;
            icon: {
                base: string;
                classActive: string;
                classInactive: string;
                inactiveId: string;
                activeId: string;
                size: string;
            };
        };
        panel: {
            base: string;
        };
    };
    shadowless: {
        container: string;
        disclosure: string;
        button: {
            base: string;
            title: string;
            active: string;
            titleWrapper: string;
            icon: {
                base: string;
                classActive: string;
                classInactive: string;
                inactiveId: string;
                activeId: string;
                size: string;
            };
        };
        panel: {
            base: string;
        };
    };
};
