export declare const theme: {
    overlay: string;
    base: string;
    panel: string;
};
