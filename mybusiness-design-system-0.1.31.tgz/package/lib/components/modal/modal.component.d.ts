import { EventEmitter } from '@angular/core';
/**
 * ModalComponent
 *
 * Live demo:
 * <example-url>/demo/ds-modal.component.html</example-url>
 */
export declare class ModalComponent {
    isShown: boolean;
    icon?: string;
    type?: 'success' | 'warning' | 'error' | 'info';
    title?: string;
    description?: string;
    mainAction?: string;
    secondaryAction?: string;
    className?: string;
    close: EventEmitter<void>;
    mainActionOnClick: EventEmitter<void>;
    secondaryActionOnClick: EventEmitter<void>;
    theme: {
        overlay: string;
        base: string;
        panel: string;
    };
    onEscPressed(_event: KeyboardEvent): void;
    onClose(): void;
    onBackdropClick(event: MouseEvent): void;
    onSecondaryActionOnClick(): void;
    onMainActionOnClick(): void;
}
