export declare const SliderDotsTheme: {
    /**
     * ──────────────────────────────────────────────────────────────────────────────
     * DEFAULT VARIANT
     * ──────────────────────────────────────────────────────────────────────────────
     */
    default: {
        container: string;
        dotsWrapper: string;
        dot: {
            base: string;
            size: string;
            activeBg: string;
            inactiveBg: string;
        };
        arrow: {
            wrapper: string;
            activeText: string;
            disabledText: string;
            disabledOpacity: string;
        };
    };
};
