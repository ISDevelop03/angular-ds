import { EventEmitter } from '@angular/core';
import { SliderDotsTheme } from './theme';
declare type ThemeKey = keyof typeof SliderDotsTheme;
/**
 * SliderDotsComponent
 *
 * Live demo:
 * <example-url>/demo/ds-slider-dots.component.html</example-url>
 */
export declare class SliderDotsComponent {
    /**
     * Number of dots/slides to display.
     * Must be ≥ 1.
     **/
    count: number;
    className: string;
    /** 0-based index of the currently “active” slide. */
    active: number;
    doNotDisableArrows: boolean;
    /**
     * Which theme (variant) from SliderDotsTheme to use.
     * E.g. 'default', 'red', or any other key in SliderDotsTheme.
     */
    variant: ThemeKey;
    /** If false, arrows are completely hidden. */
    showArrows: boolean;
    /** Emits the chosen dot index (0-based) when the user clicks a dot. */
    select: EventEmitter<number>;
    /** Emits when user clicks the “Prev” arrow (if not disabled). */
    prev: EventEmitter<void>;
    /** Emits when user clicks the “Next” arrow (if not disabled). */
    next: EventEmitter<void>;
    /**
     * Convenience getter: returns the theme object for the current `themeName`,
     * or falls back to `default` if the key is missing.
     */
    readonly theme: {
        container: string;
        dotsWrapper: string;
        dot: {
            base: string;
            size: string;
            activeBg: string;
            inactiveBg: string;
        };
        arrow: {
            wrapper: string;
            activeText: string;
            disabledText: string;
            disabledOpacity: string;
        };
    };
    /** Build an array [0, 1, 2, …, count-1] to loop over in the template. */
    readonly indices: number[];
    /** Is “Prev” arrow currently disabled (because active is already 0)? */
    readonly isPrevDisabled: boolean;
    /** Is “Next” arrow currently disabled (because active is at count-1)? */
    readonly isNextDisabled: boolean;
    /** Handler for clicking Prev: only emit if not disabled. */
    onPrev(): void;
    /** Handler for clicking Next: only emit if not disabled. */
    onNext(): void;
    /** Handler for clicking a dot at index i: only emit if i !== active. */
    onSelect(i: number): void;
    /**
     * CSS classes for the “Prev” arrow’s wrapper.
     * If disabled, append the `disabledOpacity` classes.
     */
    readonly prevArrowWrapperClass: string;
    /**
     * CSS classes for the “Next” arrow’s wrapper.
     * If disabled, append the `disabledOpacity` classes.
     */
    readonly nextArrowWrapperClass: string;
    /**
     * CSS classes for the <ds-icon> inside **both** arrows, when “enabled.”
     * (We assume the icon’s color should match `activeText`.)
     * When disabled, we replace that with `disabledText`.
     */
    readonly prevIconClass: string;
    readonly nextIconClass: string;
}
export {};
