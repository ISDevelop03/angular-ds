import { ElementRef, OnDestroy, OnInit, TemplateRef, ViewContainerRef, ChangeDetectorRef, ApplicationRef, ComponentFactoryResolver, Injector, EventEmitter } from '@angular/core';
/**
 * DropdownHolderComponent
 *
 * Live demo:
 * <example-url>/demo/ds-dropdown-holder.component.html</example-url>
 */
export declare class DropdownHolderComponent implements OnInit, OnDestroy {
    private cd;
    private vcr;
    private cfr;
    private appRef;
    private injector;
    private document;
    className: string;
    containerClassName: string;
    buttonContent: ElementRef<any>;
    toggle: EventEmitter<boolean>;
    trigger: ElementRef;
    menuTpl: TemplateRef<any>;
    menu: ElementRef;
    isOpen: boolean;
    menuStyles: {
        [key: string]: string;
    };
    private portalHost;
    private menuPortal;
    constructor(cd: ChangeDetectorRef, vcr: ViewContainerRef, cfr: ComponentFactoryResolver, appRef: ApplicationRef, injector: Injector, document: any);
    ngOnInit(): void;
    ngOnDestroy(): void;
    toggleMenu(): void;
    private setMenuPosition;
    closeMenu(): void;
    onItemClick(event: any, cb?: (event: any) => void): void;
    handleOutsideClick: (e: MouseEvent) => void;
    stopEvent(event: MouseEvent): void;
    private static zIndexCounter;
}
