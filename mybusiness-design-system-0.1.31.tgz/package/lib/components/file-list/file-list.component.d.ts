import { EventEmitter } from '@angular/core';
export declare type UploadedFiles = {
    file: File & {
        id: string;
    };
    progress?: number;
    status?: 'uploading' | 'success' | 'error';
    errors?: null | string[];
};
/**
 * FileListComponent
 *
 * Live demo:
 * <example-url>/demo/ds-file-list.component.html</example-url>
 */
export declare class FileListComponent {
    className?: string;
    files: UploadedFiles[];
    isMultiple: boolean;
    isDownloadable: boolean;
    maxHeight: number | undefined;
    showErrorButtonUpload: boolean;
    onDelete: EventEmitter<{}>;
    onReUpload: EventEmitter<{}>;
    onDownload: EventEmitter<{}>;
    onDownloadErrors: EventEmitter<{}>;
    private errorVisibilityMap;
    isErrorVisible(fileId: string): boolean;
    toggleErrors(fileId: string): void;
    removeFile(fileId: string): void;
    downloadFile(file: File): void;
    formatFileSize(sizeInBytes: number): string;
}
