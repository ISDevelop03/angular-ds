import { TemplateRef } from '@angular/core';
/**
 * BoxCheckboxComponent
 *
 * Live demo:
 * <example-url>/demo/ds-box-checkbox.component.html</example-url>
 */
export declare class BoxCheckboxComponent {
    className?: string;
    checked: boolean;
    disabled: boolean;
    label?: string;
    tooltip?: string | TemplateRef<any>;
    change: () => void;
}
