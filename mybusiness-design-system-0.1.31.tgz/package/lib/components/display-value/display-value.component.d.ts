/**
 * @ignore
 */
export declare class DsDisplayValueComponent {
    value: any;
    className?: string;
    readonly hasValue: boolean;
}
