import { ChangeDetectorRef, ElementRef } from '@angular/core';
interface IBadge {
    icon?: string;
    label: string;
    href?: string;
    pill: boolean;
    variant: string;
    size: string;
    outline: boolean;
    withDot: boolean;
    iconRight: boolean;
    className: string;
}
/**
 * BadgeGroupComponent
 *
 * Live demo:
 * <example-url>/demo/ds-badge-group.component.html</example-url>
 */
export declare class BadgeGroupComponent {
    private cdr;
    private host;
    className: string;
    moreClassName: string;
    moreIcon: string;
    moreIconSize: string;
    tags: IBadge[];
    showInvisibleTags: boolean;
    container: ElementRef<HTMLDivElement>;
    visibleTags: IBadge[];
    invisibleTags: IBadge[];
    overflowCount: number;
    constructor(cdr: ChangeDetectorRef, host: ElementRef<HTMLElement>);
    toggleInvisibleTags(event: Event): void;
    private calculateOverflow;
    ngAfterViewInit(): void;
    onWindowResize(): void;
    onClickOutside(target: HTMLElement): void;
}
export {};
