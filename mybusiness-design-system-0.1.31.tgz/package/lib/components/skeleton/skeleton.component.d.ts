/**
 * SkeletonComponent
 *
 * Live demo:
 * <example-url>/demo/ds-skeleton.component.html</example-url>
 */
export declare class SkeletonComponent {
    className?: string;
}
