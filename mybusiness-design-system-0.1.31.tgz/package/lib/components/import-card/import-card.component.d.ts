import { EventEmitter } from '@angular/core';
export interface ImportCardAction {
    label: string;
    icon: string;
    onClick: () => void;
}
/**
 * ImportCardComponent
 *
 * Live demo:
 * <example-url>/demo/ds-import-card.component.html</example-url>
 */
export declare class ImportCardComponent {
    className?: string;
    title: string;
    description: string;
    actions: ImportCardAction[];
    icon?: string;
    onClick: EventEmitter<any>;
    handleCardClick(): void;
}
