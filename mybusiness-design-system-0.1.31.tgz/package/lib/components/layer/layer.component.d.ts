import { EventEmitter } from '@angular/core';
/**
 * LayerComponent
 *
 * Live demo:
 * <example-url>/demo/ds-layer.component.html</example-url>
 */
export declare class LayerComponent {
    className?: string;
    isOpen: boolean;
    isOpenChange: EventEmitter<boolean>;
    onClose(): void;
}
