export declare const theme: {
    base: string;
    variants: {
        base: string;
        neutral: {
            bar: string;
            progress: string;
        };
        success: {
            bar: string;
            progress: string;
        };
        warning: {
            bar: string;
            progress: string;
        };
        error: {
            bar: string;
            progress: string;
        };
    };
};
