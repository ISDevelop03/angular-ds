/**
 * ProgressComponent
 *
 * Live demo:
 * <example-url>/demo/ds-progress.component.html</example-url>
 */
export declare class ProgressComponent {
    variant: 'neutral' | 'success' | 'warning' | 'error';
    type: 'inline' | 'block';
    label?: string;
    percentage: number;
    suffix: string;
    total?: number;
    className?: string;
    appliedTheme: {
        base: string;
        variants: {
            base: string;
            neutral: {
                bar: string;
                progress: string;
            };
            success: {
                bar: string;
                progress: string;
            };
            warning: {
                bar: string;
                progress: string;
            };
            error: {
                bar: string;
                progress: string;
            };
        };
    };
    readonly calcPercentage: number;
}
