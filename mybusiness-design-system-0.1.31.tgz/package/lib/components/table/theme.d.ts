export declare type TableVariant = 'default' | 'secondary' | 'bordered';
export interface TableTheme {
    table: string;
    header: string;
    headerCell: string;
    headerTh: string;
    headerText: string;
    headerIcons: string;
    headerCellSortable: string;
    headerCellButton: string;
    body: string;
    row: (index: number) => string;
    cell: string;
}
export declare const TableThemes: Record<TableVariant, TableTheme>;
