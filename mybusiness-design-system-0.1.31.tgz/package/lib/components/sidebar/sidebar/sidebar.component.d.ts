import { EventEmitter } from '@angular/core';
import { IMenus, IMainMenu, ILanguage, Cap } from '../types';
import { ISelectItem } from '../../profile-dropdown/types';
/**
 * SidebarComponent
 *
 * Live demo:
 * <example-url>/demo/ds-sidebar.component.html</example-url>
 */
export declare class DsSidebarComponent {
    className: string;
    profileMenus: ISelectItem[];
    mainMenus: IMainMenu[];
    disableMainMenus: boolean;
    disableBottomMenus: boolean;
    sizes: Cap[];
    defaultCap: Cap;
    logo: string;
    miniLogo: string;
    language: ILanguage;
    onThemeChange: EventEmitter<{}>;
    subSidebarIsOpen: boolean;
    callingOnClick: EventEmitter<{}>;
    reclamationOnClick: EventEmitter<{}>;
    languageOnClick: EventEmitter<{}>;
    settingsOnClick: EventEmitter<{}>;
    onOpenSidebar: EventEmitter<{}>;
    openMainMenuIndex: number;
    _onThemeChange(theme: any): void;
    subMenuData: IMenus;
    openSubSidebar(menus: IMenus | undefined, idx: number): void;
    closeSubSidebar(): void;
    toggleMainMenu(idx: number): void;
}
