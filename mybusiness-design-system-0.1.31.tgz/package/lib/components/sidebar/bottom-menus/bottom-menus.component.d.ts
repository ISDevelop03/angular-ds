import { ElementRef, EventEmitter } from '@angular/core';
import { ISelectItem } from '../../profile-dropdown/types';
import { Cap, ILanguage } from '../types';
/**
 * @ignore
 */
export declare class DsBottomMenusComponent {
    private host;
    fontSize: string;
    showCaps: boolean;
    sizes: Cap[];
    defaultCap: Cap;
    currentCap: Cap;
    profileMenus: ISelectItem[];
    lastLoginDate: string;
    language: ILanguage;
    disableBottomMenus: boolean;
    callingOnClick: EventEmitter<{}>;
    reclamationOnClick: EventEmitter<{}>;
    languageOnClick: EventEmitter<{}>;
    settingsOnClick: EventEmitter<{}>;
    onThemeChange: EventEmitter<Cap>;
    constructor(host: ElementRef<HTMLElement>);
    ngOnInit(): void;
    capsClick(event: MouseEvent): void;
    onSizeChange(size: Cap): void;
    _onThemeChange(theme: any): void;
    onClickOutside(target: HTMLElement): void;
}
