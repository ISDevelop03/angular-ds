import { OnInit } from '@angular/core';
import { IMenuListItem } from '../types';
import { Router } from '@angular/router';
/**
 * @ignore
 */
export declare class DsMenuListComponent implements OnInit {
    private router;
    data: IMenuListItem[];
    currentURL: string;
    constructor(router: Router);
    private openMap;
    toggle(item: IMenuListItem): void;
    isOpen(item: IMenuListItem): boolean;
    hasChildren(item: IMenuListItem): boolean;
    ngOnInit(): void;
}
