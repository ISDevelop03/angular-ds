export declare const levels: {
    1: {
        title: string;
        icon: string;
    };
    2: {
        title: string;
        icon: string;
    };
    3: {
        title: string;
        icon: string;
    };
};
