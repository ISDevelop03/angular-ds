import { EventEmitter } from '@angular/core';
/**
 * @ignore
 */
export declare class DsMenuItemComponent {
    subSidebarIsOpen: boolean;
    subMenuData: any;
    title: string;
    icon?: string;
    color?: string;
    menus?: any;
    isFirst: boolean;
    disableMainMenus: boolean;
    href: string;
    onClick: EventEmitter<void>;
    readonly isActive: boolean;
    readonly wrapperClass: string;
    handleClick(): void;
}
