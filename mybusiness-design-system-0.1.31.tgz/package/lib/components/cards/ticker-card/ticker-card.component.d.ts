/**
 * Ticker-cardComponent
 *
 * Live demo:
 * <example-url>/demo/ds-ticker-card.component.html</example-url>
 */
export declare class TickerCardComponent {
    title: string;
    image: string;
    price: number;
    className?: string;
}
