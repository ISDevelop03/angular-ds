import { EventEmitter } from '@angular/core';
/**
 * Filial-cardComponent
 *
 * Live demo:
 * <example-url>/demo/ds-filial-card.component.html</example-url>
 */
export declare class FilialCardComponent {
    icon: string;
    id: number;
    sector: string;
    name: string;
    className?: string;
    useImageBorder: boolean;
    setSelected: EventEmitter<any>;
    data?: any;
    onClick(event: Event): void;
    getFirstTwoLetters: (title: string) => string;
}
