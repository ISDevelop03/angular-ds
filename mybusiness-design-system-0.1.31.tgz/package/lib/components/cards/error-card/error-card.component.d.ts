interface IErrorCard {
    label: string;
    value?: string;
    className?: string;
}
/**
 * ErrorCardComponent
 *
 * Live demo:
 * <example-url>/demo/ds-error-card.component.html</example-url>
 */
export declare class ErrorCardComponent {
    items: IErrorCard[];
    className?: string;
}
export {};
