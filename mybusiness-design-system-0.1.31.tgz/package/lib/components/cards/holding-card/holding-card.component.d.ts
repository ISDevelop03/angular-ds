/**
 * Holding-cardComponent
 *
 * Live demo:
 * <example-url>/demo/ds-holding-card.component.html</example-url>
 */
export declare class DsHoldingCardComponent {
    title: string;
    href: string;
    className: string;
}
