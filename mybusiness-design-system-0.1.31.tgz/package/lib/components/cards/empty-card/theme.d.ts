export declare const Theme: {
    textTitle: string;
    textDescription: string;
};
