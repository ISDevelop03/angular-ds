import { EventEmitter } from '@angular/core';
/**
 * Empty-cardComponent
 *
 * Live demo:
 * <example-url>/demo/ds-empty-card.component.html</example-url>
 */
export declare class EmptyCardComponent {
    title?: string;
    description: string;
    buttonLabel?: string;
    image: string;
    isLoading: boolean;
    data?: any;
    onClick: EventEmitter<any>;
    theme: {
        textTitle: string;
        textDescription: string;
    };
    handleClick(event: Event): void;
}
