import { EventEmitter } from '@angular/core';
/**
 * Payment-cardComponent
 *
 * Live demo:
 * <example-url>/demo/ds-payment-card.component.html</example-url>
 */
export declare class PaymentCardComponent {
    title?: string;
    image?: string;
    price?: number;
    currency?: string;
    deleteText?: string;
    isSelected?: boolean;
    className?: string;
    data?: any;
    onDelete: EventEmitter<any>;
    onSelect: EventEmitter<any>;
    readonly formattedPrice: string;
    onSelectChange(event: any): void;
    handleDelete(event: Event): void;
}
