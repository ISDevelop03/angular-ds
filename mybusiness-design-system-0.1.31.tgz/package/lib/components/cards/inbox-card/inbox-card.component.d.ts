import { EventEmitter } from '@angular/core';
/**
 * Inbox-cardComponent
 *
 * Live demo:
 * <example-url>/demo/ds-inbox-card.component.html</example-url>
 */
export declare class InboxCardComponent {
    id?: string;
    title?: string;
    content?: string;
    date?: string;
    isRead: boolean;
    link?: string;
    data?: any;
    onClick: EventEmitter<any>;
    handleClick(event: Event): void;
}
