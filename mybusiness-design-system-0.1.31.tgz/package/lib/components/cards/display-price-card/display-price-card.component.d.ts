interface DisplayPriceCardItem {
    label: string;
    value: string;
    showLine?: boolean;
}
interface ButtonItem {
    text: string;
    className: string;
    onClick: (event: Event) => void;
    variant: string;
    size: string;
    type: 'submit' | 'button' | 'reset';
    isLoading: boolean;
    icon: string;
    iconRight: string;
    iconLeft: string;
}
/**
 * DisplayPriceCardComponent
 *
 * Live demo:
 * <example-url>/demo/ds-display-price-card.component.html</example-url>
 */
export declare class DisplayPriceCardComponent {
    text: string;
    price: string;
    icon: string;
    items: DisplayPriceCardItem[];
    buttons: ButtonItem[];
    className?: string;
    data?: any;
}
export {};
