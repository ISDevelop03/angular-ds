import { ChangeDetectorRef, ElementRef, EventEmitter } from '@angular/core';
import { ICallToActionIcon } from '../../call-to-action-icons/types';
export interface InvoiceActions {
    label: string;
    icon: string;
    href: string;
    onClick: (data: any) => void;
}
/**
 * Invoice-cardComponent
 *
 * Live demo:
 * <example-url>/demo/ds-invoice-card.component.html</example-url>
 */
export declare class InvoiceCardComponent {
    private elementRef;
    private cdr;
    items?: InvoiceActions[];
    actions?: ICallToActionIcon[];
    id?: any;
    href?: string;
    title: string;
    image: string;
    className?: string;
    data?: any;
    onClick: EventEmitter<any>;
    isDropdownOpen: boolean;
    dropdownOpenUp: boolean;
    searchInput: string;
    getFiltredValues(): InvoiceActions[];
    dropdownTrigger: ElementRef<HTMLElement>;
    dropdownMenu: ElementRef<HTMLElement>;
    constructor(elementRef: ElementRef<HTMLElement>, cdr: ChangeDetectorRef);
    onDocumentClick(event: MouseEvent): void;
    toggleDropdown(event: Event): void;
    private updateDropdownPosition;
    closeDropdown(): void;
    onDropdownItemClick(event: Event, item: InvoiceActions): void;
    onClickHandler(event: Event): void;
    ngOnInit(): void;
}
