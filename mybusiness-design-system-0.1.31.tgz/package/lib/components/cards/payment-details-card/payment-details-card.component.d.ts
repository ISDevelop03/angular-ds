import { EventEmitter, TemplateRef } from '@angular/core';
/**
 * Payment-details-cardComponent
 *
 * Live demo:
 * <example-url>/demo/ds-payment-details-card.component.html</example-url>
 */
export declare class PaymentDetailsCardComponent {
    title: string;
    titleHeader: string;
    date?: string;
    price?: number;
    currency?: string;
    isSelected?: boolean;
    useCheckbox?: boolean;
    className?: string;
    disabled?: boolean;
    status?: TemplateRef<any>;
    statusContext?: string;
    data?: any;
    onSelect: EventEmitter<any>;
    readonly formattedPrice: string;
    onSelectChange(event: any): void;
}
