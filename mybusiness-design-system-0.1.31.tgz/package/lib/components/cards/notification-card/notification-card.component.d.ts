import { EventEmitter } from '@angular/core';
/**
 * Notification-cardComponent
 *
 * Live demo:
 * <example-url>/demo/ds-notification-card.component.html</example-url>
 */
export declare class NotificationCardComponent {
    id?: string;
    title?: string;
    content?: string;
    isRead: boolean;
    link?: string;
    time?: string;
    data?: any;
    onClick: EventEmitter<any>;
    handleClick(event: Event): void;
}
