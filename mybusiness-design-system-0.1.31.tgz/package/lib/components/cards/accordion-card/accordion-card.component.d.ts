import { TemplateRef } from '@angular/core';
export interface AccordionCard {
    label: string;
    value: any | TemplateRef<any>;
}
/**
 * AccordionCardComponent
 *
 * Live demo:
 * <example-url>/demo/ds-accordion-card.component.html</example-url>
 */
export declare class AccordionCardComponent {
    items: AccordionCard[];
    className?: string;
    isTemplate(ref: any): ref is TemplateRef<any>;
}
