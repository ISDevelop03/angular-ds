import { EventEmitter } from '@angular/core';
export declare type TTransfer = {
    motif: string;
    amount: number;
};
export declare type TTransferAmount = {
    amount: number;
    currency: string;
};
/**
 * VirementCardComponent
 *
 * Live demo:
 * <example-url>/demo/ds-virement-card.component.html</example-url>
 */
export declare class VirementCardComponent {
    className?: string;
    beneficiaryName?: string;
    beneficiaryAccountNumber?: string;
    motif?: string;
    amount?: TTransferAmount;
    onSave: EventEmitter<TTransfer>;
    onDelete: EventEmitter<void>;
    mode: 'edit' | 'view';
    motifValue: string;
    amountValue: number | string | null;
    toggleEditMode(): void;
    toggleViewMode(): void;
    handleSave(): void;
    handleDelete(): void;
}
