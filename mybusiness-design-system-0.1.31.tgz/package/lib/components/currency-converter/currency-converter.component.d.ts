import { EventEmitter } from '@angular/core';
interface CurrencyProps {
    value: string;
    label: string;
    symbol: string;
    color: string;
    image: string;
}
/**
 * Currency-converterComponent
 *
 * Live demo:
 * <example-url>/demo/ds-currency-converter.component.html</example-url>
 */
export declare class CurrencyConverterComponent {
    value: number;
    currency: string;
    currencies: CurrencyProps[];
    /** emits when the number input changes */
    valueChange: EventEmitter<number>;
    /** emits when the currency select changes */
    currencyChange: EventEmitter<string>;
    onInput(e: Event): void;
    onCurrencyChange(newCur: any): void;
}
export {};
