import { AfterContentInit, QueryList } from '@angular/core';
import { StepComponent } from './step.component';
import { StepsTheme } from './theme';
export interface StepButton {
    variant: string;
    content: string;
    disableHandleStep?: boolean;
    onClick: (data: any) => void;
    icon?: string;
    iconRight?: string;
    iconLeft?: string;
    type?: 'button' | 'submit' | 'reset';
    className?: string;
    size?: string;
    disabled?: boolean;
    outline?: boolean;
    pill?: boolean;
}
/**
 * StepsComponent
 *
 * Live demo:
 * <example-url>/demo/ds-steps.component.html</example-url>
 */
export declare class StepsComponent implements AfterContentInit {
    /** Index of the currently visible step */
    currentStepIndex: number;
    /** Collect all projected <ds-step> children */
    steps: QueryList<StepComponent>;
    /** Theme variant key (e.g. 'default' | 'primary' | 'success') */
    variant: string;
    title: string;
    showNavigation: boolean;
    showHeader: boolean;
    /** Resolved theme for the selected variant */
    theme: StepsTheme;
    ngAfterContentInit(): void;
    /** Move to next step if allowed */
    goNext: (event?: Event, button?: StepButton) => void;
    /** Move to previous step if allowed */
    goPrev: (event?: Event, button?: StepButton) => void;
}
