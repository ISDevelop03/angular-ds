export interface StepsTheme {
    wrapper: string;
    /** Wrapper for the header row */
    headerWrapper: string;
    /** Individual step in the header */
    step: string;
    /** Modifier applied to the active step */
    activeStep: string;
    /** Wrapper for the content pane */
    contentWrapper: string;
    /** Wrapper for the navigation buttons */
    navigationWrapper: string;
    /** Common button styles */
    button: string;
}
export declare const STEPS_THEME: {
    [variant: string]: StepsTheme;
};
