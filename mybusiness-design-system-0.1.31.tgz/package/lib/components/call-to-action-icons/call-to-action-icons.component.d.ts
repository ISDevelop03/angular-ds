import { ICallToActionIcon } from './types';
import { callToActionIconsTheme } from './theme';
/**
 * Call-to-action-iconsComponent
 *
 * Live demo:
 * <example-url>/demo/ds-call-to-action-icons.component.html</example-url>
 */
export declare class CallToActionIconsComponent {
    variant: keyof typeof callToActionIconsTheme;
    className?: string;
    actions: ICallToActionIcon[];
    theme: {
        default: {
            wrapper: string;
            separator: string;
            button: string;
            icon: string;
            iconSize: string;
        };
        separated: {
            wrapper: string;
            separator: string;
            button: string;
            icon: string;
            iconSize: string;
        };
        borderless: {
            wrapper: string;
            separator: string;
            button: string;
            icon: string;
            iconSize: string;
        };
    };
    handleClick(event: Event, action: ICallToActionIcon): void;
}
