export declare const callToActionIconsTheme: {
    default: {
        wrapper: string;
        separator: string;
        button: string;
        icon: string;
        iconSize: string;
    };
    separated: {
        wrapper: string;
        separator: string;
        button: string;
        icon: string;
        iconSize: string;
    };
    borderless: {
        wrapper: string;
        separator: string;
        button: string;
        icon: string;
        iconSize: string;
    };
};
