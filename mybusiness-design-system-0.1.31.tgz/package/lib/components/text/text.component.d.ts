import { ElementRef, Renderer2, OnChanges, SimpleChanges, AfterViewInit } from '@angular/core';
import { typography } from './theme';
/**
 * TextComponent
 *
 * Live demo:
 * <example-url>/demo/ds-text.component.html</example-url>
 */
export declare class DsTextComponent implements OnChanges, AfterViewInit {
    private el;
    private renderer;
    variant: keyof typeof typography;
    tag: string;
    className: string;
    content: string;
    private tagElement;
    private currentTag;
    constructor(el: ElementRef, renderer: Renderer2);
    ngAfterViewInit(): void;
    ngOnChanges(changes: SimpleChanges): void;
    private createElement;
    private replaceElement;
    private updateElement;
}
