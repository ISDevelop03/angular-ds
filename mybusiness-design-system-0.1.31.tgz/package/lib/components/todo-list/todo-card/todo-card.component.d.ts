/**
 * TodoCardComponent
 *
 * Live demo:
 * <example-url>/demo/ds-todo-card.component.html</example-url>
 */
export declare class TodoCardComponent {
    title: string;
    description?: string;
    date: string;
    badgeText: string;
    badgeVariant: string;
    icon?: string;
    isRead: boolean;
    className?: string;
}
