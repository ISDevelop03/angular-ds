/**
 * TodoTabComponent
 *
 * Live demo:
 * <example-url>/demo/ds-todo-tab.component.html</example-url>
 */
export declare class TodoTabComponent {
    title: string;
    count: number;
    icon?: string;
    isOpen: boolean;
    onClick: () => void;
    className?: string;
}
