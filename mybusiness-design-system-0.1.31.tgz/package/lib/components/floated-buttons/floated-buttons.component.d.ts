interface FloatedButton {
    content: string;
    type?: 'button' | 'submit' | 'reset';
    icon?: string;
    iconRight?: boolean;
    className?: string;
    disabled?: boolean;
    isLoading?: boolean;
    isDelete?: boolean;
    onClick?: (event: any) => void;
}
/**
 * FloatedButtonsComponent
 *
 * Live demo:
 * <example-url>/demo/ds-floated-buttons.component.html</example-url>
 */
export declare class FloatedButtonsComponent {
    items: FloatedButton[];
    className?: string;
    isAllItemsDisabled(): boolean;
}
export {};
