import { EventEmitter } from '@angular/core';
import { CardVariant } from '../card-visual/card-visual.component';
/**
 * BankCardComponent — carte sélectionnable (commande de cartes)
 *
 * Live demo:
 * <example-url>/demo/ds-bank-card.component.html</example-url>
 */
export declare class BankCardComponent {
    variant: CardVariant;
    label: string;
    description: string;
    /** When true, shows the active (red) border and radio dot. */
    selected: boolean;
    /** Optional product image. When omitted, a CSS fallback by variant is shown. */
    imageSrc: string | null;
    alt: string | null;
    className: string;
    onSelect: EventEmitter<CardVariant>;
    readonly resolvedAlt: string;
    readonly fallback: {
        gradient: string;
        accent: string;
        label: string;
        sub: string;
    };
    select(): void;
}
