import { OnChanges, OnInit, SimpleChanges } from '@angular/core';
/** One label / value pair. */
export declare type ValeursField = {
    label: string;
    value: string;
};
/**
 * A column in a row — one or more stacked fields.
 * Single field: `[{ label, value }]`
 * Multi field:  `[{ label, value }, { label, value }, ...]`
 */
export declare type ValeursColumn = ValeursField[];
/** @deprecated Use ValeursField — kept as alias for older call sites. */
export declare type ValeursColumnItem = ValeursField;
/**
 * ValeursTableComponent — card rows with columns of stacked label/value pairs
 * and vertical dividers (Mes valeurs Lovable UI).
 *
 * Live demo:
 * <example-url>/demo/ds-valeurs-table.component.html</example-url>
 */
export declare class ValeursTableComponent implements OnInit, OnChanges {
    /**
     * Rows of columns. Each column is an array of fields (supports 1+ items
     * stacked vertically in the same column).
     */
    rows: ValeursColumn[][];
    /** When true, first row gets the selected (red) outline. */
    highlightFirst: boolean;
    className: string;
    minColWidth: number;
    displayRows: ValeursColumn[][];
    trackerStyle: {
        [key: string]: string;
    };
    gridStyle: {
        [key: string]: string;
    };
    ngOnInit(): void;
    ngOnChanges(changes: SimpleChanges): void;
    readonly hasRows: boolean;
    /**
     * Accepts either:
     * - grouped columns: ValeursField[][] per row (preferred)
     * - flat fields:     ValeursField[] per row (each field becomes a 1-item column)
     */
    private normalizeRows;
    private recomputeLayout;
    isHighlighted(index: number): boolean;
}
