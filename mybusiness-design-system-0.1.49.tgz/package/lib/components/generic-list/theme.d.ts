export declare const theme: {
    white: {
        container: string;
        label: string;
    };
    gray: {
        container: string;
        label: string;
    };
};
