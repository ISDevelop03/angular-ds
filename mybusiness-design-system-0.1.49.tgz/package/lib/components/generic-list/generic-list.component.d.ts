import { theme } from './theme';
export declare type GenericListTextItem = {
    label: string;
    type: 'text';
    value: string;
};
export declare type GenericListListItem = {
    label: string;
    type: 'list-badges';
    value: string[];
};
export declare type GenericListAccountItem = {
    label: string;
    type: 'account';
    value: {
        accountName: string;
        accountNumber: string;
    };
};
export declare type GenericListItem = GenericListTextItem | GenericListListItem | GenericListAccountItem;
export declare type GenericListDisplay = 'inline' | 'stacked';
export declare type GenericListVariant = keyof typeof theme;
export declare type GenericListSection = {
    title: string;
    display?: GenericListDisplay;
    items: GenericListItem[];
};
/**
 * GenericListComponent
 *
 * Live demo:
 * <example-url>/demo/ds-generic-list.component.html</example-url>
 */
export declare class GenericListComponent {
    className?: string;
    variant: GenericListVariant;
    sections: GenericListSection[];
    theme: {
        white: {
            container: string;
            label: string;
        };
        gray: {
            container: string;
            label: string;
        };
    };
    getDisplay(section: GenericListSection): GenericListDisplay;
}
