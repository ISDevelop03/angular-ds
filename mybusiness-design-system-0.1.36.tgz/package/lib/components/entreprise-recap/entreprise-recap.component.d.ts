declare type TAccount = {
    account_type: string;
    account_number: string;
};
export declare type TEntrepriseRecapItems = {
    label: string;
    value: string | number | TAccount;
};
/**
 * EntrepriseRecapComponent
 *
 * Live demo:
 * <example-url>/demo/ds-entreprise-recap.component.html</example-url>
 */
export declare class EntrepriseRecapComponent {
    className?: string;
    items: TEntrepriseRecapItems[];
    isScalarValue(value: string | number | TAccount): value is string | number;
    asAccount(value: string | number | TAccount): TAccount | null;
}
export {};
