export declare type TAction = {
    actionDate: string;
    actionLabel: string;
    actionAgent: TAgent;
};
export declare type TAgent = {
    name: string;
    role: string;
};
/**
 * SchemaSignatureComponent
 *
 * Live demo:
 * <example-url>/demo/ds-schema-signature.component.html</example-url>
 */
export declare class SchemaSignatureComponent {
    className?: string;
    title?: string;
    initiation?: TAction;
    actions?: TAction[];
}
