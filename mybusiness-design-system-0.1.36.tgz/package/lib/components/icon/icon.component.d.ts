/**
 * IconComponent
 *
 * Live demo:
 * <example-url>/demo/ds-icon.component.html</example-url>
 */
export declare class IconComponent {
    id: string;
    size: string;
    class: string;
    style: string;
    disabled: boolean;
}
