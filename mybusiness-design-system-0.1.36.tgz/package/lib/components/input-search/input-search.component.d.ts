import { ElementRef } from '@angular/core';
/**
 * InputSearchComponent
 *
 * Live demo:
 * <example-url>/demo/ds-input-search.component.html</example-url>
 */
export declare class InputSearchComponent {
    private elementRef;
    className?: string;
    placeholder: string;
    maxWidth: string;
    value: string;
    isExpanded: boolean;
    constructor(elementRef: ElementRef<HTMLElement>);
    onDocumentClick(event: MouseEvent): void;
    openSearch(): void;
    clearSearch(): void;
}
