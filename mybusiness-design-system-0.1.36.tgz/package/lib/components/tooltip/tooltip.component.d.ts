import { ElementRef, Renderer2, OnInit, OnDestroy, AfterViewChecked, ChangeDetectorRef, TemplateRef, OnChanges, SimpleChanges } from '@angular/core';
import { AnimationEvent } from '@angular/animations';
/**
 * TooltipComponent
 *
 * Live demo:
 * <example-url>/demo/ds-tooltip.component.html</example-url>
 */
export declare class TooltipComponent implements OnInit, OnDestroy, AfterViewChecked, OnChanges {
    private el;
    private renderer;
    private cdr;
    content: TemplateRef<any> | string;
    position: 'top' | 'topRight' | 'topLeft' | 'bottom' | 'bottomRight' | 'bottomLeft' | 'left' | 'right';
    className?: string;
    disabled: boolean;
    delay: number;
    theme: any;
    style: Record<string, string>;
    readonly wordLimit = 30;
    isExpanded: boolean;
    isVisible: boolean;
    shouldRenderTooltip: boolean;
    defaultTheme: {
        base: string;
        positions: {
            top: string;
            topRight: string;
            topLeft: string;
            bottom: string;
            bottomRight: string;
            bottomLeft: string;
            left: string;
            right: string;
        };
        arrow: {
            base: string;
            positions: {
                top: string;
                topRight: string;
                topLeft: string;
                bottom: string;
                bottomRight: string;
                bottomLeft: string;
                left: string;
                right: string;
            };
        };
    };
    private timeoutId;
    private mouseLeaveTimeoutId;
    constructor(el: ElementRef, renderer: Renderer2, cdr: ChangeDetectorRef);
    ngOnInit(): void;
    ngAfterViewChecked(): void;
    ngOnChanges(changes: SimpleChanges): void;
    private applyStylesToTooltip;
    ngOnDestroy(): void;
    readonly appliedTheme: any;
    readonly computedClass: string;
    readonly animationState: string;
    readonly arrowClass: string;
    readonly isStringContent: boolean;
    readonly contentWordCount: number;
    readonly isTruncated: boolean;
    readonly displayedContent: string;
    toggleExpanded(event: MouseEvent): void;
    onMouseEnter(event: MouseEvent): void;
    onMouseLeave(event: MouseEvent): void;
    onFocusIn(event: FocusEvent): void;
    onFocusOut(event: FocusEvent): void;
    private showTooltip;
    private hideTooltip;
    onTooltipAnimationDone(event: AnimationEvent): void;
    private clearTimeout;
    onTooltipMouseEnter(event: MouseEvent): void;
    private clearMouseLeaveTimeout;
}
