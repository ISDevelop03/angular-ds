import { EventEmitter, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { IMenus, IMainMenu, ILanguage, Cap, IDisableBottomMenus } from '../types';
import { ISelectItem } from '../../profile-dropdown/types';
/**
 * SidebarComponent
 *
 * Live demo:
 * <example-url>/demo/ds-sidebar.component.html</example-url>
 */
export declare class DsSidebarComponent implements OnInit {
    private router;
    className: string;
    profileMenus: ISelectItem[];
    mainMenus: IMainMenu[];
    disableMainMenus: boolean;
    disableBottomMenus: IDisableBottomMenus;
    sizes: Cap[];
    defaultCap: Cap;
    logo: string;
    miniLogo: string;
    language: ILanguage;
    onThemeChange: EventEmitter<{}>;
    subSidebarIsOpen: boolean;
    callingOnClick: EventEmitter<{}>;
    reclamationOnClick: EventEmitter<{}>;
    languageOnClick: EventEmitter<{}>;
    settingsOnClick: EventEmitter<{}>;
    onOpenSidebar: EventEmitter<{}>;
    openMainMenuIndex: number;
    isActif: string;
    constructor(router: Router);
    ngOnInit(): void;
    setActif(url: string): void;
    _onThemeChange(theme: any): void;
    subMenuData: IMenus;
    openSubSidebar(menus: IMenus | undefined, idx: number): void;
    closeSubSidebar(): void;
    toggleMainMenu(idx: number): void;
}
