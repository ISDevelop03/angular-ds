import { EventEmitter } from '@angular/core';
import { IMenuListItem } from '../types';
/**
 * @ignore
 */
export declare class DsMenuListComponent {
    data: IMenuListItem[];
    isActif: string;
    onLinkClick: EventEmitter<string>;
    private openMap;
    toggle(item: IMenuListItem): void;
    isOpen(item: IMenuListItem): boolean;
    hasChildren(item: IMenuListItem): boolean;
    handleLinkClick(url: string): void;
}
