import { OnChanges, OnInit, SimpleChanges } from '@angular/core';
export declare type CardVariant = 'deposit' | 'business' | 'escale';
interface VariantStyle {
    alt: string;
    gradient: string;
    accent: string;
    label: string;
    sub: string;
}
/**
 * CardVisualComponent — vignette carte bancaire
 *
 * Live demo:
 * <example-url>/demo/ds-card-visual.component.html</example-url>
 */
export declare class CardVisualComponent implements OnInit, OnChanges {
    variant: CardVariant;
    /** When set, renders the image instead of the CSS fallback. */
    imageSrc: string | null;
    alt: string | null;
    className: string;
    width: number;
    height: number;
    style: VariantStyle;
    resolvedAlt: string;
    ngOnInit(): void;
    ngOnChanges(_changes: SimpleChanges): void;
    private resolve;
}
export {};
