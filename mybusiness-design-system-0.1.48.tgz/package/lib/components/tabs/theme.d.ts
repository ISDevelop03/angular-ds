export declare const theme: {
    default: {
        wrapper: string;
        list: {
            base: string;
            container: string;
            tab: {
                base: string;
                selected: string;
                unselected: string;
            };
        };
        panels: {
            container: string;
            panel: {
                base: string;
            };
        };
    };
    noBackground: {
        wrapper: string;
        list: {
            base: string;
            container: string;
            tab: {
                base: string;
                button: {
                    base: string;
                    selected: string;
                    unselected: string;
                };
                selected: string;
                unselected: string;
            };
        };
        panels: {
            container: string;
            panel: {
                base: string;
            };
        };
    };
    vertical: {
        wrapper: string;
        list: {
            base: string;
            container: string;
            tab: {
                base: string;
                button: {
                    base: string;
                    selected: string;
                    unselected: string;
                };
                selected: string;
                unselected: string;
            };
        };
        panels: {
            container: string;
            panel: {
                base: string;
            };
        };
    };
    withBorder: {
        wrapper: string;
        list: {
            base: string;
            container: string;
            tab: {
                base: string;
                button: {
                    base: string;
                    selected: string;
                    unselected: string;
                };
                selected: string;
                unselected: string;
            };
        };
        panels: {
            container: string;
            panel: {
                base: string;
            };
        };
    };
};
