import { EventEmitter, TemplateRef } from '@angular/core';
import { theme } from './theme';
export interface ITab {
    title: string;
    panel: string | TemplateRef<any> | ITab[];
    href?: string;
    link?: string;
    disabled?: boolean;
}
/**
 * TabsComponent
 *
 * Live demo:
 * <example-url>/demo/ds-tabs.component.html</example-url>
 */
export declare class DsTabsComponent {
    items: ITab[];
    className: string;
    containerClassName: string;
    variant: keyof typeof theme;
    rightContent?: TemplateRef<any>;
    showTabsSeparator: boolean;
    onSelect: EventEmitter<any>;
    selectedIndex: number;
    selectedSubIndex: number | null;
    theme: {
        default: {
            wrapper: string;
            list: {
                base: string;
                container: string;
                tab: {
                    base: string;
                    selected: string;
                    unselected: string;
                };
            };
            panels: {
                container: string;
                panel: {
                    base: string;
                };
            };
        };
        noBackground: {
            wrapper: string;
            list: {
                base: string;
                container: string;
                tab: {
                    base: string;
                    button: {
                        base: string;
                        selected: string;
                        unselected: string;
                    };
                    selected: string;
                    unselected: string;
                };
            };
            panels: {
                container: string;
                panel: {
                    base: string;
                };
            };
        };
        vertical: {
            wrapper: string;
            list: {
                base: string;
                container: string;
                tab: {
                    base: string;
                    button: {
                        base: string;
                        selected: string;
                        unselected: string;
                    };
                    selected: string;
                    unselected: string;
                };
            };
            panels: {
                container: string;
                panel: {
                    base: string;
                };
            };
        };
        withBorder: {
            wrapper: string;
            list: {
                base: string;
                container: string;
                tab: {
                    base: string;
                    button: {
                        base: string;
                        selected: string;
                        unselected: string;
                    };
                    selected: string;
                    unselected: string;
                };
            };
            panels: {
                container: string;
                panel: {
                    base: string;
                };
            };
        };
    };
    openAccordions: {
        [key: number]: boolean;
    };
    selectTab(event: Event, tab: ITab, index: number): void;
    selectSubTab(event: Event, parentTab: ITab, parentIndex: number, subTab: ITab, subIndex: number): void;
    toggleAccordion(index: number): void;
    isAccordionOpen(index: number): boolean;
    isSelected(index: number): boolean;
    isParentSelected(index: number): boolean;
    isSubSelected(parentIndex: number, subIndex: number): boolean;
    getActivePanel(tab: ITab, index: number): string | TemplateRef<any> | null;
    getTabButtonClass(selected: boolean): string;
    getAccordionIconId(index: number): string;
    isTemplate(ref: any): ref is TemplateRef<any>;
    isArray(value: any): value is any[];
}
