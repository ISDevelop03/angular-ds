import { EventEmitter } from '@angular/core';
import { CardVariant } from '../card-visual/card-visual.component';
import { ITab } from '../tabs/tabs.component';
export interface CardItem {
    id: string;
    name: string;
    holder: string;
    numTail: string;
    expiry: string;
    variant: CardVariant;
    status?: 'Actif';
    plafondAchat: string;
    plafondRetrait: string;
    solde: string;
    /** Optional override for card thumbnail */
    imageSrc?: string;
}
/**
 * CreditCardComponent — ligne carte dépliable avec onglets
 *
 * Live demo:
 * <example-url>/demo/ds-credit-card.component.html</example-url>
 */
export declare class CreditCardComponent {
    card: CardItem;
    expanded: boolean;
    /** Same shape as ds-tabs `items` — panels are managed by ds-tabs */
    items: ITab[];
    selectedIndex: number;
    className: string;
    onToggle: EventEmitter<CardItem>;
    onTabChange: EventEmitter<{
        index: number;
        tab: ITab;
    }>;
    toggle(): void;
    onTabSelect(payload: {
        index: number;
        tab: ITab;
    }): void;
    showStatusBadge(): boolean;
}
