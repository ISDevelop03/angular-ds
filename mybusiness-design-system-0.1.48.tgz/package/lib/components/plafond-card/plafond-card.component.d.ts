import { EventEmitter, OnChanges, OnInit, SimpleChanges } from '@angular/core';
export declare type GaugeColor = 'green' | 'orange' | 'red' | 'olive';
/**
 * PlafondCardComponent — carte plafond (titre, jauge, plafonds contractuel/commercial)
 *
 * Live demo:
 * <example-url>/demo/ds-plafond-card.component.html</example-url>
 */
export declare class PlafondCardComponent implements OnInit, OnChanges {
    title: string;
    editable: boolean;
    color: GaugeColor;
    consumed: string;
    max: string;
    /** Fill ratio 0–1. When omitted, derived from `color` for backward compat. */
    percent: number | null;
    label: string;
    minLabel: string;
    contractuel: string;
    commercial: string;
    note: string;
    className: string;
    onEdit: EventEmitter<void>;
    bgPath: string;
    fgPath: string;
    stroke: string;
    ngOnInit(): void;
    ngOnChanges(_changes: SimpleChanges): void;
    readonly upperTitle: string;
    requestEdit(): void;
    private rebuild;
}
