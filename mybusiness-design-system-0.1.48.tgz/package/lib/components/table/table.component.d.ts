import { EventEmitter, TemplateRef, OnChanges, SimpleChanges, ElementRef, OnDestroy } from '@angular/core';
import { TableVariant } from './theme';
export interface ColumnDef {
    header: string;
    expandable?: boolean;
    truncate?: boolean;
    styles?: {
        [key: string]: string;
    };
    style?: {
        [key: string]: string;
    };
    accessor: string;
    sortable?: boolean;
    cellTemplate?: TemplateRef<any>;
}
/**
 * TableComponent
 *
 * Live demo:
 * <example-url>/demo/ds-table.component.html</example-url>
 */
export declare class TableComponent implements OnChanges, OnDestroy {
    data: any[];
    columns: ColumnDef[];
    variant: TableVariant;
    remoteSort: boolean;
    selectionEnabled: boolean;
    selectionMode: 'single' | 'multi';
    expandableRows: boolean;
    expandedRowTemplate?: TemplateRef<{
        $implicit: any;
        row: any;
    }>;
    className?: string;
    sortChange: EventEmitter<{
        accessor: string;
        direction?: "asc" | "desc";
    }>;
    isOverflowing: boolean;
    isOnLeft: boolean;
    isOnRight: boolean;
    selectionChange: EventEmitter<any>;
    tableContainer: ElementRef<HTMLDivElement>;
    tableElement: ElementRef<HTMLTableElement>;
    selectedRows: Set<any>;
    selectedRowId: string | null;
    expandedRows: Set<any>;
    displayData: any[];
    private originalData;
    sortColumn: string | null;
    sortDirection: 'asc' | 'desc';
    theme: Record<TableVariant, import("./theme").TableTheme>;
    ngOnInit(): void;
    ngOnChanges(changes: SimpleChanges): void;
    onSelect(row: any): void;
    private resizeListener?;
    private scrollListener?;
    ngAfterViewInit(): void;
    ngOnDestroy(): void;
    toggleTruncateData(col: ColumnDef): void;
    onSort(col: ColumnDef): void;
    readonly isAllSelected: boolean;
    readonly isSomeSelected: boolean;
    readonly isIndeterminate: boolean;
    isAllUnselectable(): boolean;
    toggleSelectAll(checked: boolean): void;
    toggleRow(row: any, checked: boolean): void;
    isSelected(row: any): boolean;
    private emitSelection;
    headerCheckboxChange: () => void;
    getRowCheckboxChange(row: any): () => void;
    toggleRowExpand(row: any): void;
    isRowExpanded(row: any): boolean;
    readonly expandableColspan: number;
    getAllLines(text: any, col: ColumnDef): string[];
    checkTableOverflow(): void;
}
