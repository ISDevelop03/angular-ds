import { ApplicationRef, ChangeDetectorRef, ComponentFactoryResolver, ElementRef, EventEmitter, Injector, OnChanges, SimpleChanges, TemplateRef, ViewContainerRef } from '@angular/core';
/**
 * PriceFilterComponent
 *
 * Live demo:
 * <example-url>/demo/ds-price-filter.component.html</example-url>
 */
export declare class PriceFilterComponent implements OnChanges {
    private cd;
    private vcr;
    private cfr;
    private appRef;
    private injector;
    private document;
    className?: string;
    showOptions: boolean;
    value: number | null;
    isRange: boolean;
    onSelect: EventEmitter<number | Record<string, any>>;
    trigger: ElementRef;
    menuTpl: TemplateRef<any>;
    menu: ElementRef;
    isOpen: boolean;
    menuStyles: {
        [key: string]: string;
    };
    private portalHost;
    private menuPortal;
    selectedType: 'debit' | 'credit';
    selectedPrice: number | null;
    displayPrice: string;
    placeholder: string;
    selectedRange: {
        min: number;
        max: number;
    };
    displayPriceMin: string;
    displayPriceMax: string;
    logDisplayPrice(): void;
    constructor(cd: ChangeDetectorRef, vcr: ViewContainerRef, cfr: ComponentFactoryResolver, appRef: ApplicationRef, injector: Injector, document: any);
    ngOnChanges(changes: SimpleChanges): void;
    ngOnInit(): void;
    ngOnDestroy(): void;
    toggleMenu(): void;
    private setMenuPosition;
    closeMenu(): void;
    handleOutsideClick: (e: MouseEvent) => void;
    formatPrice(value: number | string): string;
    onPriceKeydown(event: KeyboardEvent): void;
    onPriceInput(event: Event): void;
    onPriceInputMin(event: Event): void;
    onPriceInputMax(event: Event): void;
    clearSelection(): void;
    handleSelect(): void;
    stopEvent(event: MouseEvent): void;
    private static zIndexCounter;
}
