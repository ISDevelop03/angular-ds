import { EventEmitter, ElementRef, SimpleChanges, OnChanges } from '@angular/core';
import { theme } from './theme';
export interface Solde {
    value: number;
    currency: string;
    currency_flag: string;
}
export interface SelectItem {
    unavailable?: boolean;
    icon: string;
    value: string;
    accountName: string;
    accountNumber: string;
    soldeComptable?: Solde;
    soldeTempsReel?: Solde;
}
export interface OmittedSelectItem {
    value: string;
    icon?: string;
    unavailable?: boolean;
}
/**
 * Accounts-selectComponent
 *
 * Live demo:
 * <example-url>/demo/ds-accounts-select.component.html</example-url>
 */
export declare class AccountsSelectComponent implements OnChanges {
    items: SelectItem[];
    label?: string;
    errorMessage?: string;
    placeholder: string;
    variant: keyof typeof theme;
    disabled: boolean;
    hasError: boolean;
    emptyLabel: string;
    multiple: boolean;
    isLoading: boolean;
    className?: string;
    buttonIcon?: string;
    value: string | null;
    customOptionsStyles?: {
        [key: string]: any;
    };
    autoComplete: boolean;
    showCurrencyFlag: boolean;
    required: boolean;
    /**
     * Number of options above which the list is virtualized (only the options
     * visible in the viewport are rendered). Set to `Infinity` to disable.
     */
    virtualScrollThreshold: number;
    /**
     * Fixed height (px) of an option row while virtualized. Defaults to 65px, or
     * 69px when options display balances. Increase it if your rows are taller.
     */
    itemSize?: number;
    /** Number of extra rows rendered above and below the viewport. */
    bufferSize: number;
    valueChange: EventEmitter<string | string[]>;
    private static zIndexCounter;
    autoCompleteInput?: ElementRef;
    isOpen: boolean;
    searchTerm: string;
    filteredItems: SelectItem[];
    selectedValue: SelectItem | null;
    containerPosition: {
        [key: string]: any;
    };
    containerStyles: {};
    triggerButton?: ElementRef;
    optionsContainer?: ElementRef;
    theme: {
        default: {
            element: {
                label: string;
                button: {
                    base: string;
                    neutral: string;
                    selected: string;
                    error: string;
                    iconeError: string;
                    disabled: string;
                    label: string;
                    placeholder: string;
                };
                field: {
                    activated: string;
                };
                icone: {
                    arrow: string;
                    checked: string;
                };
                accountPicto: {
                    base: string;
                    enabled: string;
                    disabled: string;
                    error: string;
                };
                options: {
                    selectedfont: string;
                    container: string;
                    element: string;
                    fontcolor: string;
                    available: string;
                    unavailable: string;
                };
                error: string;
            };
        };
    };
    visibleItems: SelectItem[];
    topPadding: number;
    bottomPadding: number;
    private startIndex;
    private endIndex;
    private scrollTop;
    private viewportHeight;
    private hasBalances;
    ngOnChanges(changes: SimpleChanges): void;
    readonly isVirtual: boolean;
    readonly rowHeight: number;
    trackByValue(index: number, item: SelectItem): string;
    onOptionsScroll(): void;
    /** Recomputes which slice of `filteredItems` should be in the DOM. */
    private updateVirtualWindow;
    private resetScroll;
    /** When opening a virtualized list, bring the selected option into view. */
    private syncVirtualViewport;
    readonly mergedStyles: {
        [key: string]: any;
    } & {
        [key: string]: any;
    };
    toggleDropdown(): void;
    shouldAppear(): boolean;
    calculatePosition(): void;
    selectOption(item: SelectItem): void;
    isSelected(item: SelectItem): boolean;
    readonly selected: SelectItem;
    onClickOutside(event: MouseEvent): void;
    onEscClose(event: KeyboardEvent): void;
    onAutoCompleteInput(event: Event): void;
    clearSearch(): void;
}
