import { EventEmitter } from '@angular/core';
/**
 * NotificationSettingsComponent
 *
 * Live demo:
 * <example-url>/demo/ds-notification-settings.component.html</example-url>
 */
export declare class NotificationSettingsComponent {
    className?: string;
    title: string;
    description: string;
    notificationsEnabled: boolean;
    notifications: string[];
    notificationsChange: EventEmitter<boolean>;
    onNotificationsChange(enabled: boolean): void;
}
