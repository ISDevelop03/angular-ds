/**
 * UnhabilitatedWidgetComponent
 *
 * Live demo:
 * <example-url>/demo/ds-unhabilitated-widget.component.html</example-url>
 */
export declare class UnhabilitatedWidgetComponent {
    className?: string;
    backgroundImage?: string;
    modalImage?: string;
    title?: string;
    description?: string;
}
