import { EventEmitter } from '@angular/core';
import { IMenus } from '../types';
/**
 * @ignore
 */
export declare class DsMenuItemComponent {
    subSidebarIsOpen: boolean;
    subMenuData: any;
    title: string;
    icon?: string;
    color?: string;
    menus?: IMenus;
    isFirst: boolean;
    disableMainMenus: boolean;
    href: string;
    isExternal: boolean;
    isActif: string;
    openInNewTab: boolean;
    onClick: EventEmitter<void>;
    onLinkClick: EventEmitter<string>;
    readonly isActive: boolean;
    private containsHref;
    readonly wrapperClass: string;
    handleClick(): void;
    handleLinkClick(): void;
}
