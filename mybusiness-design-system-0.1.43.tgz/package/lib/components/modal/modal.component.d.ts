import { AfterContentChecked, AfterViewInit, ChangeDetectorRef, ElementRef, EventEmitter, OnChanges, SimpleChanges } from '@angular/core';
/**
 * ModalComponent
 *
 * Live demo:
 * <example-url>/demo/ds-modal.component.html</example-url>
 */
export declare class ModalComponent implements AfterViewInit, AfterContentChecked, OnChanges {
    private cdr;
    isShown: boolean;
    icon?: string;
    type?: 'success' | 'warning' | 'error' | 'info';
    title?: string;
    description?: string;
    mainAction?: string;
    secondaryAction?: string;
    className?: string;
    close: EventEmitter<void>;
    mainActionOnClick: EventEmitter<void>;
    secondaryActionOnClick: EventEmitter<void>;
    contentContainer?: ElementRef<HTMLElement>;
    hasProjectedContent: boolean;
    theme: {
        overlay: string;
        base: string;
        panel: string;
    };
    constructor(cdr: ChangeDetectorRef);
    ngOnChanges(changes: SimpleChanges): void;
    ngAfterViewInit(): void;
    ngAfterContentChecked(): void;
    onEscPressed(_event: KeyboardEvent): void;
    onClose(): void;
    onBackdropClick(event: MouseEvent): void;
    onSecondaryActionOnClick(): void;
    onMainActionOnClick(): void;
    private updateProjectedContentPresence;
}
