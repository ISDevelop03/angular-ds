/**
 * FlatTooltipComponent
 *
 * Live demo:
 * <example-url>/demo/ds-flat-tooltip.component.html</example-url>
 */
export declare class FlatTooltipComponent {
    className?: string;
    title: string;
    content: string;
}
