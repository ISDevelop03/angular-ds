export declare const theme: {
    default: {
        element: {
            label: string;
            button: {
                base: string;
                neutral: string;
                selected: string;
                error: string;
                iconeError: string;
                disabled: string;
                label: string;
                placeholder: string;
            };
            field: {
                activated: string;
            };
            icone: {
                arrow: string;
                checked: string;
            };
            accountPicto: {
                base: string;
                enabled: string;
                disabled: string;
                error: string;
            };
            options: {
                selectedfont: string;
                container: string;
                element: string;
                fontcolor: string;
                available: string;
                unavailable: string;
            };
            error: string;
        };
    };
};
